/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers.utils;

import com.adeamx.scotiabank.guardavalores.lib.beans.DobleTipeo;
import java.io.Serializable;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.el.ExpressionFactory;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.AjaxBehaviorEvent;
import org.primefaces.behavior.ajax.AjaxBehavior;
import org.primefaces.behavior.ajax.AjaxBehaviorListenerImpl;
import org.primefaces.component.dialog.Dialog;
import org.primefaces.component.focus.Focus;
import org.primefaces.component.inputtext.InputText;
import org.primefaces.component.outputlabel.OutputLabel;
import org.primefaces.context.RequestContext;
import org.primefaces.event.CloseEvent;
import org.primefaces.extensions.component.inputnumber.InputNumber;


/**
 *
 * @author evglezmen
 */
public class DobleTipeoDialog implements Serializable{
    
    private boolean activoDialog;
    private DobleTipeo dobletipeo;
    private String valor;
    private String resultadoValidacion;
    private Map<String,Object> configBean;
    
    
    public DobleTipeoDialog(Map<String, Object> config){
        this.configBean =  config;
    }
    
    @PostConstruct
    public void init(){                
        activoDialog = false;
        dobletipeo =  new DobleTipeo();
        valor = "";    
        resultadoValidacion = "";        
    }    
    
   //** Crea los componentes del dialog, con los valores requeridos
    public RequestContext showDobleTipeo(FacesContext context, UIViewRoot view){        
        Map<String,String> params = context.getExternalContext().getRequestParameterMap();
        String component = params.get("javax.faces.partial.execute");        
        String valorInput = params.get(component);        
        dobletipeo = new DobleTipeo();
        
        if(!activoDialog){                    
            UIComponent panelGroup = view.findComponent(component);                    
            //UIComponent resource = view.findComponent("form");
            
            InputText inputOrigen = (InputText) panelGroup.findComponent(component.substring(component.lastIndexOf(":")+1));        
            Dialog dialog = (Dialog) panelGroup.findComponent("dialog"+inputOrigen.getId());            
            dobletipeo.setValorOrigen(valorInput);
            valor = "";
            resultadoValidacion = "";
            if(valorInput !=null && valorInput.trim().length() > 0){            
            ExpressionFactory ef = context.getApplication().getExpressionFactory();                        
            inputOrigen.setStyle("visibility: hidden;");

            if(dialog == null){                
                dialog =  new Dialog();                
                MethodExpression me = ef.createMethodExpression(context.getELContext(), "#{"+configBean.get("INPCLOSED")+"}", String.class, new Class[0]);                                                
                AjaxBehavior ajaxBehavior = (AjaxBehavior) context.getApplication().createBehavior(AjaxBehavior.BEHAVIOR_ID);
                ajaxBehavior.setProcess("@this");
                ajaxBehavior.addAjaxBehaviorListener(new AjaxBehaviorListenerImpl(me, me));
                dialog.addClientBehavior("close", ajaxBehavior);

                dialog.setId("dialog"+inputOrigen.getId());
                dialog.setWidgetVar("widget"+inputOrigen.getId());
                dialog.setHeader("Recaptura");
                dialog.setVisible(true);
                dialog.setClosable(false);
                dialog.setMinimizable(false);
                dialog.setMaximizable(false);                

                dialog.setDynamic(false);
                dialog.setHideEffect("fade");
                dialog.setFooter("Presiona Enter para validar o ESC para regresar");

                dialog.setDraggable(true);                
                dialog.setWidth("360");
                dialog.setHeight("100");
                
                dialog.setModal(true);
                dialog.setCloseOnEscape(true);
                //dialog.setAppendTo("@(body)");
                
                InputText inputText = new InputText();
                inputText.setId(inputOrigen.getId()+"Filter");
                inputText.setMaxlength(valorInput.length());
                inputText.setOnkeypress(inputOrigen.getOnkeypress());
                inputText.setOnkeyup(inputOrigen.getOnkeyup());                               
               // inputText.setOnkeydown("javascript:return displayKeyCode(event);");
                                
                ValueExpression dynExpression = createValueExpressions("#{"+configBean.get("NOMBEAN")+".valor}", String.class);                
                ValueExpression expressionValidacion = createValueExpressions("#{"+configBean.get("NOMBEAN")+".resultadoValidacion}", String.class);                                
                ValueExpression expressionColorValidacion = createValueExpressions("#{"+configBean.get("NOMBEAN")+".resultadoValidacion eq '¡CODIGO VALIDO!'?'color:green;font-size: 18Px;':'color:red;font-size: 18Px;'}", String.class);                                
                
                inputText.setValueExpression("value", dynExpression);                
                                                          
                MethodExpression methodsexpression = ef.createMethodExpression(context.getELContext(), "#{"+configBean.get("NOMBEAN")+".valida}", ActionEvent.class, new Class[0]);
                AjaxBehavior ajaxBehaviorInp = new AjaxBehavior(); 
                AjaxBehaviorListenerImpl ajaxBehaviorListenerImpl = new AjaxBehaviorListenerImpl(methodsexpression, methodsexpression); 
                ajaxBehaviorInp.addAjaxBehaviorListener(ajaxBehaviorListenerImpl);                
                ajaxBehaviorInp.setUpdate("@this,"+inputText.getId()+"Valida"); 
                ajaxBehaviorInp.setOncomplete("if(!args.isValid){PF('"+dialog.getWidgetVar()+"').hide()}");
                
                inputText.addClientBehavior("change", ajaxBehaviorInp);               

                OutputLabel lebel = new OutputLabel();
                lebel.setFor(inputText.getId());
                lebel.setValue(inputOrigen.getAlt());
                
                OutputLabel lebelValida = new OutputLabel();
                lebelValida.setId(inputText.getId()+"Valida");
                lebelValida.setValueExpression("value", expressionValidacion);
                lebelValida.setValueExpression("style", expressionColorValidacion);                
                
                Focus focus = new Focus();
                focus.setFor(inputText.getId());
                           
                dialog.getChildren().add(lebel);
                dialog.getChildren().add(inputText);
                dialog.getChildren().add(lebelValida);
                dialog.getChildren().add(focus);
                panelGroup.getChildren().add(dialog);
            } else{
                InputText inputText = new InputText();
                inputText.setId(inputOrigen.getId()+"Filter");
                inputText.setMaxlength(valorInput.length());
                inputText.setOnkeypress(inputOrigen.getOnkeypress());
                inputText.setOnkeyup(inputOrigen.getOnkeyup());               
                                
                ValueExpression dynExpression = createValueExpressions("#{"+configBean.get("NOMBEAN")+".valor}", String.class);                
                ValueExpression expressionValidacion = createValueExpressions("#{"+configBean.get("NOMBEAN")+".resultadoValidacion}", String.class);                                
                ValueExpression expressionColorValidacion = createValueExpressions("#{"+configBean.get("NOMBEAN")+".resultadoValidacion eq '¡CODIGO VALIDO!'?'color:green;font-size: 18Px;':'color:red;font-size: 18Px;'}", String.class);                                
                
                inputText.setValueExpression("value", dynExpression);                
                                                          
                MethodExpression methodsexpression = ef.createMethodExpression(context.getELContext(), "#{"+configBean.get("NOMBEAN")+".valida}", ActionEvent.class, new Class[0]);
                AjaxBehavior ajaxBehaviorInp = new AjaxBehavior(); 
                AjaxBehaviorListenerImpl ajaxBehaviorListenerImpl = new AjaxBehaviorListenerImpl(methodsexpression, methodsexpression); 
                ajaxBehaviorInp.addAjaxBehaviorListener(ajaxBehaviorListenerImpl);                
                ajaxBehaviorInp.setUpdate("@this,"+inputText.getId()+"Valida"); 
                ajaxBehaviorInp.setOncomplete("if(!args.isValid){PF('"+dialog.getWidgetVar()+"').hide()}");
                
                inputText.addClientBehavior("change", ajaxBehaviorInp);               

                OutputLabel lebel = new OutputLabel();
                lebel.setFor(inputText.getId());
                lebel.setValue(inputOrigen.getAlt());
                
                OutputLabel lebelValida = new OutputLabel();
                lebelValida.setId(inputText.getId()+"Valida");
                lebelValida.setValueExpression("value", expressionValidacion);
                lebelValida.setValueExpression("style", expressionColorValidacion);
                
                Focus focus = new Focus();
                focus.setFor(inputText.getId());
                           
                dialog.getChildren().add(lebel);
                dialog.getChildren().add(inputText);
                dialog.getChildren().add(lebelValida);
                dialog.getChildren().add(focus);
            }           
            setActivoDialog(true);
            RequestContext requestContext = RequestContext.getCurrentInstance();            
            requestContext.execute("PF('"+dialog.getWidgetVar()+"').show()");
            requestContext.update(component.substring(0,component.lastIndexOf(":")));            
            
            return requestContext;
            }
        }
        
    return null;    
}
    
    //** Crea los componentes del dialog, con los valores requeridos
    public RequestContext showDobleTipeoNumber(FacesContext context, UIViewRoot view){        
        Map<String,String> params = context.getExternalContext().getRequestParameterMap();
        String component = params.get("javax.faces.partial.execute");        
        String valorInput = params.get(component+"_input");        
        dobletipeo = new DobleTipeo();
        
        if(!activoDialog){                    
            UIComponent panelGroup = view.findComponent(component);                    
            //UIComponent resource = view.findComponent("form");
            
            InputNumber inputOrigen = (InputNumber) panelGroup.findComponent(component.substring(component.lastIndexOf(":")+1));        
            Dialog dialog = (Dialog) panelGroup.findComponent("dialog"+inputOrigen.getId());            
            dobletipeo.setValorOrigen(valorInput);
            valor = "";
            resultadoValidacion = "";
            if(valorInput !=null && valorInput.trim().length() > 0){            
            ExpressionFactory ef = context.getApplication().getExpressionFactory();                        
            inputOrigen.setStyle("visibility: hidden;");

            if(dialog == null){                
                dialog =  new Dialog();                
                MethodExpression me = ef.createMethodExpression(context.getELContext(), "#{"+configBean.get("NUMCLOSED")+"}", String.class, new Class[0]);                                                
                AjaxBehavior ajaxBehavior = (AjaxBehavior) context.getApplication().createBehavior(AjaxBehavior.BEHAVIOR_ID);
                ajaxBehavior.setProcess("@this");
                ajaxBehavior.addAjaxBehaviorListener(new AjaxBehaviorListenerImpl(me, me));
                dialog.addClientBehavior("close", ajaxBehavior);

                dialog.setId("dialog"+inputOrigen.getId());
                dialog.setWidgetVar("widget"+inputOrigen.getId());
                dialog.setHeader("Recaptura");
                dialog.setVisible(true);
                dialog.setClosable(false);
                dialog.setMinimizable(false);
                dialog.setMaximizable(false);                

                dialog.setDynamic(false);
                dialog.setHideEffect("fade");
                dialog.setFooter("Presiona Enter para validar o ESC para regresar");

                dialog.setDraggable(true);                
                dialog.setWidth("360");
                dialog.setHeight("100");
                
                dialog.setModal(true);
                dialog.setCloseOnEscape(true);
                //dialog.setAppendTo("@(body)");
                
                InputNumber inputText = new InputNumber();
                inputText.setId(inputOrigen.getId()+"Filter");
                inputText.setMaxlength(valorInput.length());
                inputText.setOnkeypress(inputOrigen.getOnkeypress());
                
               // inputText.setOnkeydown("javascript:return displayKeyCode(event);");
                                
                ValueExpression dynExpression = createValueExpressions("#{"+configBean.get("NOMBEAN")+".valor}", String.class);                
                ValueExpression expressionValidacion = createValueExpressions("#{"+configBean.get("NOMBEAN")+".resultadoValidacion}", String.class);                                
                ValueExpression expressionColorValidacion = createValueExpressions("#{"+configBean.get("NOMBEAN")+".resultadoValidacion eq '¡CODIGO VALIDO!'?'color:green;font-size: 18Px;':'color:red;font-size: 18Px;'}", String.class);                                
                
                inputText.setValueExpression("value", dynExpression);                
                                                          
                MethodExpression methodsexpression = ef.createMethodExpression(context.getELContext(), "#{"+configBean.get("NOMBEAN")+".valida}", ActionEvent.class, new Class[0]);
                AjaxBehavior ajaxBehaviorInp = new AjaxBehavior(); 
                AjaxBehaviorListenerImpl ajaxBehaviorListenerImpl = new AjaxBehaviorListenerImpl(methodsexpression, methodsexpression); 
                ajaxBehaviorInp.addAjaxBehaviorListener(ajaxBehaviorListenerImpl);                
                ajaxBehaviorInp.setUpdate("@this,"+inputText.getId()+"Valida"); 
                ajaxBehaviorInp.setOncomplete("if(!args.isValid){PF('"+dialog.getWidgetVar()+"').hide()}");
                
                inputText.addClientBehavior("change", ajaxBehaviorInp);               

                OutputLabel lebel = new OutputLabel();
                lebel.setFor(inputText.getId());
                lebel.setValue(inputOrigen.getAlt());
                
                OutputLabel lebelValida = new OutputLabel();
                lebelValida.setId(inputText.getId()+"Valida");
                lebelValida.setValueExpression("value", expressionValidacion);
                lebelValida.setValueExpression("style", expressionColorValidacion);                
                
                Focus focus = new Focus();
                focus.setFor(inputText.getId());
                           
                dialog.getChildren().add(lebel);
                dialog.getChildren().add(inputText);
                dialog.getChildren().add(lebelValida);
                dialog.getChildren().add(focus);
                panelGroup.getChildren().add(dialog);
            } else{
                InputNumber inputText = new InputNumber();                
                inputText.setId(inputOrigen.getId()+"Filter");
                inputText.setMaxlength(valorInput.length());                
                                
                ValueExpression dynExpression = createValueExpressions("#{"+configBean.get("NOMBEAN")+".valor}", String.class);                
                ValueExpression expressionValidacion = createValueExpressions("#{"+configBean.get("NOMBEAN")+".resultadoValidacion}", String.class);                                
                ValueExpression expressionColorValidacion = createValueExpressions("#{"+configBean.get("NOMBEAN")+".resultadoValidacion eq '¡CODIGO VALIDO!'?'color:green;font-size: 18Px;':'color:red;font-size: 18Px;'}", String.class);                                
                
                inputText.setValueExpression("value", dynExpression);                
                                                          
                MethodExpression methodsexpression = ef.createMethodExpression(context.getELContext(), "#{"+configBean.get("NOMBEAN")+".valida}", ActionEvent.class, new Class[0]);
                AjaxBehavior ajaxBehaviorInp = new AjaxBehavior(); 
                AjaxBehaviorListenerImpl ajaxBehaviorListenerImpl = new AjaxBehaviorListenerImpl(methodsexpression, methodsexpression); 
                ajaxBehaviorInp.addAjaxBehaviorListener(ajaxBehaviorListenerImpl);                
                ajaxBehaviorInp.setUpdate("@this,"+inputText.getId()+"Valida"); 
                ajaxBehaviorInp.setOncomplete("if(!args.isValid){PF('"+dialog.getWidgetVar()+"').hide()}");
                
                inputText.addClientBehavior("change", ajaxBehaviorInp);               

                OutputLabel lebel = new OutputLabel();
                lebel.setFor(inputText.getId());
                lebel.setValue(inputOrigen.getAlt());
                
                OutputLabel lebelValida = new OutputLabel();
                lebelValida.setId(inputText.getId()+"Valida");
                lebelValida.setValueExpression("value", expressionValidacion);
                lebelValida.setValueExpression("style", expressionColorValidacion);
                
                Focus focus = new Focus();
                focus.setFor(inputText.getId());
                           
                dialog.getChildren().add(lebel);
                dialog.getChildren().add(inputText);
                dialog.getChildren().add(lebelValida);
                dialog.getChildren().add(focus);
            }           
            setActivoDialog(true);
            RequestContext requestContext = RequestContext.getCurrentInstance();            
            requestContext.execute("PF('"+dialog.getWidgetVar()+"').show()");
            requestContext.update(component.substring(0,component.lastIndexOf(":")));            
            
            return requestContext;
            }
        }
        
    return null;    
}
    
    
    
    public void valida(AjaxBehaviorEvent even){
        RequestContext requestContext = RequestContext.getCurrentInstance();
        
        if(getValor().equals(dobletipeo.getValorOrigen())){  
            resultadoValidacion = "¡CODIGO VALIDO!";
            // add callback parameter
            requestContext.addCallbackParam("isValid", false);
        }else{
            resultadoValidacion = "¡ CODIGO NO COINCIDE !";
             // add callback parameter
            requestContext.addCallbackParam("isValid", true);
        }        
    }
    
    
    
    public void closed(CloseEvent ce){                
        UIViewRoot view = FacesContext.getCurrentInstance().getViewRoot();
        Dialog dialog = (Dialog) ce.getComponent();
        String clienteId = dialog.getClientId().replaceAll("dialog", "");
        String IdInput = clienteId.substring(clienteId.lastIndexOf(":")+1);        
        
        UIComponent panelGroup = view.findComponent(clienteId);        
        InputText input = (InputText) panelGroup.findComponent(IdInput); 
        input.setStyle("visibility:visible;");
        
        if(!getValor().equals(dobletipeo.getValorOrigen())){
            input.resetValue();
            input.setValue("");
        }
        
        deleteComponentsHoldingUnwantedState(dialog.getClientId().substring(dialog.getClientId().lastIndexOf(":")+1));  
        RequestContext requestContext = RequestContext.getCurrentInstance();
        requestContext.execute("document.getElementById('"+clienteId+"').focus()");        
        requestContext.update(clienteId);
        setActivoDialog(false);        
    }
    
    
    public void closedTipeoNumber(CloseEvent ce){ 
        UIViewRoot view = FacesContext.getCurrentInstance().getViewRoot();
        
        Dialog dialog = (Dialog) ce.getComponent();
        String clienteId = dialog.getClientId().replaceAll("dialog", "");
        String IdInput = clienteId.substring(clienteId.lastIndexOf(":")+1);        
        
        UIComponent panelGroup = view.findComponent(clienteId);        
        InputNumber input = (InputNumber) panelGroup.findComponent(IdInput); 
        input.setStyle("visibility:visible;");
        
        if(!getValor().equals(dobletipeo.getValorOrigen())){
            input.resetValue();
            input.setValue("");
        }
        
        deleteComponentsHoldingUnwantedState(dialog.getClientId().substring(dialog.getClientId().lastIndexOf(":")+1));  
        RequestContext requestContext = RequestContext.getCurrentInstance();
        requestContext.execute("document.getElementById('"+clienteId+"').focus()");        
        requestContext.update(clienteId);
        setActivoDialog(false);        
    }
        
    private static ValueExpression createValueExpressions(String valueExpression, Class<?> valueType) {
        FacesContext context = FacesContext.getCurrentInstance();
        return context.getApplication().getExpressionFactory()
            .createValueExpression(context.getELContext(), valueExpression, valueType);
    }
    
    public static UIViewRoot getUIViewRoot() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        return facesContext != null ? facesContext.getViewRoot() : null;
    }
    
    
    public static void deleteComponentsHoldingUnwantedState(String componentId) {
	    deleteComponentsHoldingUnwantedState(findComponent(getUIViewRoot(), componentId));
	}
    
    
    public static void deleteComponentsHoldingUnwantedState(UIComponent parentComponent) {
        if (parentComponent != null) {
            parentComponent.getChildren().clear();
        }
    }
    
    private static UIComponent findComponent(UIComponent parentComponent, String componentId) {
	    if (parentComponent != null) {
	        if (componentId.equals(parentComponent.getId())) {
	            return parentComponent;
	        }
	        for (UIComponent child : parentComponent.getChildren()) {
	            UIComponent component = findComponent(child, componentId);
	            if (component != null) {
	                return component;
	            }
	        }
	    }
	    return null;
	}
    
    
    public boolean isActivoDialog() {
        return activoDialog;
    }

    public void setActivoDialog(boolean activoDialog) {
        this.activoDialog = activoDialog;
    }

    public DobleTipeo getDobletipeo() {
        return dobletipeo;
    }

    public void setDobletipeo(DobleTipeo dobletipeo) {
        this.dobletipeo = dobletipeo;
    }


   
    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getResultadoValidacion() {
        return resultadoValidacion;
    }

    public void setResultadoValidacion(String resultadoValidacion) {
        this.resultadoValidacion = resultadoValidacion;
    }
    
    
}
