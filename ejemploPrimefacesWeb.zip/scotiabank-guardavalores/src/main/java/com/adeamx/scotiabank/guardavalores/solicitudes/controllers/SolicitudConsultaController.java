package com.adeamx.scotiabank.guardavalores.solicitudes.controllers;

import com.adeadms.core.adea.pojos.Clientes;
import com.adeamx.dms.libs.consultas.beans.ScPersonalBean;
import com.adeamx.dms.libs.consultas.pojos.AdeaCatalogos;
import com.adeamx.dms.libs.consultas.pojos.ScCentroCosto;
import com.adeamx.dms.libs.consultas.pojos.ScPrioridad;
import com.adeamx.dms.libs.consultas.pojos.ScSolicitudConsulta;
import com.adeamx.dms.libs.consultas.pojos.ScTipoConsulta;
import com.adeamx.dms.libs.consultas.services.BusquedaService;
import com.adeamx.dms.libs.consultas.services.CatalogoService;
import com.adeamx.dms.libs.consultas.utils.ComboItem;
import com.adeamx.faces.lib.utilerias.MessagesShow;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScbnkExpediente;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaSolicitudConsultaService;

import java.io.BufferedReader;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import mx.com.adea.security.core.userdetails.UserDetails;
import net.codicentro.core.TypeCast;
import org.apache.commons.lang.StringUtils;
import org.primefaces.event.FileUploadEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/**
 *
 * @author asalgado
 */
@Component
@Scope("view")
public class SolicitudConsultaController implements Serializable {

    private Logger logger = LoggerFactory.getLogger(SolicitudConsultaController.class);

    @Value("${com.adeamx.webmx.customer.id}")
    private Long scltcod;

    @Autowired
    private ScotiaSolicitudConsultaService consultaService;

    @Autowired
    private CatalogoService catalogoServiceImpl;

    @Autowired
    private BusquedaService busquedaService;

    private UserDetails userDetails;

    //Busqueda Expedientes
    private String nunicodocFilter;
    private String nunicodoctFilter;
    private String nroIdentdocFilter;
    private Long folioFilter;
    private Long creditoFilter;

    private List<ScbnkExpediente> lstBusqueda;
    private List<ScbnkExpediente> lstSolicitados;
    private ScbnkExpediente selectedExpediente;

    //Datos de la solicitud
    private List<Clientes> clientList = new ArrayList<Clientes>();
    private Long clienteId;
    private String folioCliente;
    private List<ComboItem> lugarConsultaList = new ArrayList<ComboItem>();
    private Integer lugarConsulta;
    private List<AdeaCatalogos> modosConsultaList = new ArrayList<AdeaCatalogos>();
    private String modoConsulta;
    private List<AdeaCatalogos> kitModoConsultaList = new ArrayList<AdeaCatalogos>();
    private Integer kitSelected;
    private List<ScPrioridad> prioridadList = new ArrayList<ScPrioridad>();
    private Long prioridad;
    private List<ScTipoConsulta> tipoConsultaList = new ArrayList<ScTipoConsulta>();
    private Long tipoConsulta;
    private List<ScPersonalBean> solicitanteList = new ArrayList<ScPersonalBean>();
    private Long solicitante;
    private List<ScPersonalBean> receptoresList = new ArrayList<ScPersonalBean>();
    private Long receptor;
    private List<ScCentroCosto> centroCostoList = new ArrayList<ScCentroCosto>();
    private Long centroCosto;
    private String observaciones;
    private String observacionesFact;
    private boolean facturable;
    
    private boolean fluidGridBusquedaVisible;
    private boolean swON;
    private boolean docsVisible;

    @PostConstruct
    public void init() {
        userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        fluidGridBusquedaVisible = true;
        docsVisible = false;
        loadClienteList();
    }

    public void altaSolicitud() {
        try {
            if (lstSolicitados == null || lstSolicitados.isEmpty()) {
                throw new Exception("No se ha seleccionado ningún expediente.");
            }
            
            ScSolicitudConsulta solicitud = new ScSolicitudConsulta();
            solicitud.setSolicitante(solicitante);
            solicitud.setReceptor(receptor);
            solicitud.setTipoConsulta(tipoConsulta);
            solicitud.setPrioridad(prioridad);
            solicitud.setCc(centroCosto);
            solicitud.setLugarConsulta(lugarConsulta);
            solicitud.setFacturable(facturable ? 1 : 0);
            solicitud.setObservaciones(!com.adeamx.adeadms.util.TypeCast.isBlank(observaciones) ? observaciones.trim() : "");
            solicitud.setClienteContenido(scltcod);
            solicitud.setArchivoConsulta("");
            solicitud.setArchivoDepositado("");
            solicitud.setConsecutivo(0L);
            solicitud.setFechaRespuesta(new Date(System.currentTimeMillis() + (prioridad == 1 ? 259200000 : 86400000)));
            consultaService.altaSolicitud(solicitud, lstSolicitados, userDetails.getUsername());

            limpiaCampos();

        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(SolicitudConsultaController.class.getName()).log(Level.SEVERE, "Ocurrió un error al generar la solicitud", ex);
            MessagesShow.showMessageErrorBackEnd("Ocurrió un error al generar la solicitud: <br/> " + ex.getMessage());

        }
    }

    public void cleanSearch() {
        nunicodocFilter = null;
        nunicodoctFilter = null;
        nroIdentdocFilter = null;
        folioFilter = null;
        creditoFilter = null;
        lstBusqueda = null;
    }

    public void buscar() {
        if(modoConsulta == null || modoConsulta.isEmpty()){
            MessagesShow.showMessageError("Favor de seleccionar el Modo de Consulta");
            return;
        }
        Map<String, Object> params = new HashMap<String, Object>();
        if (!StringUtils.isBlank(nunicodocFilter)) {
            params.put("nunicodoc", TypeCast.toLong(StringUtils.substring(nunicodocFilter, 1)));
        }
        if (!StringUtils.isBlank(nunicodoctFilter)) {
            params.put("nunicodoct", TypeCast.toLong(StringUtils.substring(nunicodoctFilter, 1)));
        }
        if (!StringUtils.isBlank(nroIdentdocFilter)) {
            params.put("nroidentdoc", nroIdentdocFilter);
        }
        if (folioFilter != null && folioFilter != 0L) {
            params.put("folio", folioFilter);
        } else {
            folioFilter = null;
        }
        if (creditoFilter != null && creditoFilter != 0L) {
            params.put("credito", creditoFilter);
        } else {
            creditoFilter = null;
        }
//        if (params.isEmpty()) {
//            MessagesShow.showMessageError("LLene por lo menos un filtro de búsqueda");
//        } else {
        lstBusqueda = consultaService.buscaExpedientes(params,modoConsulta);
//        }
    }

    public void limpiaCampos() {
        clienteId = null;
        lugarConsultaList = new ArrayList<ComboItem>();
        lugarConsulta = null;
        modosConsultaList = new ArrayList<AdeaCatalogos>();
        modoConsulta = null;
        kitModoConsultaList = new ArrayList<AdeaCatalogos>();
        kitSelected = null;
        prioridadList = new ArrayList<ScPrioridad>();
        prioridad = null;
        tipoConsultaList = new ArrayList<ScTipoConsulta>();
        tipoConsulta = null;
        solicitanteList = new ArrayList<ScPersonalBean>();
        solicitante = null;
        receptoresList = new ArrayList<ScPersonalBean>();
        receptor = null;
        centroCostoList = new ArrayList<ScCentroCosto>();
        centroCosto = null;
        facturable = false;
        observaciones = "";
        observacionesFact = "";
        folioCliente = null;
        lstBusqueda = null;
        lstSolicitados = null;
        docsVisible = false;
        loadClienteList();
        cleanSearch();
    }

    public void asignaExpedienteToSolicitados() {
        if (lstSolicitados == null || lstSolicitados.isEmpty()) {
            lstSolicitados = new ArrayList<ScbnkExpediente>();
        }

        if (selectedExpediente.getNunicodoc() == null || selectedExpediente.getNunicodoc() == 0) {
            MessagesShow.showMessageError("El expediente no tiene etiqueta U, no se puede agregar a la solicitud");
            return;
        }
        if (existeExpedienteEnSolicitados(lstSolicitados, selectedExpediente) != -1) {
            MessagesShow.showMessageError("El expediente ya se encuentra en lista de solicitudes");
            return;
        }
        if(modoConsulta.equals("DOCUMENTOS") && selectedExpediente.getNunicodoct() == null ){
            MessagesShow.showMessageError("El expediente no tiene documentos, no se puede agregar a la solicitud");
            return;
        }
        try {
            Map<String, Object> modelMap = consultaService.validaExpedienteFolio(selectedExpediente.getNunicodoc(), scltcod, selectedExpediente.getNunicodoct());
            Boolean data = (Boolean) modelMap.get("data");
            if (data) {
                String slc = (String) modelMap.get("solicitante");
                Date fecha = (Date) modelMap.get("fecha");
                String message = null;
                if(modoConsulta.equals("EXPEDIENTES") && ((BigDecimal)modelMap.get("completo")).intValue() == 0){
                    //Se permite solicitar expediente aunque tenga documentos en consulta
//                     message = String.format("El expediente %d tiene documentos solicitados por %s desde %s", 
//                        selectedExpediente.getNunicodoc(), slc, TypeCast.toString(fecha, "dd/MM/yyyy"));
                } else {
                    message = String.format("El "+modoConsulta.toLowerCase().substring(0,modoConsulta.length()-1)+" %d esta solicitado por %s desde %s", 
                        modoConsulta.equals("EXPEDIENTES") ? selectedExpediente.getNunicodoc() : selectedExpediente.getNunicodoct(), slc, TypeCast.toString(fecha, "dd/MM/yyyy"));
                }
                if(message != null){
                    MessagesShow.showMessageErrorBackEnd(message);
                } else {
                    lstSolicitados.add(selectedExpediente);
                }
                
            } else {
                if(modoConsulta.equals("DOCUMENTOS")){
                    if(!consultaService.isDocumentoValido(selectedExpediente.getNunicodoct())){
                        MessagesShow.showMessageErrorBackEnd("EL DOCUMENTO TIENE UN ESTADO NO VALIDO PARA SER CONSULTADO.");
                        return;
                    }
                }
                lstSolicitados.add(selectedExpediente);
            }

        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(SolicitudConsultaController.class.getName()).log(Level.SEVERE, null, ex);
            MessagesShow.showMessageErrorBackEnd(ex.getMessage());
        }

    }

    public void eliminaExpedienteFromSolicitados() {
        Integer index = existeExpedienteEnSolicitados(lstSolicitados, selectedExpediente);
        if (index != null && index != -1) {
            lstSolicitados.remove(index.intValue());
        }
    }

    private Integer existeExpedienteEnSolicitados(List<ScbnkExpediente> lstSolicitados, ScbnkExpediente selectedExpediente) {
        int i = 0;
        for (ScbnkExpediente solicitado : lstSolicitados) {
            if (modoConsulta.equals("EXPEDIENTES") && solicitado.getNunicodoc().equals(selectedExpediente.getNunicodoc())) {
                return i;
            } else if (modoConsulta.equals("DOCUMENTOS") && solicitado.getNunicodoct().equals(selectedExpediente.getNunicodoct())) {
                return i;
            }
            i++;
        }
        return -1;
    }

    public void loadClienteList() {
        try {
            clientList = new ArrayList<Clientes>();
            Clientes cte = catalogoServiceImpl.getClienteByScltcod(scltcod);
            clientList.add(cte);
//            clientList = catalogoServiceImpl.getClientes(null);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    public void loadLugaresConsultaList() {
        try {
//            limpiar pantalla
            lugarConsultaList = new ArrayList<ComboItem>();
            lugarConsulta = null;
            modosConsultaList = new ArrayList<AdeaCatalogos>();
            modoConsulta = null;
            kitModoConsultaList = new ArrayList<AdeaCatalogos>();
            kitSelected = null;
            prioridadList = new ArrayList<ScPrioridad>();
            prioridad = null;
            tipoConsultaList = new ArrayList<ScTipoConsulta>();
            tipoConsulta = null;
            solicitanteList = new ArrayList<ScPersonalBean>();
            solicitante = null;
            receptoresList = new ArrayList<ScPersonalBean>();
            receptor = null;
            centroCostoList = new ArrayList<ScCentroCosto>();
            centroCosto = null;

            lugarConsultaList = new ArrayList<ComboItem>();
            lugarConsultaList.add(new ComboItem(ComboItem.LUGAR_CONSULTA_LOCAL_CLIENTE_VALUE, ComboItem.LUGAR_CONSULTA_LOCAL_CLIENTE_LABEL));
            lugarConsultaList.add(new ComboItem(ComboItem.LUGAR_CONSULTA_REMOTA_VALUE, ComboItem.LUGAR_CONSULTA_REMOTA_LABEL));
            if (userDetails.getUser().getCliente() == 2L) {
                lugarConsultaList.add(new ComboItem(ComboItem.LUGAR_CONSULTA_INTERNA_VALUE, ComboItem.LUGAR_CONSULTA_INTERNA_LABEL));
                lugarConsultaList.add(new ComboItem(ComboItem.LUGAR_CONSULTA_DEVOLUCION_DEFINITIVA_VALUE, ComboItem.LUGAR_CONSULTA_DEVOLUCION_DEFINITIVA_LABEL));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadModosConsultaList() {
        try {
            modosConsultaList = consultaService.obtenerModosConsulta(clienteId.intValue());
        } catch (Exception e) {
            logger.error(e.getMessage());
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadInComboModoConsulta() {
        loadKitConsultaList();
        loadPrioridadesList();
        if(modoConsulta.equals("DOCUMENTOS")){
            docsVisible = true;
        } else{
            nunicodoctFilter = null;
            docsVisible = false;
        }
        lstBusqueda = null;
        lstSolicitados = null;
    }

    public void loadKitConsultaList() {
        try {
            AdeaCatalogos modoSelected = getModoSelected();
            if (modoSelected != null) {
                kitModoConsultaList = busquedaService.obtenerKits(modoSelected.getId());
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadPrioridadesList() {
        try {
            prioridadList = catalogoServiceImpl.getPrioridades(clienteId);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadTiposConsultaList() {
        Integer item;
        try {
//            if (modoConsulta == ComboItem.MODO_CONSULTA_CAJAS_VALUE) {
            if (ComboItem.MODO_CONSULTA_CAJAS_LABEL.compareTo(modoConsulta) == 0) {
                item = ScTipoConsulta.ITEM_SOLICITADO_CAJAS;
            } else {
                item = ScTipoConsulta.ITEM_SOLICITADO_EXPEDIENTES;
            }
            tipoConsultaList = catalogoServiceImpl.getTiposConsulta(clienteId, item);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadSolicitantesList() {
        try {
            solicitanteList = catalogoServiceImpl.getSolicitantes(clienteId, null);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadReceptoresList() {
        try {
            receptoresList = catalogoServiceImpl.getReceptores(clienteId, null);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadCentrosCostoList() {
        try {
            centroCostoList = catalogoServiceImpl.getCentrosCosto(clienteId);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    private AdeaCatalogos getModoSelected() {
        if (modoConsulta != null) {
            for (AdeaCatalogos catalogo : modosConsultaList) {
                if (catalogo.getDescripcionCat().compareTo(modoConsulta) == 0) {
                    return catalogo;
                }
            }
        }
        return null;
    }
    
    
    public void habilitaCargaArchivo(){
    	if(swON){
    		fluidGridBusquedaVisible = false;
    	}else{
    		fluidGridBusquedaVisible = true;
    	} 
    }
    
    public void handleFileUpload(FileUploadEvent event) {
        try {

            InputStream in = event.getFile().getInputstream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
//    	        StringBuilder out = new StringBuilder();
            String line;

            LinkedList<String> lListAcepted = new LinkedList<String>();
            LinkedList<String> lListRefused = new LinkedList<String>();

            if (!modoConsulta.equals("EXPEDIENTES") || modoConsulta.isEmpty()) {
                MessagesShow.showMessageError("Favor de seleccionar el Modo de Consulta en expediente");
                return;
            }

            while ((line = reader.readLine()) != null) {
                try {
                    Long.parseLong(line);
                    lListAcepted.push(line);
                } catch (NumberFormatException nfe) {
                    lListRefused.push(line);
                }
            }

            if ((lListAcepted.size() + lListRefused.size()) > 1000) {
                MessagesShow.showMessageError("El archivo no debe contener mas de 1000 registros.");
                return;
            }

            if (lstSolicitados == null || lstSolicitados.isEmpty()) {
                lstSolicitados = new ArrayList<ScbnkExpediente>();
            }
            String listaCreditos = "";
            for (String credito : lListAcepted) {
                listaCreditos = listaCreditos + credito + ",";
            }

            Map<String, Object> params = new HashMap<String, Object>();
            params.put("credito", listaCreditos.substring(0, listaCreditos.length() - 1));
            lstBusqueda = consultaService.buscaExpedientes(params, modoConsulta);
            
            
            try {
                if (!lstBusqueda.isEmpty()) {

                    if (lListRefused.size() > lstBusqueda.size()) {
                        MessagesShow.showMessageError("Archivo rechazado por mayoria de registros incorrectos.");
                        return;
                    }

                    lstSolicitados = consultaService.validaExpedientesaConsultar(lstBusqueda);

                    if (lListRefused.size() > lstSolicitados.size()) {
                        MessagesShow.showMessageError("Archivo rechazado por mayoria de registros incorrectos.");
                        return;
                    }
                }

            } catch (Exception ex) {
                java.util.logging.Logger.getLogger(SolicitudConsultaController.class.getName()).log(Level.SEVERE, null, ex);
                MessagesShow.showMessageErrorBackEnd(ex.getMessage());
            }

            MessagesShow.showMessageInfo("Archivo Cargado correctamente con: " + lstSolicitados.size() + " registros.");

        } catch (Exception e) {
            e.printStackTrace();
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error: " + e.getMessage());
            FacesContext.getCurrentInstance().addMessage(null, message);

        }

    }
    

    public String getNunicodocFilter() {
        return nunicodocFilter;
    }

    public void setNunicodocFilter(String nunicodocFilter) {
        this.nunicodocFilter = nunicodocFilter;
    }

    public String getNunicodoctFilter() {
        return nunicodoctFilter;
    }

    public void setNunicodoctFilter(String nunicodoctFilter) {
        this.nunicodoctFilter = nunicodoctFilter;
    }

    public String getNroIdentdocFilter() {
        return nroIdentdocFilter;
    }

    public void setNroIdentdocFilter(String nroIdentdocFilter) {
        this.nroIdentdocFilter = nroIdentdocFilter;
    }

    public Long getFolioFilter() {
        return folioFilter;
    }

    public void setFolioFilter(Long folioFilter) {
        this.folioFilter = folioFilter;
    }

    public Long getCreditoFilter() {
        return creditoFilter;
    }

    public void setCreditoFilter(Long creditoFilter) {
        this.creditoFilter = creditoFilter;
    }

    public List<ScbnkExpediente> getLstBusqueda() {
        return lstBusqueda;
    }

    public void setLstBusqueda(List<ScbnkExpediente> lstBusqueda) {
        this.lstBusqueda = lstBusqueda;
    }

    public List<ScbnkExpediente> getLstSolicitados() {
        return lstSolicitados;
    }

    public void setLstSolicitados(List<ScbnkExpediente> lstSolicitados) {
        this.lstSolicitados = lstSolicitados;
    }

    public ScbnkExpediente getSelectedExpediente() {
        return selectedExpediente;
    }

    public void setSelectedExpediente(ScbnkExpediente selectedExpediente) {
        this.selectedExpediente = selectedExpediente;
    }

    public List<Clientes> getClientList() {
        return clientList;
    }

    public void setClientList(List<Clientes> clientList) {
        this.clientList = clientList;
    }

    public Long getClienteId() {
        return clienteId;
    }

    public void setClienteId(Long clienteId) {
        this.clienteId = clienteId;
    }

    public List<ComboItem> getLugarConsultaList() {
        return lugarConsultaList;
    }

    public void setLugarConsultaList(List<ComboItem> lugarConsultaList) {
        this.lugarConsultaList = lugarConsultaList;
    }

    public Integer getLugarConsulta() {
        return lugarConsulta;
    }

    public void setLugarConsulta(Integer lugarConsulta) {
        this.lugarConsulta = lugarConsulta;
    }

    public List<AdeaCatalogos> getModosConsultaList() {
        return modosConsultaList;
    }

    public void setModosConsultaList(List<AdeaCatalogos> modosConsultaList) {
        this.modosConsultaList = modosConsultaList;
    }

    public String getModoConsulta() {
        return modoConsulta;
    }

    public void setModoConsulta(String modoConsulta) {
        this.modoConsulta = modoConsulta;
    }

    public List<AdeaCatalogos> getKitModoConsultaList() {
        return kitModoConsultaList;
    }

    public void setKitModoConsultaList(List<AdeaCatalogos> kitModoConsultaList) {
        this.kitModoConsultaList = kitModoConsultaList;
    }

    public Integer getKitSelected() {
        return kitSelected;
    }

    public void setKitSelected(Integer kitSelected) {
        this.kitSelected = kitSelected;
    }

    public List<ScPrioridad> getPrioridadList() {
        return prioridadList;
    }

    public void setPrioridadList(List<ScPrioridad> prioridadList) {
        this.prioridadList = prioridadList;
    }

    public Long getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(Long prioridad) {
        this.prioridad = prioridad;
    }

    public List<ScTipoConsulta> getTipoConsultaList() {
        return tipoConsultaList;
    }

    public void setTipoConsultaList(List<ScTipoConsulta> tipoConsultaList) {
        this.tipoConsultaList = tipoConsultaList;
    }

    public Long getTipoConsulta() {
        return tipoConsulta;
    }

    public void setTipoConsulta(Long tipoConsulta) {
        this.tipoConsulta = tipoConsulta;
    }

    public List<ScPersonalBean> getSolicitanteList() {
        return solicitanteList;
    }

    public void setSolicitanteList(List<ScPersonalBean> solicitanteList) {
        this.solicitanteList = solicitanteList;
    }

    public Long getSolicitante() {
        return solicitante;
    }

    public void setSolicitante(Long solicitante) {
        this.solicitante = solicitante;
    }

    public List<ScPersonalBean> getReceptoresList() {
        return receptoresList;
    }

    public void setReceptoresList(List<ScPersonalBean> receptoresList) {
        this.receptoresList = receptoresList;
    }

    public Long getReceptor() {
        return receptor;
    }

    public void setReceptor(Long receptor) {
        this.receptor = receptor;
    }

    public List<ScCentroCosto> getCentroCostoList() {
        return centroCostoList;
    }

    public void setCentroCostoList(List<ScCentroCosto> centroCostoList) {
        this.centroCostoList = centroCostoList;
    }

    public Long getCentroCosto() {
        return centroCosto;
    }

    public void setCentroCosto(Long centroCosto) {
        this.centroCosto = centroCosto;
    }

    public String getFolioCliente() {
        return folioCliente;
    }

    public void setFolioCliente(String folioCliente) {
        this.folioCliente = folioCliente;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getObservacionesFact() {
        return observacionesFact;
    }

    public void setObservacionesFact(String observacionesFact) {
        this.observacionesFact = observacionesFact;
    }

    public boolean isFacturable() {
        return facturable;
    }

    public void setFacturable(boolean facturable) {
        this.facturable = facturable;
    }

    public boolean isSwON() {
            return swON;
    }

    public void setSwON(boolean swON) {
            this.swON = swON;
    }

    public boolean isFluidGridBusquedaVisible() {
            return fluidGridBusquedaVisible;
    }

    public void setFluidGridBusquedaVisible(boolean fluidGridBusquedaVisible) {
            this.fluidGridBusquedaVisible = fluidGridBusquedaVisible;
    }

    public boolean isDocsVisible() {
        return docsVisible;
    }

    public void setDocsVisible(boolean docsVisible) {
        this.docsVisible = docsVisible;
    }	
}
