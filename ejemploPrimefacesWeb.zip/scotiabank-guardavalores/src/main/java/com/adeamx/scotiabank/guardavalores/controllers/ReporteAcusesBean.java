/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import mx.com.adea.security.core.userdetails.UserDetails;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adeamx.adeadms.servicios.RegistroGeneralServicio;
import com.adeamx.scotiabank.guardavalores.lib.beans.ReporteTotalesLectMasiva;
import com.adeamx.scotiabank.guardavalores.lib.beans.SbReporteDocumentosLecM;
import com.adeamx.scotiabank.guardavalores.lib.pojos.AcuseScbnkDetalle;
import com.adeamx.scotiabank.guardavalores.lib.pojos.AcuseScbnkTotales;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScbnkBaseLectura;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaLecturaMasivaService;
import com.adeamx.scotiabank.guardavalores.lib.utils.Constantes;

/**
 * 
 * @author jdavila
 */
@Controller
@Scope("view")
public class ReporteAcusesBean implements Serializable{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private static final Logger log = LoggerFactory.getLogger(ReporteAcusesBean.class);
    
    JasperReport jasperReport = null;
    JasperPrint jasperPrint = null;
    Map<String, Object> jasperParams = null;
    
    private List<AcuseScbnkDetalle> acuseScbnkDetalleList;
    private List<AcuseScbnkTotales> acuseScbnkTotalesList;
    
    @Autowired
    ScotiaLecturaMasivaService scotiaLecturaMasivaService;    
    
	private String folioAcuse;

    @PostConstruct
    public void init(){
    	acuseScbnkDetalleList = new ArrayList<AcuseScbnkDetalle>();
    	acuseScbnkTotalesList = new ArrayList<AcuseScbnkTotales>();; 
    }

    public void limpiaForm(){     
    	acuseScbnkDetalleList = null;
    	acuseScbnkTotalesList = null;
    	folioAcuse = null;
    }   
  
    public void search() {
    	acuseScbnkDetalleList =  scotiaLecturaMasivaService.obtieneDetalleByFolioAcuse(folioAcuse);
    	acuseScbnkTotalesList = scotiaLecturaMasivaService.obtieneTotalesByFolioAcuse(folioAcuse);
    }    
    
   
    public void exportPdfCartaDetalle() {
    	System.out.println("generaAcuse");
    	FacesContext context = FacesContext.getCurrentInstance();
		try {				
            HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
				
				JasperReport jr = JasperCompileManager.compileReport(Thread.currentThread().getContextClassLoader()
						.getResourceAsStream("reports/ReporteTotalesSobrantes.jrxml"));
				
				JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(acuseScbnkDetalleList);

				Map<String, Object> parametros = new HashMap<String, Object>();
	
				parametros.put("ubicacionScotia", acuseScbnkTotalesList.get(0).getUbicacion());
				parametros.put("ubicacionAdea", acuseScbnkTotalesList.get(0).getUbicacionAdea());
				parametros.put("localizacion", acuseScbnkTotalesList.get(0).getLocalizacion());
				parametros.put("folio", folioAcuse);
				parametros.put("usuarioLectura", acuseScbnkTotalesList.get(0).getUsuarioLectura());
				parametros.put("fechaLectura", acuseScbnkTotalesList.get(0).getFechaLectura());				
				// realizamos el for para los demas parametros
				
				parametros.put("TpoCredAuto","AUTO");
				parametros.put("TpoCreditoHipo","HIPOTECARIO");
				parametros.put("TpoCreditoPersonal","PERSONAL");
				parametros.put("TpoCreditoRH","RRHH");
				
				for (AcuseScbnkTotales dataTotales : acuseScbnkTotalesList) {
					
					if ((dataTotales.getAcuseScbnkTotalesPk().getTipoCredito()).equals(Constantes.C_AUTO)) {
						parametros.put("conciliadoAuto",dataTotales.getConciliados());
						parametros.put("sobranteAuto",dataTotales.getSobrantes());
						parametros.put("faltanteAuto",dataTotales.getFaltantes());
					} else if ((dataTotales.getAcuseScbnkTotalesPk().getTipoCredito()).equals(Constantes.C_HIPOTECARIO)) {
						parametros.put("conciliadoHipo",dataTotales.getConciliados());
						parametros.put("sobranteHipo",dataTotales.getSobrantes());
						parametros.put("faltanteHipo",dataTotales.getFaltantes());
					} else if ((dataTotales.getAcuseScbnkTotalesPk().getTipoCredito()).equals(Constantes.C_PERSONAL)) {
						parametros.put("conciliadoPersonal",dataTotales.getConciliados());
						parametros.put("sobrantePersonal",dataTotales.getSobrantes());
						parametros.put("faltantePersonal",dataTotales.getFaltantes());
					} else if ((dataTotales.getAcuseScbnkTotalesPk().getTipoCredito()).equals(Constantes.C_RRHH)) {
						parametros.put("conciliadoRH",dataTotales.getConciliados());
						parametros.put("sobranteRH", dataTotales.getSobrantes());
						parametros.put("faltanteRH", dataTotales.getFaltantes());
					} 

				}
				
				byte[] fichero = JasperRunManager.runReportToPdf(jr,parametros, beanCollectionDataSource);
				ServletOutputStream outputStream = response.getOutputStream();
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment; filename=\"Acuse_"+folioAcuse+ ".pdf\"");
				outputStream.write(fichero);
				outputStream.flush();
				outputStream.close();
		        context.renderResponse();
	            context.responseComplete();	
				
			
		} catch (Exception ex) {
			ex.printStackTrace();
			addMessageError("Error!", ex.getMessage());
		}	
    }
    


	/**
      * MENSAJES 
      * @param summary
      * @param detail
      */
    
    public void addMessageInfo(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public void addMessageError(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public void addMessageWarning(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

	public List<AcuseScbnkDetalle> getAcuseScbnkDetalleList() {
		return acuseScbnkDetalleList;
	}

	public void setAcuseScbnkDetalleList(
			List<AcuseScbnkDetalle> acuseScbnkDetalleList) {
		this.acuseScbnkDetalleList = acuseScbnkDetalleList;
	}

	public List<AcuseScbnkTotales> getAcuseScbnkTotalesList() {
		return acuseScbnkTotalesList;
	}

	public void setAcuseScbnkTotalesList(
			List<AcuseScbnkTotales> acuseScbnkTotalesList) {
		this.acuseScbnkTotalesList = acuseScbnkTotalesList;
	}

	public String getFolioAcuse() {
		return folioAcuse;
	}

	public void setFolioAcuse(String folioAcuse) {
		this.folioAcuse = folioAcuse;
	}
	

}
