/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import mx.com.adea.security.core.userdetails.UserDetails;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adeamx.adeadms.servicios.RegistroGeneralServicio;
import com.adeamx.scotiabank.guardavalores.lib.beans.ReporteTotalesLectMasiva;
import com.adeamx.scotiabank.guardavalores.lib.beans.SbReporteDocumentosLecM;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScbnkBaseLectura;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaLecturaMasivaService;
import com.adeamx.scotiabank.guardavalores.lib.utils.Constantes;

/**
 * 
 * @author jdavila
 */
@Controller
@Scope("view")
public class ReporteLecturaMasivaBean implements Serializable{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    public final static String TARGET_PATH_DIGITALES = "Digitales";
    private static final Logger log = LoggerFactory.getLogger(ReporteLecturaMasivaBean.class);
    
    @Value("${com.adeamx.security.antivirus.detecting.host}")
    private String antivirusDetectingHost;
    @Value("${com.adeamx.webmx.customer.id}")
    private Long cliente;

    
    JasperReport jasperReport = null;
    JasperPrint jasperPrint = null;
    Map<String, Object> jasperParams = null;
    
    private UserDetails userDetails;
    private ReporteTotalesLectMasiva reporteTotalesLectMasiva;
    private List<ReporteTotalesLectMasiva> reporteTotalesLMBeanList;
    private List<ScbnkBaseLectura> scbnkBaseLecturaList;
    
    private List<SbReporteDocumentosLecM> reporteDocumentosList;
    
    @Autowired
    ScotiaLecturaMasivaService scotiaLecturaMasivaService;    
    @Autowired
    RegistroGeneralServicio registroGeneralServicio;
    

    private Date now;
	private String ubicacionAdeA;
	private String ubicacionScotiabank;
	private ScbnkBaseLectura scbnkBaseLectura;
	

    
    
    @PostConstruct
    public void init(){
        userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();       
        reporteTotalesLMBeanList =new ArrayList<ReporteTotalesLectMasiva>(); 
        now = registroGeneralServicio.getFechaActual();            
        reporteTotalesLectMasiva = new ReporteTotalesLectMasiva();
        reporteDocumentosList =new ArrayList<SbReporteDocumentosLecM>(); 
        
    }

    public void limpiaForm(){     
    	scbnkBaseLecturaList = null;
    	reporteTotalesLMBeanList = null;
    	ubicacionScotiabank = null;
    	scbnkBaseLectura = null;
    }   
  
    public void search() {
    	reporteTotalesLMBeanList =  scotiaLecturaMasivaService.obtieneTotalesByUbicacion(ubicacionScotiabank);
    	scbnkBaseLecturaList = scotiaLecturaMasivaService.obtieneDetalleByUbicacion(ubicacionScotiabank);
    }    
    
    @ResponseBody
    public void exportPdfCartaDetalle() {  
    	
        try {
        	FacesContext context = FacesContext.getCurrentInstance();
        	HttpServletResponse response = (HttpServletResponse)context.getExternalContext().getResponse();
        	
            JasperReport jr = JasperCompileManager.compileReport(Thread.currentThread().getContextClassLoader().getResourceAsStream("reports/ReporteTotalesIncidencias.jrxml"));
            JRBeanCollectionDataSource beanCollectionDataSource= new JRBeanCollectionDataSource(scbnkBaseLecturaList);
            
            Map<String, Object> parametros = new HashMap<String, Object>();

            parametros.put("ubicacionScotia", ubicacionScotiabank);
            parametros.put("ubicacionAdea", ubicacionAdeA);     
            parametros.put("localizacion", reporteTotalesLMBeanList.get(0).getLocalizacion());
            parametros.put("folio", "0000000001");
            parametros.put("usuarioLectura", reporteTotalesLMBeanList.get(0).getUsuarioLectura());
            parametros.put("fechaLectura", reporteTotalesLMBeanList.get(0).getFechaLectura());
            // TODO
            //realizamos el for para los demas parametros
            for(ReporteTotalesLectMasiva dataTotales : reporteTotalesLMBeanList){
            	//Conciliados
            	if((dataTotales.getTipoCredito()).equals(Constantes.C_AUTO)){
            		parametros.put("conciliadoAuto",dataTotales.getConciliados());
                	parametros.put("sobranteAuto", dataTotales.getSobrantes());
                	parametros.put("faltanteAuto", dataTotales.getFaltantes());
            	}else if((dataTotales.getTipoCredito()).equals(Constantes.C_HIPOTECARIO)){
            		parametros.put("conciliadoHipo",dataTotales.getConciliados());
                	parametros.put("sobranteHipo", dataTotales.getSobrantes());
                	parametros.put("faltanteHipo", dataTotales.getFaltantes());
            	}else if((dataTotales.getTipoCredito()).equals(Constantes.C_PERSONAL)){
            		parametros.put("conciliadoPersonal",dataTotales.getConciliados());
                	parametros.put("sobrantePersonal", dataTotales.getSobrantes());
                	parametros.put("faltantePersonal", dataTotales.getFaltantes());
            	}else if((dataTotales.getTipoCredito()).equals(Constantes.C_RRHH)){
            		parametros.put("conciliadoRH",dataTotales.getConciliados());
                	parametros.put("sobranteRH", dataTotales.getSobrantes());
                	parametros.put("faltanteRH", dataTotales.getFaltantes());
            	}
            }
            
            byte[] fichero = JasperRunManager.runReportToPdf(jr, parametros, beanCollectionDataSource);
            ServletOutputStream outputStream = response.getOutputStream();
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=\"AcuseValija" + ".pdf\"");
            outputStream.write(fichero);
            outputStream.flush();
            outputStream.close();
            
        } catch (Exception ex) {
        	ex.printStackTrace();
        }
        FacesContext.getCurrentInstance().responseComplete();
    }
    
    
    public void doctosByNunicodoc(){ 
    	
    	reporteDocumentosList =  scotiaLecturaMasivaService.getReporteDoctosConciliados(scbnkBaseLectura.getScbnkBaseLecturaPk().getNunicodoc(),scbnkBaseLectura.getScbnkBaseLecturaPk().getTipoCredito() );
    }   
    


	/**
      * MENSAJES 
      * @param summary
      * @param detail
      */
    
    public void addMessageInfo(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public void addMessageError(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public void addMessageWarning(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }



    public Date getNow() {
        return now;
    }

    public void setNow(Date now) {
        this.now = now;
    }

	public String getUbicacionAdeA() {
		return ubicacionAdeA;
	}

	public void setUbicacionAdeA(String ubicacionAdeA) {
		this.ubicacionAdeA = ubicacionAdeA;
	}

	public List<ScbnkBaseLectura> getScbnkBaseLecturaList() {
		return scbnkBaseLecturaList;
	}

	public void setScbnkBaseLecturaList(List<ScbnkBaseLectura> scbnkBaseLecturaList) {
		this.scbnkBaseLecturaList = scbnkBaseLecturaList;
	}

	public String getUbicacionScotiabank() {
		return ubicacionScotiabank;
	}

	public void setUbicacionScotiabank(String ubicacionScotiabank) {
		this.ubicacionScotiabank = ubicacionScotiabank;
	}

	public ReporteTotalesLectMasiva getReporteTotalesLMBean() {
		return reporteTotalesLectMasiva;
	}

	public void setReporteTotalesLMBean(ReporteTotalesLectMasiva reporteTotalesLectMasiva) {
		this.reporteTotalesLectMasiva = reporteTotalesLectMasiva;
	}

	public List<ReporteTotalesLectMasiva> getReporteTotalesLMBeanList() {
		return reporteTotalesLMBeanList;
	}

	public void setReporteTotalesLMBeanList(
			List<ReporteTotalesLectMasiva> reporteTotalesLMBeanList) {
		this.reporteTotalesLMBeanList = reporteTotalesLMBeanList;
	}
	
    public List<SbReporteDocumentosLecM> getReporteDocumentosList() {
		return reporteDocumentosList;
	}

	public void setReporteDocumentosList(
			List<SbReporteDocumentosLecM> reporteDocumentosList) {
		this.reporteDocumentosList = reporteDocumentosList;
	}

	public ScbnkBaseLectura getScbnkBaseLectura() {
		return scbnkBaseLectura;
	}

	public void setScbnkBaseLectura(ScbnkBaseLectura scbnkBaseLectura) {
		this.scbnkBaseLectura = scbnkBaseLectura;
	}
	

}
