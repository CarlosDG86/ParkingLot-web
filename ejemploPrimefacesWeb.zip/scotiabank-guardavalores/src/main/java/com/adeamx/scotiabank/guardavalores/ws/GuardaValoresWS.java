package com.adeamx.scotiabank.guardavalores.ws;

import java.util.Date;
import java.util.List;

import javax.jws.WebParam;
import javax.jws.WebService;

import com.adeamx.adeadms.excepciones.ServicioException;
import com.adeamx.scotiabank.guardavalores.lib.beans.SbControlUbicacion;
import com.adeamx.scotiabank.guardavalores.lib.beans.SbControlUbicacionDocum;
import com.adeamx.scotiabank.guardavalores.lib.pojos.UbicaPorDocumento;
/**
 * @author oplata
 *
 */
@WebService
public interface GuardaValoresWS {

    public String hello(@WebParam(name = "name") String txt);

    public String hello2(@WebParam(name = "name") String txt)
            throws ServicioException;
    
    /**
     * Realizar el control de ubicaciones a nivel documento
     * @param ubicaciones
     * @param usuario
     * @return
     * @throws ServicioException 
     */
    public List<SbControlUbicacionDocum> controlUbicacionDocum(
            @WebParam(name = "ubicaciones") List<SbControlUbicacionDocum> ubicaciones, @WebParam(name = "usuario") String usuario)
            throws ServicioException;
    
    public List<SbControlUbicacion> controlUbicacion(@WebParam(name = "ubicaciones") List<SbControlUbicacion> ubicaciones,
			@WebParam(name = "usuario") String usuario)
            throws ServicioException;

    public List<SbControlUbicacion> expedientesUbicacion(
            @WebParam(name = "ubicacion") String ubicacion)
            throws ServicioException;
    /**
     * Retorna la lista de documentos pendientes de Ubicar
     * Si existe nunicodoc significa que su Expediente esta ubicado y deberan asignarlo a dicho expediente
     * Si el expediente es nulo, ubicarlo de forma dispersa
     * @param usuario
     * @return 
     */
    public List<UbicaPorDocumento> documentoUbicacion( @WebParam(name = "usuario") String usuario );
    }

