package com.adeamx.scotiabank.guardavalores.ws;


import com.adeadms.core.adea.pojos.ChecklistCap;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.servlet.ServletContext;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import net.codicentro.core.TypeCast;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.adeadms.core.adea.pojos.EtiqDocum;
import com.adeadms.core.adea.pojos.EtiqDocumHn;
import com.adeadms.core.adea.pojos.Horizontalca;
import com.adeamx.adeadms.excepciones.ServicioException;
import com.adeamx.adeadms.servicios.CapturaGeneralServicio;
import com.adeamx.adeadms.servicios.RegistroGeneralServicio;
import com.adeamx.scotiabank.guardavalores.lib.beans.SbControlUbicacion;
import com.adeamx.scotiabank.guardavalores.lib.beans.SbControlUbicacionDocum;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbControlUbicaciones;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbControlUbicacionesDocum;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScbnkBaseLectura;
import com.adeamx.scotiabank.guardavalores.lib.pojos.UbicaPorDocumento;
import com.adeamx.scotiabank.guardavalores.lib.services.ControlUbicacionWSService;
import com.adeamx.scotiabank.guardavalores.web.sp.UbicacionPorDocumentoSP;
import mx.com.adea.security.services.AuthenticationService;

/**
 * @author oplata
 *
 */
@WebService(serviceName = "GuardaValoresService", endpointInterface = "com.adeamx.scotiabank.guardavalores.ws.GuardaValoresWS")
public class GuardaValoresWSImpl implements GuardaValoresWS {

    private static final Logger logger = LoggerFactory
            .getLogger(GuardaValoresWS.class);
    @Resource
    public WebServiceContext wsContext;
    private Boolean initialized = false;
    private EtiqDocum  etq = null;
    private ScbnkBaseLectura datosBDScotia=null;
    private Horizontalca horizontal=null;
    /**
     * Services
     */

    private AuthenticationService accesoServicio;
    @Autowired
    ControlUbicacionWSService service;
    @Autowired
    UbicacionPorDocumentoSP ubicacionDocumentoSp;
    
    @Autowired
    RegistroGeneralServicio registroGeneralServicio;
    @Autowired
    CapturaGeneralServicio capturaGeneralServicio;

    private void init() {
        if (!initialized) {
            ServletContext sc = (ServletContext) wsContext.getMessageContext()
                    .get(MessageContext.SERVLET_CONTEXT);
            WebApplicationContext wac = WebApplicationContextUtils
                    .getRequiredWebApplicationContext(sc);
            accesoServicio = wac.getBean(AuthenticationService.class);
    //        service = wac.getBean(WSService.class);
            service = wac.getBean(ControlUbicacionWSService.class);
            registroGeneralServicio = wac.getBean(RegistroGeneralServicio.class);
            initialized = true;
        }
    }

    @Override
    public String hello(String txt) {
        return "Hello " + txt + " !";
    }

    @Override
    public String hello2(String txt) throws ServicioException {
        throw new ServicioException("Hello " + txt + " !");
    }
    
    @SuppressWarnings({"unused", "null"})
    @Override
    public List<SbControlUbicacionDocum> controlUbicacionDocum(
            @WebParam(name = "ubicaciones") List<SbControlUbicacionDocum> ubicaciones, @WebParam(name = "usuario") String usuario)
            throws ServicioException {
        init();
        System.out.println("PASO 1: " + usuario );
        System.out.println("PASO 2: " + ubicaciones.size() );
        for (SbControlUbicacionDocum ubicacion : ubicaciones) {
            EtiqDocumHn etqHn = null;
            datosBDScotia = null;
            horizontal = null;
            
            System.out.println("PASO 3: " + ubicacion.toString() );
            if( service.validaUbicAdeaDocum(ubicacion, horizontal) ){
////                ScbnkBaseLectura datosBDScotia = null;
                ChecklistCap checklistCap = capturaGeneralServicio.getChecklistCap( new Long( ubicacion.getEtiquetaTAdeA().replace("T", "") ) );
                if( checklistCap == null ){
                    ubicacion.setDescripcion( "EL DOCUMENTO QUE DESEAS INGRESAR NO TIENE CAPTURA." );
                }else if (service.validaEtiquetaAdea(ubicacion, etqHn)) {
////                    ScbnkBaseLectura ubicOrigScotia = service.getDatosRecallByUbicacionAdea(ubicacion.getUbicacionAdeA());
                    etqHn = service.getEtiquetaT( TypeCast.toLong(ubicacion.getEtiquetaTAdeA().replace("T", "")));
                    etqHn.setEstadoUbicacion("ETN");
                    
                    horizontal = service.getUbicacionHz(ubicacion.getUbicacionAdeA());
                    
                    SbControlUbicacionesDocum ubicDocum = new SbControlUbicacionesDocum();
                    ubicDocum.setFecha(registroGeneralServicio.getFechaActual());
                    ubicDocum.setNunicodoct(etqHn.getNunicodoc());
                    ubicDocum.setNunicodoc( checklistCap.getNunicodoc() );
                    ubicDocum.setUbicAdea( new Long(horizontal.getHzNunico()));
////                    ubicDocum.setUbicAdeaAnterior(datosBDScotia != null ? new Long(datosBDScotia.getHzNunico()) : null);
                    ubicDocum.setUsuario(usuario);
                    ubicDocum.setTipoUbicac( 1l );
                    System.out.println("PASO 4: " + etqHn.toString() );
                    System.out.println("PASO 5: " + ubicDocum.toString() );
                    service.actualizaEstadoEtiqDocum(etqHn, ubicDocum);
                    ubicacion.setUbicado(true);
                }
            }
            
            System.out.println("PASO 6: " + ubicacion.toString() );
        }
        System.out.println("PASO 7: " + ubicaciones.size() );
        return ubicaciones;
    }
    
    @SuppressWarnings({"unused", "null"})
    @Override
    public List<SbControlUbicacion> controlUbicacion(
            @WebParam(name = "ubicaciones") List<SbControlUbicacion> ubicaciones, @WebParam(name = "usuario") String usuario)
            throws ServicioException {
        init();
        for (SbControlUbicacion ubicacion : ubicaciones) {

            etq = null;
            datosBDScotia = null;
            horizontal = null;

            if (validaUbicAdea(ubicacion)) {
                
                etq = null;
                if (validaEtiquetaAdea(ubicacion)) {

                    ScbnkBaseLectura ubicOrigScotia = service.getDatosRecallByUbicacionAdea(ubicacion.getUbicacionAdeA());
                    etq.setEstadoUbicacion("ETN");

                    SbControlUbicaciones sbControlUbicaciones = new SbControlUbicaciones();
                    sbControlUbicaciones.setFecha(registroGeneralServicio.getFechaActual());
                    sbControlUbicaciones.setNunicodoc(etq.getnUnicoDoc());
                    sbControlUbicaciones.setUbicAdeaActual(horizontal.getHzNunico().toString());
                    sbControlUbicaciones.setUbicScotiaActual(ubicOrigScotia != null ? ubicOrigScotia.getUbicacionRealRecall() : null);
                    sbControlUbicaciones.setUbicAdeaAnterior(datosBDScotia != null ? datosBDScotia.getHzNunico().toString() : null);
                    sbControlUbicaciones.setUbicScotiaAnterior(datosBDScotia != null ? datosBDScotia.getUbicacionRealRecall() : null);
                    sbControlUbicaciones.setUsuario(usuario);

                    if (datosBDScotia != null) {
                        datosBDScotia.setUbicacionAdea(ubicacion.getUbicacionAdeA());
                        datosBDScotia.setHzNunico(horizontal.getHzNunico());
                        datosBDScotia.setUbicacionRealRecall(ubicOrigScotia != null ? ubicOrigScotia.getUbicacionRealRecall() : null);
                    }

                    service.actualizaEstadoEtiq(etq, datosBDScotia, sbControlUbicaciones);
                    ubicacion.setUbicado(true);
                }
            }
        }

        return ubicaciones;
    }

    @Override
    public List<SbControlUbicacion> expedientesUbicacion(
            @WebParam(name = "ubicacion") String ubicacion)
            throws ServicioException {
        init();

        return service.getExpedientesUbic(ubicacion);

    }

    @Override
    public List<UbicaPorDocumento> documentoUbicacion( @WebParam(name = "usuario") String usuario ){
        return ubicacionDocumentoSp.getDatos();
    }
    
    private  boolean validaUbicAdea(SbControlUbicacion ubicacion){

    	try {   
    		
            if (ubicacion.getUbicacionAdeA().startsWith("C") && TypeCast.toInt(ubicacion.getUbicacionAdeA().substring(1, 3)) > -1 && TypeCast.toInt(ubicacion.getUbicacionAdeA().substring(5)) > -1 && ubicacion.getUbicacionAdeA().length() == 13){
            	horizontal = service.getUbicacionHz(ubicacion.getUbicacionAdeA());
            	if(horizontal == null){
            		ubicacion.setUbicado(false);
            		ubicacion.setDescripcion("NO EXISTE LA UBICACION ADEA REGISTRADA");
            		return false;
            	}  
            }else{
        		ubicacion.setUbicado(false);
        		ubicacion.setDescripcion("LECTURA ERRONEA DE LA UBICACIÓN ADEA.");
        		return false;
            }
            return true;

        } catch (Exception ex) {
    		ubicacion.setDescripcion(ex.getMessage());
    		return false;
        }
    }

    private boolean validaEtiquetaAdea(SbControlUbicacion ubicacion) {

        try {

            if (StringUtils.isNotEmpty(ubicacion.getEtiquetaAdeA())
                    && !Pattern.matches("U\\d{10}", ubicacion.getEtiquetaAdeA())) {
                ubicacion.setUbicado(false);
                ubicacion.setDescripcion("LECTURA ERRONEA DE LA ETIQUETA ADEA.");
                return false;
            } else {
                // validamos etiq docum
                etq = service.getEtiquetaU(TypeCast.toLong(ubicacion.getEtiquetaAdeA().replace("U", "")));
                if (etq == null) {
                    ubicacion.setUbicado(false);
                    ubicacion.setDescripcion("LA ETIQUETA ADEA NO EXISTE PARA ESTE CLIENTE");
                    return false;
                }

                datosBDScotia = service.getDatosRecallByNunicodoc(etq.getnUnicoDoc());
                if (datosBDScotia == null) {

                    if (!service.validaCabeceraDoc(etq.getnUnicoDoc())) {
                        ubicacion.setUbicado(false);
                        ubicacion.setDescripcion("NO SE ENCUENTRA REGISTRO DE UBICACION PARA LA ETIQUETA ADEA:"
                                + etq.getnUnicoDoc());
                        return false;
                    }
                } else {
                    return true;
                }
                return true;
            }
        } catch (Exception ex) {
            ubicacion.setDescripcion(ex.getMessage());
            return false;
        }
    }

    

}