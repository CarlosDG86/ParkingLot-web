/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import com.adeadms.core.adea.pojos.CabeceraDoc;
import com.adeadms.core.adea.pojos.Caja;
import java.io.Serializable;
import java.util.Date;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import mx.com.adea.security.core.userdetails.UserDetails;
import net.codicentro.core.TypeCast;

import org.apache.commons.lang.StringUtils;
import org.primefaces.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.adeadms.core.adea.pojos.EtiqDocum;
import com.adeadms.core.adea.pojos.Horizontalca;
import com.adeamx.adeadms.servicios.RegistroGeneralServicio;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbControlUbicaciones;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbTrasvase;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScbnkBaseLectura;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaLecturaMasivaService;
import com.adeamx.scotiabank.guardavalores.lib.utils.Constantes;
import java.util.ArrayList;
import java.util.List;
import org.primefaces.event.SelectEvent;

/**
 *
 * @author jdavila
 */
@Controller
@Scope("view")
public class TrasvaseBean implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    public final static String TARGET_PATH_DIGITALES = "Digitales";
    private static final Logger log = LoggerFactory.getLogger(TrasvaseBean.class);

    @Value("${com.adeamx.webmx.customer.id}")
    private Long cliente;

    private UserDetails userDetails;

    @Autowired
    ScotiaLecturaMasivaService scotiaLecturaMasivaService;
    @Autowired
    RegistroGeneralServicio registroGeneralServicio;

    private Date now;
    private SbTrasvase datosTrasvase;
    private String cajaStr;
    private String expedienteStr;
    private List<SbTrasvase> trasvaseList;
    private boolean cajaReadOnly;
    

    @PostConstruct
    public void init() {
        userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        now = registroGeneralServicio.getFechaActual();
        datosTrasvase = new SbTrasvase();
        trasvaseList = new ArrayList<SbTrasvase>();
        cajaReadOnly = false;
    }

    public void validaCaja() {
        RequestContext requestContext = RequestContext.getCurrentInstance();
        try {

            if (StringUtils.isNotEmpty(cajaStr)
                    && !Pattern.matches("S\\d{8}", cajaStr)) {
                throw new Exception("LECTURA ERRONEA DE LA ETIQUETA ADEA.");
            }
            // Valida Existencia de la caja
            Caja caja = registroGeneralServicio.getCaja(TypeCast.toLong(cajaStr.replace("S", "")));
            if (caja == null) {
                throw new Exception("LA CAJA NO EXISTE.");
            } else if (!caja.getCliente().equals(Constantes.CLIENTE_SRT)) {
                throw new Exception("LA CAJA NO PERTENECE A ESTE CLIENTE.");
            } else {
                datosTrasvase.setCajaDestino(TypeCast.toLong(cajaStr.replace("S", "")));
                cajaReadOnly= true;
            }

        } catch (Exception ex) {
            addMessageError("Error!", ex.getMessage());
            cajaStr = null;
            requestContext.execute("document.getElementById('form:fluidGrid:caja').focus()");
        }
    }

    public void validaEtiquetaAdea() {        
        try {

            if (StringUtils.isNotEmpty(expedienteStr)
                    && !Pattern.matches("U\\d{10}", expedienteStr)) {
                addMessageError("Error!",
                        "LECTURA ERRONEA DE LA ETIQUETA ADEA.");
            } else {
                //Validamos si se encuentra en la lista de lecturas
                for (SbTrasvase iter : trasvaseList) {
                    Long nunicolst = iter.getNunicodoc();
                    Long nunicoLeido = TypeCast.toLong(expedienteStr.replace("U", ""));
                    if (nunicolst.compareTo(nunicoLeido) == 0) {
                         throw new Exception(
                            "LA ETIQUETA " + expedienteStr + " YA CUENTA CON REGISTRO DE SALIDA");
                    }
                }      
                
                // validamos etiq docum
                EtiqDocum etq = scotiaLecturaMasivaService.getEtiquetaU(TypeCast.toLong(expedienteStr.replace("U", "")));
                if (etq == null) {
                    throw new Exception(
                            "LA ETIQUETA ADEA NO EXISTE PARA ESTE CLIENTE");
                } else if (etq.getEstadoUbicacion() != null ) {
                    if (etq.getEstadoUbicacion().equals("ETA"))
                        throw new Exception(
                            "LA ETIQUETA ADEA YA SE ENCUENTRA EN ESTADO 'ETA'.");
                }

                SbTrasvase sbTrasvase = scotiaLecturaMasivaService.getEtiquetaTrasvase(etq.getnUnicoDoc());

                if (sbTrasvase != null) {
                    throw new Exception(
                            "LA ETIQUETA " + etq.getnUnicoDoc() + " YA CUENTA CON REGISTRO DE SALIDA");
                } else {
                    //Validamos captura
                    

                    if (scotiaLecturaMasivaService.getExpedienteCapturado(etq.getnUnicoDoc())) {
                        //Llenamos bean para guarda en la lista
                        datosTrasvase.setCajaOrigen(scotiaLecturaMasivaService.getCajaCaptura(etq.getnUnicoDoc()));
                        datosTrasvase.setFecha(now);
                        datosTrasvase.setTipo("");
                        datosTrasvase.setEstatus('C');
                        datosTrasvase.setNunicodoc(etq.getnUnicoDoc());
                        datosTrasvase.setUsuario(userDetails.getUser().getLogin());

//                        scotiaLecturaMasivaService.saveRegistroTrasvase(datosTrasvase);
                        trasvaseList.add(datosTrasvase);
                        expedienteStr = null;
                        
                    }else{
                       throw new Exception(
                            "LA ETIQUETA " + etq.getnUnicoDoc() + " NO SE ENCUENTRA CAPTURADA."); 
                    }
                    
                    datosTrasvase = new SbTrasvase();
                    datosTrasvase.setCajaDestino(TypeCast.toLong(cajaStr.replace("S", "")));
                }

            }
        } catch (Exception ex) {
            ex.printStackTrace();
            expedienteStr = null;
            addMessageError("Error!", ex.getMessage());
        }
    }

    

    public void limpiaForm() {
        datosTrasvase = new SbTrasvase();
        cajaStr = null;
        expedienteStr = null;
        cajaReadOnly = false;
        trasvaseList = new ArrayList<SbTrasvase>();
    }

    public void cerrarUbicacion() {
        try {
            if (trasvaseList.isEmpty()) {
                throw new Exception(
                        "DEBE INGRESAR AL MENOS UN REGISTRO");
            }
            if (cajaStr == null) {
                throw new Exception(
                        "DEBE INGRESAR UNA CAJA");
            }

            //ACTUALIZAMOS ESTATUS DE LOS EXPEDIENTES y CIERRA CAJA
            scotiaLecturaMasivaService.actualizaEstatusExpTrasvase(trasvaseList);
            
            limpiaForm();
            addMessageInfo("Alerta!", "SE HAN GUARDADO LOS CAMBIOS, CORRECTAMENTE.");
        } catch (Exception ex) {
            addMessageError("Error!", ex.getMessage());
        }
    }
    
    public void eliminaRegistro(
//            SelectEvent event
    ){
//        System.out.println(event);
        System.out.println(datosTrasvase);
        if (trasvaseList.remove(datosTrasvase)){
            addMessageInfo("Alerta!", "SE ELIMINADO EL REGISTRO, CORRECTAMENTE.");
        }
        datosTrasvase = new SbTrasvase();
    }

    /**
     * MENSAJES
     *
     * @param summary
     * @param detail
     */
    public void addMessageInfo(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void addMessageError(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void addMessageWarning(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, summary, detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public Date getNow() {
        return now;
    }

    public void setNow(Date now) {
        this.now = now;
    }

    public SbTrasvase getDatosTrasvase() {
        return datosTrasvase;
    }

    public void setDatosTrasvase(SbTrasvase datosTrasvase) {
        this.datosTrasvase = datosTrasvase;
    }

    public String getCajaStr() {
        return cajaStr;
    }

    public void setCajaStr(String cajaStr) {
        this.cajaStr = cajaStr;
    }

    public String getExpedienteStr() {
        return expedienteStr;
    }

    public void setExpedienteStr(String expedienteStr) {
        this.expedienteStr = expedienteStr;
    }

    public List<SbTrasvase> getTrasvaseList() {
        return trasvaseList;
    }

    public void setTrasvaseList(List<SbTrasvase> trasvaseList) {
        this.trasvaseList = trasvaseList;
    }

    public boolean isCajaReadOnly() {
        return cajaReadOnly;
    }

    public void setCajaReadOnly(boolean cajaReadOnly) {
        this.cajaReadOnly = cajaReadOnly;
    }


}
