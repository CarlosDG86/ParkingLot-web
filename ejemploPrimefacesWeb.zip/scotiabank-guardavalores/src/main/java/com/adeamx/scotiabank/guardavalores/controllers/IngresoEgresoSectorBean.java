/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import mx.com.adea.security.core.userdetails.UserDetails;
import net.codicentro.core.TypeCast;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.adeadms.core.adea.pojos.EtiqDocum;
import com.adeamx.adeadms.servicios.RegistroGeneralServicio;
import com.adeamx.scotiabank.guardavalores.lib.pojos.IngresoEgresoSector;
import com.adeamx.scotiabank.guardavalores.lib.pojos.IngresoEgresoSectorPk;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaLecturaMasivaService;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author jdavila
 */
@Controller
@Scope("view")
public class IngresoEgresoSectorBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static String TARGET_PATH_DIGITALES = "Digitales";
	private static final Logger log = LoggerFactory
			.getLogger(IngresoEgresoSectorBean.class);

	@Value("${com.adeamx.security.antivirus.detecting.host}")
	private String antivirusDetectingHost;
	@Value("${com.adeamx.webmx.customer.id}")
	private Long cliente;

	private UserDetails userDetails;

	@Autowired
	ScotiaLecturaMasivaService scotiaLecturaMasivaService;
	@Autowired
	RegistroGeneralServicio registroGeneralServicio;

	private String sector;
	private String tipoMovimiento;
	private String etiquetaAdea;
	private String pEntrega;
	private String pRecibe;
        private List<String> listaEtiquetas;        

	private Date now;
	private EtiqDocum etq;

	@PostConstruct
	public void init() {
		userDetails = (UserDetails) SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();
                listaEtiquetas = new ArrayList<String>();
		now = registroGeneralServicio.getFechaActual();
		sector = null;
		tipoMovimiento = null;
		pEntrega = null;
		pRecibe = null;
		etq = new EtiqDocum();
	}

	public void validaEtiquetaAdea() {
		try {
			if (StringUtils.isNotEmpty(etiquetaAdea)
					&& !Pattern.matches("U\\d{10}", etiquetaAdea)) {
				etiquetaAdea = null;
				throw new Exception("LECTURA ERRONEA DE LA ETIQUETA ADEA.");

			} else {
				// validamos etiq docum
				etq = scotiaLecturaMasivaService.getEtiquetaU(TypeCast
						.toLong(etiquetaAdea.replace("U", "")));
				if (etq == null) {
					etiquetaAdea = null;
					throw new Exception(
							"LA ETIQUETA ADEA NO EXISTE PARA ESTE CLIENTE");
				} else if (etq.getEstadoUbicacion() != null) {
					if (etq.getEstadoUbicacion().equals("ECL")
							|| etq.getEstadoUbicacion().equals("ECR")
							|| etq.getEstadoUbicacion().equals("BD")) {
						etiquetaAdea = null;
						throw new Exception(
								"LA ETIQUETA ADEA SE ENCUENTRA EN CONSULTA.");
					}

				}
                                
                           if(listaEtiquetas.contains(etiquetaAdea)){
                               etiquetaAdea = null;
                               throw new Exception(
								"LA ETIQUETA ADEA YA SE ENCUENTRA EN EL LISTADO.");
                           }     
                                
                          listaEtiquetas.add(etiquetaAdea);
                          etiquetaAdea = "";
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			addMessageError("Error!", ex.getMessage());
		}
	}

	public void limpiaForm() {
		etiquetaAdea = null;
		sector = null;
		tipoMovimiento = null;
		pEntrega = null;
		pRecibe = null;
		etq = new EtiqDocum();
                listaEtiquetas =  new ArrayList<String>();
	}     
        
	public void guardaMovimiento() {
		try {
			if (getSector() == null) {
				throw new Exception("DEBE SELECCIONAR UN SECTOR.");
			}
			if (tipoMovimiento == null) {
				throw new Exception("DEBE SELECCIONAR UN TIPO DEMOVIMIENTO.");
			}                        
                        if(listaEtiquetas == null || listaEtiquetas.isEmpty()){
                            	throw new Exception("DEBE INGRESAR UN NUMERO DE ETIQUETA.");
                        }

			IngresoEgresoSectorPk iEPk = new IngresoEgresoSectorPk();

			iEPk.setFecha(Calendar.getInstance());
			iEPk.setNunicodoc(etq.getnUnicoDoc());
			IngresoEgresoSector iE = new IngresoEgresoSector();
			iE.setMovimiento(TypeCast.toInteger(tipoMovimiento));
			iE.setSector(TypeCast.toInteger(sector));
			iE.setUsuario(userDetails.getUser().getLogin());
			iE.setIngresoEgresoSectorPk(iEPk);
			iE.setpEntrega(pEntrega);
			iE.setpRecibe(pRecibe);
                        
                        for(String etiquetadDato:listaEtiquetas){
                            iEPk.setFecha(Calendar.getInstance());
                            iEPk.setNunicodoc(TypeCast.toLong(etiquetadDato.replace("U", "")));
                            scotiaLecturaMasivaService.guardaMovimientoSector(iE);
                        }
			
			limpiaForm();
			addMessageInfo("Alerta!", "¡REGISTRO GUARDADO CORRECTAMENTE!.");
		} catch (Exception ex) {
			ex.printStackTrace();
			addMessageError("Error!", ex.getMessage());
		}
	}
        
        public void quitaEtiqueta(){
            Map<String,String> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
            String Idfind = params.get("idEtiqueta");
            etiquetaAdea = "";
            listaEtiquetas.remove(Idfind);
        }
        

	/**
	 * MENSAJES
	 * 
	 * @param summary
	 * @param detail
	 */

	public void addMessageInfo(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
				summary, detail);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void addMessageError(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
				summary, detail);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void addMessageWarning(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN,
				summary, detail);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public Date getNow() {
		return now;
	}

	public void setNow(Date now) {
		this.now = now;
	}

	public String getEtiquetaAdea() {
		return etiquetaAdea;
	}

	public void setEtiquetaAdea(String etiquetaAdea) {
		this.etiquetaAdea = etiquetaAdea;
	}

	public EtiqDocum getEtq() {
		return etq;
	}

	public void setEtq(EtiqDocum etq) {
		this.etq = etq;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getTipoMovimiento() {
		return tipoMovimiento;
	}

	public void setTipoMovimiento(String tipoMovimiento) {
		this.tipoMovimiento = tipoMovimiento;
	}

	public String getpEntrega() {
		return pEntrega;
	}

	public void setpEntrega(String pEntrega) {
		this.pEntrega = pEntrega;
	}

	public String getpRecibe() {
		return pRecibe;
	}

	public void setpRecibe(String pRecibe) {
		this.pRecibe = pRecibe;
	}

    public List<String> getListaEtiquetas() {
        return listaEtiquetas;
    }

    public void setListaEtiquetas(List<String> listaEtiquetas) {
        this.listaEtiquetas = listaEtiquetas;
    }
        
        
        

}
