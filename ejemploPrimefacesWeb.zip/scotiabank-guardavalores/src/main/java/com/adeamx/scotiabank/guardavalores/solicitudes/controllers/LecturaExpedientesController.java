package com.adeamx.scotiabank.guardavalores.solicitudes.controllers;

import com.adeamx.dms.libs.consultas.pojos.ScExpedienteSolicitado;
import com.adeamx.dms.libs.consultas.pojos.ScRemito;
import com.adeamx.dms.libs.consultas.pojos.ScSolicitudConsulta;
import com.adeamx.faces.lib.utilerias.MessagesShow;
import com.adeamx.scotiabank.guardavalores.lib.beans.ExpedientesRemitosBean;
import com.adeamx.scotiabank.guardavalores.lib.beans.ReporteUbicacionesBean;
import com.adeamx.scotiabank.guardavalores.lib.pojos.AcuseScbnkTotales;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaSolicitudConsultaService;
import com.adeamx.scotiabank.guardavalores.lib.utils.Constantes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import mx.com.adea.security.core.userdetails.UserDetails;
import net.codicentro.core.TypeCast;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/**
 *
 * @author asalgado
 */
@Component
@Scope("view")
public class LecturaExpedientesController implements Serializable {

    private static final Logger logger = Logger.getLogger(SolicitudesGeneradasController.class.getName());

    public static final int STATUS_SOLICITADO = 1;
    public static final int STATUS_ASIGNADO = 2;
    public static final int STATUS_MESA_TRABAJO = 3;

    @Value("${com.adeamx.webmx.customer.id}")
    private Long scltcod;

    @Autowired
    private ScotiaSolicitudConsultaService consultaService;

    UserDetails userDetails;
    private List<ScSolicitudConsulta> listSolicitudes;
    private ScSolicitudConsulta selectedSolicitud;

    private Long folioSolicitud;

    private Integer cantImagenes = 0;
    private Integer cantCDs = 0;
    private Integer cantFotoCopias = 0;
    private String etiqueta;
    private Integer completo;
    private boolean enableFinalizarLectura;

    private List<Map<String, Object>> listExpPendientes;
    private List<Map<String, Object>> listExpTrabajados;

    private List<Map<String, Object>> listDocsPendientes;
    private List<Map<String, Object>> listDocsTrabajados;

    @PostConstruct
    public void init() {
        userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        listSolicitudes = consultaService.getSolicitudesByStatus(scltcod, STATUS_ASIGNADO);
    }

    public void search() {
        listSolicitudes = consultaService.getSolicitudesByFolioAndStatus(scltcod, folioSolicitud, STATUS_ASIGNADO);
        if (listSolicitudes != null && !listSolicitudes.isEmpty()) {
            selectedSolicitud = listSolicitudes.get(0);
            onSolicitudSelect();
        }
    }

    public void cleanSearch() {
        folioSolicitud = null;
        selectedSolicitud = null;
        setCantImagenes(null) ;
        setCantCDs(null);
        setCantFotoCopias(null);
        listSolicitudes = consultaService.getSolicitudesByStatus(scltcod, STATUS_ASIGNADO);
    }

    public void onSolicitudSelect() {
        etiqueta = null;

        if (selectedSolicitud != null) {
            List<Map<String, Object>> lstExp = consultaService.getEstatusExpedientesByFolio(selectedSolicitud.getFolio());
            List<Map<String, Object>> lstDocs = consultaService.getEstatusDocumentosByFolio(selectedSolicitud.getFolio());

            listExpPendientes = getExpByStatus(lstExp, STATUS_ASIGNADO);
            listExpTrabajados = getExpByStatus(lstExp, STATUS_MESA_TRABAJO);

            listDocsPendientes = getDocsByStatus(lstDocs, STATUS_ASIGNADO);
            listDocsTrabajados = getDocsByStatus(lstDocs, STATUS_MESA_TRABAJO);

//            Map<String, Object> totExpedientes = consultaService.getTotalesExpedientesByFolio(selectedSolicitud.getFolio());
//            Integer totExpSolicitados = TypeCast.toInteger(totExpedientes.get("TOTAL"));
//            Integer totExpLeidosMT = TypeCast.toInteger(totExpedientes.get("LEIDOS_MT"));
//
//            Map<String, Object> totDocumentos = consultaService.getTotalesDocumentosByFolio(selectedSolicitud.getFolio());
//            Integer totDocSolicitados = TypeCast.toInteger(totDocumentos.get("TOTAL"));
//            Integer totDocLeidosMT = TypeCast.toInteger(totDocumentos.get("LEIDOS_MT"));
//
//            if ((totExpSolicitados.compareTo(totExpLeidosMT) == 0) && (totDocSolicitados.compareTo(totDocLeidosMT) == 0)) {
//                enableFinalizarLectura = true;
//            }
            List<ScExpedienteSolicitado> lst = consultaService.getExpedientesSolicitados(selectedSolicitud.getFolio());
            if(lst != null && !lst.isEmpty()){
                for(ScExpedienteSolicitado expSol : lst){
                    completo = expSol.getCompleto();
                    break;
                }
            }
            if(completo != null && completo.equals(0)){
                removeExpSinDocs();
            }
        }
    }

    private List<Map<String, Object>> getExpByStatus(List<Map<String, Object>> lstExp, int status) {
        List<Map<String, Object>> lstRsp = new ArrayList<Map<String, Object>>();
        for (Map<String, Object> object : lstExp) {
            int stExp = TypeCast.toInteger(object.get("STATUS"));
            if (stExp == status) {
                lstRsp.add(object);
            }
        }
        return lstRsp;
    }

    private List<Map<String, Object>> getDocsByStatus(List<Map<String, Object>> lstDocs, int status) {
        List<Map<String, Object>> lstRsp = new ArrayList<Map<String, Object>>();
        for (Map<String, Object> object : lstDocs) {
            int stDoc = TypeCast.toInteger(object.get("STATUS"));
            if (stDoc == status) {
                lstRsp.add(object);
            }
        }
        return lstRsp;
    }

    public void lecturaEtiqueta() {
        if(etiqueta != null && !etiqueta.trim().isEmpty()){
            char tipo = etiqueta.charAt(0);
            int index = 0;
            Long folio = null;
            Long nunicodoc = null;
            Long nunicodoct = null;
            Long doccod = null;

            if(tipo == 'U' && completo.equals(0)){
                MessagesShow.showMessageError("SÓLO SE PERMITEN LEER DOCUMENTOS");
                return;
            }
            try {
                switch (tipo) {
//            case 'S':
//                if (!Pattern.matches("S\\d{8}", etiqueta)) {
//                    MessagesShow.showMessageError("EL FORMATO DE LA ETIQUETA NO ES VALIDO.");
//                    return;
//                }
//                break;
                    case 'U':
                        if (!Pattern.matches("U\\d{10}", etiqueta)) {
                            MessagesShow.showMessageError("EL FORMATO DE LA ETIQUETA NO ES VALIDO.");
                            return;
                        }
                        nunicodoc = TypeCast.toLong(etiqueta.substring(1));
                        index = findExpDisponible(listExpPendientes, nunicodoc);
                        if (index == -1) {
                            MessagesShow.showMessageError("LA ETIQUETA NO SE ENCUENTRA EN ESTA SOLICITUD O TIENE UN ESTATUS INVÁLIDO.");
                            return;
                        }

                        Map<String, Object> mpExp = listExpPendientes.get(index);
                        folio = TypeCast.toLong(mpExp.get("FOLIO"));
                        nunicodoc = TypeCast.toLong(mpExp.get("NUNICODOC"));
                        consultaService.lecturaMTExpediente(folio, nunicodoc, userDetails.getUsername());
                        onSolicitudSelect();
                        break;

                    case 'T':
                        if (!Pattern.matches("T\\d{11}", etiqueta)) {
                            MessagesShow.showMessageError("EL FORMATO DE LA ETIQUETA NO ES VALIDO.");
                            return;
                        }
                        nunicodoct = TypeCast.toLong(etiqueta.substring(1));
                        index = findDocDisponible(listDocsPendientes, nunicodoct);
                        if (index == -1) {
                            MessagesShow.showMessageError("LA ETIQUETA NO SE ENCUENTRA EN ESTA SOLICITUD O TIENE UN ESTATUS INVÁLIDO.");
                            return;
                        }

                        Map<String, Object> mpDoc = listDocsPendientes.get(index);
                        folio = TypeCast.toLong(mpDoc.get("FOLIO"));
                        nunicodoc = TypeCast.toLong(mpDoc.get("NUNICODOC"));
                        nunicodoct = TypeCast.toLong(mpDoc.get("NUNICODOCT"));
                        doccod = TypeCast.toLong(mpDoc.get("DOCCOD"));
                        consultaService.lecturaMTDocumento(folio, nunicodoc, nunicodoct, doccod, userDetails.getUsername());
                        onSolicitudSelect();

                        break;
                    default:
                        MessagesShow.showMessageError("EL FORMATO DE LA ETIQUETA NO ES VALIDO.");
                        return;
                }

                MessagesShow.showMessageInfo("LA OPERACIÓN SE REALIZÓ CORRECTAMENTE.");

            } catch (Exception ex) {
                logger.log(Level.SEVERE, null, ex);
                MessagesShow.showMessageErrorBackEnd("Ocurrió un error al asignar la solicitud: <br /> " + ex.getMessage());
            }
        }
    }

    public void generarRemito() {
        try {

             Integer cantImag = new Integer(getCantImagenes());
                Integer cantCDs = new Integer(getCantCDs());
                Integer cantFotocopias = new Integer(getCantFotoCopias());
            // Validar que no existan etiquetas pendientes de lectura.
            if ((listExpPendientes != null && listExpPendientes.isEmpty()) && (listDocsPendientes != null && listDocsPendientes.isEmpty())) {
                ScRemito scRemito = consultaService.finalizarLecturaMT(selectedSolicitud.getFolio(), listExpTrabajados, listDocsTrabajados, null, userDetails.getUsername(),cantImag, cantCDs, cantFotocopias);
                List<Map<String, Object>> lstExp = null;
                String tipo = "NUNICODOC";
               
                if(completo.equals(0)){
                    lstExp = consultaService.getEstatusDocumentosByFolio(selectedSolicitud.getFolio());
                    tipo = "NUNICODOCT";
                } else {
                    lstExp = consultaService.getEstatusExpedientesByFolio(selectedSolicitud.getFolio());
                }
                               
                
                List<ExpedientesRemitosBean> etiquetasLst = new ArrayList<ExpedientesRemitosBean>();
                
                for (Map<String, Object> object : lstExp) {
                	ExpedientesRemitosBean expedientesRemitosBean = new ExpedientesRemitosBean();
                	StringBuilder msg = new StringBuilder(String.valueOf(object.get(tipo)));
                        if(completo.equals(0)){
                            msg.append(" - ").append(String.valueOf(object.get("DOCDESC")));
                        }
                        expedientesRemitosBean.setEtiqueta(msg.toString());
                	expedientesRemitosBean.setDetalle("FOLIO CONSULTA: "+String.valueOf(object.get("FOLIO")));
                	etiquetasLst.add(expedientesRemitosBean);
                }
                
                
                //TODO Agregar la GENERACION DEL ACUSE
                
                FacesContext context = FacesContext.getCurrentInstance();
			
                    HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
        				
        				JasperReport jr = JasperCompileManager.compileReport(Thread.currentThread().getContextClassLoader()
        						.getResourceAsStream("reports/ReporteRemitos.jrxml"));
        				
        				JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(etiquetasLst);

        				Map<String, Object> parametros = new HashMap<String, Object>();
        	
        				parametros.put("idRemito", scRemito.getNoRemito());
        				parametros.put("cliente", selectedSolicitud.getCliente().getAcltrzsc());
        				parametros.put("autorizo", selectedSolicitud.getScReceptor().getNombre());
        				parametros.put("tipo", selectedSolicitud.getScTipoConsulta().getDescripcion());
        				parametros.put("area", selectedSolicitud.getScCc().getDescripcion());
        				parametros.put("cCosto", selectedSolicitud.getScCc().getScCentroCostoPk().getIdCC());
        				parametros.put("domicilio", selectedSolicitud.getScReceptor().getDomicilio());
        				parametros.put("fecha", scRemito.getFecha());
        				parametros.put("receptor", selectedSolicitud.getScReceptor().getNombre());
        				parametros.put("remitente", selectedSolicitud.getScSolicitante().getNombre());
        				parametros.put("folioCliente", scRemito.getFolioCliente());
        				parametros.put("idTipoEnvio", scRemito.getIdTipoEnvio());
        				parametros.put("observaciones", selectedSolicitud.getObservaciones());
        				
        				parametros.put("cantidadImagenes", scRemito.getCantidadImagenes());
        				parametros.put("cantidadFotocopias", scRemito.getCantidadFotocopias());
        				parametros.put("cantidadCd", scRemito.getCantidadCd());
        				
        				parametros.put("folio", selectedSolicitud.getFolio());
        				parametros.put("totalExpedientes", lstExp.size());
                                        
        				parametros.put("enviados", tipo.equals("NUNICODOCT")?"DOCUMENTOS ENVIADOS":"EXPEDIENTES ENVIADOS");
                                        parametros.put("numero", tipo.equals("NUNICODOCT")?"Número De Documentos:":"Número De Expedientes:");
        				

        				
        				byte[] fichero = JasperRunManager.runReportToPdf(jr,parametros, beanCollectionDataSource);
        				ServletOutputStream outputStream = response.getOutputStream();
        				response.setContentType("application/octet-stream");
        				response.setHeader("Content-Disposition","attachment; filename=\"Acuse_"+scRemito.getNoRemito()+ ".pdf\"");
        				outputStream.write(fichero);
        				outputStream.flush();
        				outputStream.close();
        				
        		        context.renderResponse();
        	            context.responseComplete();	
        				
                
                
        	            cleanSearch();
//                MessagesShow.showMessageInfoBackEnd("LA OPERACIÃ“N SE REALIZÃ“ CORRECTAMENTE. <br /> Remito generado: " + scRemito.getIdRemito());

            } else {
                MessagesShow.showMessageErrorBackEnd("Existen etiquetas pendientes de lectura");
            }

        } catch (Exception ex) {
            logger.log(Level.SEVERE, null, ex);
            MessagesShow.showMessageErrorBackEnd("Ocurrió un error al asignar la solicitud: <br /> " + ex.getMessage());
        }
        
    }

    private int findExpDisponible(List<Map<String, Object>> expPendientes, Long nunicodoc) {
        int index = 0;
        for (Map<String, Object> mpExp : expPendientes) {
            Long nunicoExp = TypeCast.toLong(mpExp.get("NUNICODOC"));
            if (nunicoExp.compareTo(nunicodoc) == 0) {
                return index;
            }
            index++;
        }
        return -1;
    }

    private int findDocDisponible(List<Map<String, Object>> docsPendientes, Long nunicodoct) {
        int index = 0;
        for (Map<String, Object> mpExp : docsPendientes) {
            Long nunicoDoc = TypeCast.toLong(mpExp.get("NUNICODOCT"));
            if (nunicoDoc.compareTo(nunicodoct) == 0) {
                return index;
            }
            index++;
        }
        return -1;
    }
    
    private void removeExpSinDocs(){ 
        if(listDocsTrabajados != null && !listDocsTrabajados.isEmpty() && (listDocsPendientes == null || listDocsPendientes.isEmpty())){
            listExpPendientes = new ArrayList<Map<String, Object>>();
        } else {
            Long nunicoRmv = 0l;
            for (Map<String, Object> mpDocT : listDocsTrabajados) {
                Long nunicoDocT = TypeCast.toLong(mpDocT.get("NUNICODOC"));
                if(listDocsPendientes != null && !listDocsPendientes.isEmpty()){
                    for (Map<String, Object> mpDocP : listDocsPendientes) {
                        Long nunicoDocP = TypeCast.toLong(mpDocP.get("NUNICODOC"));
                        if (nunicoDocT.compareTo(nunicoDocP) == 0) {
                            nunicoRmv = 0l;
                            break;
                        } else {
                            nunicoRmv = nunicoDocT;                    
                        }
                    }
                } else {
                    nunicoRmv = nunicoDocT;
                }
                if(nunicoRmv != 0l){
                    Map<String, Object> mp = new HashMap<String, Object>();
                    for (Map<String, Object> mpExp : listExpPendientes) {
                        Long nunicoExp = TypeCast.toLong(mpExp.get("NUNICODOC"));
                        if(nunicoRmv.equals(nunicoExp)){
                            mp = mpExp;
                            break;
                        }
                    }
                    listExpPendientes.remove(mp);
                }
            }
        }
    }

    public List<ScSolicitudConsulta> getListSolicitudes() {
        return listSolicitudes;
    }

    public void setListSolicitudes(List<ScSolicitudConsulta> listSolicitudes) {
        this.listSolicitudes = listSolicitudes;
    }

    public ScSolicitudConsulta getSelectedSolicitud() {
        return selectedSolicitud;
    }

    public void setSelectedSolicitud(ScSolicitudConsulta selectedSolicitud) {
        this.selectedSolicitud = selectedSolicitud;
    }

    public Long getFolioSolicitud() {
        return folioSolicitud;
    }

    public void setFolioSolicitud(Long folioSolicitud) {
        this.folioSolicitud = folioSolicitud;
    }

    public List<Map<String, Object>> getListExpPendientes() {
        return listExpPendientes;
    }

    public void setListExpPendientes(List<Map<String, Object>> listExpPendientes) {
        this.listExpPendientes = listExpPendientes;
    }

    public List<Map<String, Object>> getListExpTrabajados() {
        return listExpTrabajados;
    }

    public void setListExpTrabajados(List<Map<String, Object>> listExpTrabajados) {
        this.listExpTrabajados = listExpTrabajados;
    }

    public List<Map<String, Object>> getListDocsPendientes() {
        return listDocsPendientes;
    }

    public void setListDocsPendientes(List<Map<String, Object>> listDocsPendientes) {
        this.listDocsPendientes = listDocsPendientes;
    }

    public Integer getCantImagenes() {
        return cantImagenes;
    }

    public void setCantImagenes(Integer cantImagenes) {
        this.cantImagenes = cantImagenes;
    }

    public Integer getCantCDs() {
        return cantCDs;
    }

    public void setCantCDs(Integer cantCDs) {
        this.cantCDs = cantCDs;
    }

    public Integer getCantFotoCopias() {
        return cantFotoCopias;
    }

    public void setCantFotoCopias(Integer cantFotoCopias) {
        this.cantFotoCopias = cantFotoCopias;
    }

    public List<Map<String, Object>> getListDocsTrabajados() {
        return listDocsTrabajados;
    }

    public void setListDocsTrabajados(List<Map<String, Object>> listDocsTrabajados) {
        this.listDocsTrabajados = listDocsTrabajados;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public boolean isEnableFinalizarLectura() {
        if ((listExpPendientes != null && listExpPendientes.isEmpty()) && (listDocsPendientes != null && listDocsPendientes.isEmpty())) {
            enableFinalizarLectura = true;
        } else {
            enableFinalizarLectura = false;
        }
        return enableFinalizarLectura;
    }

    public void setEnableFinalizarLectura(boolean enableFinalizarLectura) {
        this.enableFinalizarLectura = enableFinalizarLectura;
    }

}
