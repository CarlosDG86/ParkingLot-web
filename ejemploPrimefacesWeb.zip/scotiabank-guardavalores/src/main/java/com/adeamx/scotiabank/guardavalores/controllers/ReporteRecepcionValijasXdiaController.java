/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import com.adeamx.scotiabank.guardavalores.lib.beans.ReporteCertificacionValijaXdiaBean;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import com.adeamx.scotiabank.guardavalores.lib.services.RecepcionService;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * 
 * @author jdavila
 */
@Controller
@Scope("view")
public class ReporteRecepcionValijasXdiaController implements Serializable{
    
    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    private static final Logger log = LoggerFactory.getLogger(ReporteRecepcionValijasXdiaController.class);
    
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    
    JasperReport jasperReport = null;
    JasperPrint jasperPrint = null;
    Map<String, Object> jasperParams = null;
    
    
    private List<ReporteCertificacionValijaXdiaBean> valijasList;
    private Date fecIni;
    private String fecFin;
    
    @Autowired
    RecepcionService recepcionService;    

    @PostConstruct
    public void init(){
    	valijasList = new ArrayList<ReporteCertificacionValijaXdiaBean>();
    }

    public void limpiaForm(){     
    	valijasList = new ArrayList<ReporteCertificacionValijaXdiaBean>();
    	fecIni = null;
        fecFin = null;
    }   
  
    public void search() {
    	valijasList =  recepcionService.obtieneValijasXdia( sdf.format(fecIni), fecFin);
    }    
    
    public void exportPdfCartaDetalle() {
    	System.out.println("generaAcuse");
    	FacesContext context = FacesContext.getCurrentInstance();
		try {				
            HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
				
				JasperReport jr = JasperCompileManager.compileReport(Thread.currentThread().getContextClassLoader()
						.getResourceAsStream("reports/ReporteRecepcionXDia.jrxml"));
				
				JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(valijasList);

				Map<String, Object> parametros = new HashMap<String, Object>();
	
				parametros.put("fechaGral", sdf.format(fecIni) );
				parametros.put("totalEtiquetas", valijasList.size());
				
				byte[] fichero = JasperRunManager.runReportToPdf(jr,parametros, beanCollectionDataSource);
				ServletOutputStream outputStream = response.getOutputStream();
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment; filename=\"Acuse_"+fecIni+ ".pdf\"");
				outputStream.write(fichero);
				outputStream.flush();
				outputStream.close();
		        context.renderResponse();
	            context.responseComplete();	
				
			
		} catch (Exception ex) {
			ex.printStackTrace();
			addMessageError("Error!", ex.getMessage());
		}	
    }
    


	/**
      * MENSAJES 
      * @param summary
      * @param detail
      */
    
    public void addMessageInfo(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public void addMessageError(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public void addMessageWarning(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public List<ReporteCertificacionValijaXdiaBean> getValijasList() {
        return valijasList;
    }

    public void setValijasList(List<ReporteCertificacionValijaXdiaBean> valijasList) {
        this.valijasList = valijasList;
    }

    public Date getFecIni() {
        return fecIni;
    }

    public void setFecIni(Date fecIni) {
        this.fecIni = fecIni;
    }

    public String getFecFin() {
        return fecFin;
    }

    public void setFecFin(String fecFin) {
        this.fecFin = fecFin;
    }

	

}
