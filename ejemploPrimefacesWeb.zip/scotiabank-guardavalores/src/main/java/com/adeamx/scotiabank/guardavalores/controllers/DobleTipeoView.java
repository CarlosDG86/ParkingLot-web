/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import com.adeamx.scotiabank.guardavalores.lib.beans.DobleTipeo;
import java.io.Serializable;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import net.codicentro.core.TypeCast;
import org.primefaces.context.RequestContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

/**
 *
 * @author evglezmen
 */
@Controller
@Scope("view")
public class DobleTipeoView implements Serializable{
    
    private DobleTipeo dobleTipeo;
    private String resultadoTipeo;
    
    @PostConstruct
    public void init(){
        dobleTipeo = new DobleTipeo();
        Map<String, String[]> params
                    = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterValuesMap();

        String[] base = params.get("datosTipeo"); 
        dobleTipeo.setDesacripcion(base[0]);
        dobleTipeo.setValorOrigen(base[1]);
        dobleTipeo.setTipo(Integer.valueOf(base[2]));
    }
    
    
    public void validaDobleTipeo(){
        if(dobleTipeo.getValorOrigen().equals(dobleTipeo.getValor())){
            resultadoTipeo = "CORRECTO";
        }else{
            resultadoTipeo = "INCORRECTO";
        }
    }
    
        
    public void selectedEventoDialog() {
        String success = "error";
        if(resultadoTipeo.equals("CORRECTO")){
             success = "success";
        }
        
        RequestContext.getCurrentInstance().closeDialog(success);
    }

    public DobleTipeo getDobleTipeo() {
        return dobleTipeo;
    }

    public void setDobleTipeo(DobleTipeo dobleTipeo) {
        this.dobleTipeo = dobleTipeo;
    }
    
    public void correcto() {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, null, "¡¡ CORRECTO !!."));
    }
          
    public void error() {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, null, "¡¡ INCORRECTO !!"));
    }

    public String getResultadoTipeo() {
        return resultadoTipeo;
    }

    public void setResultadoTipeo(String resultadoTipeo) {
        this.resultadoTipeo = resultadoTipeo;
    }
     
    
    
    
}
