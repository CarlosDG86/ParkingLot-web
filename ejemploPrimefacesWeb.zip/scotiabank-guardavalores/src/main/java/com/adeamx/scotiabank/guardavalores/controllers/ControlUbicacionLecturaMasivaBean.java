/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import java.io.Serializable;
import java.util.Date;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import mx.com.adea.security.core.userdetails.UserDetails;
import net.codicentro.core.TypeCast;

import org.apache.commons.lang.StringUtils;
import org.primefaces.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.adeadms.core.adea.pojos.EtiqDocum;
import com.adeadms.core.adea.pojos.Horizontalca;
import com.adeamx.adeadms.servicios.RegistroGeneralServicio;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbControlUbicaciones;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScbnkBaseLectura;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaLecturaMasivaService;

/**
 *
 * @author jdavila
 */
@Controller
@Scope("view")
public class ControlUbicacionLecturaMasivaBean implements Serializable {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    public final static String TARGET_PATH_DIGITALES = "Digitales";
    private static final Logger log = LoggerFactory.getLogger(ControlUbicacionLecturaMasivaBean.class);
    
    @Value("${com.adeamx.security.antivirus.detecting.host}")
    private String antivirusDetectingHost;
    @Value("${com.adeamx.webmx.customer.id}")
    private Long cliente;
    
    private UserDetails userDetails;
    
    @Autowired
    ScotiaLecturaMasivaService scotiaLecturaMasivaService;    
    @Autowired
    RegistroGeneralServicio registroGeneralServicio;
    

    
	private String ubicacionAdeA;
	private String etiquetaAdea;
	
	private String ubicacionAdeaAnt;
	private String ubicacionScotiaAnt;
	private Date now;
	private EtiqDocum etq;
	private ScbnkBaseLectura datosBDScotia;
	
	private boolean btnActualizaDisabled; 

    
    
    @PostConstruct
    public void init(){
        userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();       
        now = registroGeneralServicio.getFechaActual();            
        datosBDScotia = new ScbnkBaseLectura();
        etq = new EtiqDocum  ();
        btnActualizaDisabled = true;
    }
    
    public void validaUbicAdea(){
    	RequestContext requestContext = RequestContext.getCurrentInstance();
    	try {   
    		
            if (ubicacionAdeA.startsWith("C") && TypeCast.toInt(ubicacionAdeA.substring(1, 3)) > -1 && TypeCast.toInt(ubicacionAdeA.substring(5)) > -1 && ubicacionAdeA.length() == 13){
            	Horizontalca horizontal = scotiaLecturaMasivaService.getUbicacionHz(ubicacionAdeA);
            	if(horizontal == null){
            		throw new Exception("NO EXISTE LA UBICACION ADEA REGISTRADA");
            	}  
            	requestContext.execute("document.getElementById('form:fluidGrid:EtiquetaAdea').focus()"); 
            }else{
            	addMessageError("Error!", "LECTURA ERRONEA DE LA UBICACIÓN ADEA.");
            	ubicacionAdeA = null;
            	requestContext.execute("document.getElementById('form:fluidGrid:UbicAdea').focus()"); 
            	return;
            }

        } catch (Exception ex) {
        	ex.printStackTrace();
        	ubicacionAdeA = null;
        	addMessageError("Error!", ex.getMessage());
        	requestContext.execute("document.getElementById('form:fluidGrid2:UbicAdea').focus()");
        	return;
        }
    }
    
	public void validaEtiquetaAdea() {
		RequestContext requestContext = RequestContext.getCurrentInstance();
		try {
			
			if (StringUtils.isNotEmpty(etiquetaAdea)
					&& !Pattern.matches("U\\d{10}", etiquetaAdea)) {
				addMessageError("Error!",
						"LECTURA ERRONEA DE LA ETIQUETA ADEA.");
			} else {
				// validamos etiq docum
				etq = scotiaLecturaMasivaService.getEtiquetaU(TypeCast.toLong(etiquetaAdea.replace("U","")));
				if (etq == null) {
					etiquetaAdea = null;
					throw new Exception(
							"LA ETIQUETA ADEA NO EXISTE PARA ESTE CLIENTE");
				} else if ( etq.getEstadoUbicacion() == null || !etq.getEstadoUbicacion().equals("ECU")) {
					etiquetaAdea = null;
					throw new Exception(
							"LA ETIQUETA ADEA NO SE ENCUENTRA EN ESTADO 'ECU'.");
				}
				
				datosBDScotia = scotiaLecturaMasivaService.getDatosRecallByNunicodoc(etq.getnUnicoDoc());
				
				if (datosBDScotia == null) {
					throw new Exception(
							"NO SE ENCUENTRA REGISTRO DE UBICACION PARA LA ETIQUETA ADEA:"
									+ etq.getnUnicoDoc());
				}else if (!datosBDScotia.getUbicacionAdea().equalsIgnoreCase(ubicacionAdeA)){
					ubicacionAdeaAnt = datosBDScotia.getUbicacionAdea() ;
					ubicacionScotiaAnt = datosBDScotia.getUbicacionRealRecall();
				     requestContext.addCallbackParam("isValid", true);
				}else
					btnActualizaDisabled = false;
				
			}
		} catch (Exception ex) {
			requestContext.addCallbackParam("isValid", false);
			addMessageError("Error!",  ex.getMessage());
		}
	}
	
	public void btnYES(){     
		datosBDScotia.setUbicacionAdea(ubicacionAdeA);
//		Consiliamos con su ubicacion Scotia Real y la actualizamos
		ScbnkBaseLectura ubicOrigScotia = scotiaLecturaMasivaService.getDatosRecallByUbicacionAdea(ubicacionAdeA);
		if(ubicOrigScotia != null)
			datosBDScotia.setUbicacionRealRecall(ubicOrigScotia.getUbicacionRealRecall());
		btnActualizaDisabled = false;
		
	}
	
	public void btnNO(){     
	      etiquetaAdea= null;
	      datosBDScotia = new ScbnkBaseLectura();
	      etq = new EtiqDocum  ();
	}
	
	
    public void limpiaForm(){     
      ubicacionAdeA= null;
      etiquetaAdea= null;
      datosBDScotia = new ScbnkBaseLectura();
      etq = new EtiqDocum  ();
      btnActualizaDisabled = true;
  }   


	public void actualizaUbicacion() {
		try {
			if(ubicacionAdeA == null){
				throw new Exception(
						"DEBE INGRESAR UNA UBICACIÓN");
			}
			if(etiquetaAdea == null){
				throw new Exception(
						"DEBE INGRESAR UNA ETIQUETA ADEA");
			}
			
			
			etq.setEstadoUbicacion("ETN");
			
			SbControlUbicaciones sbControlUbicaciones = new SbControlUbicaciones();
			sbControlUbicaciones.setFecha(now);
			sbControlUbicaciones.setNunicodoc(etq.getnUnicoDoc());
			sbControlUbicaciones.setUbicAdeaActual(datosBDScotia.getUbicacionAdea());
			sbControlUbicaciones.setUbicScotiaActual(datosBDScotia.getUbicacionRealRecall());
			sbControlUbicaciones.setUbicAdeaAnterior(ubicacionAdeaAnt);
			sbControlUbicaciones.setUbicScotiaAnterior(ubicacionScotiaAnt);
			sbControlUbicaciones.setUsuario(userDetails.getUser().getLogin());
			
			
			scotiaLecturaMasivaService.actualizaEstadoEtiq(etq, datosBDScotia, sbControlUbicaciones);
			limpiaForm();
			addMessageInfo("Alerta!", "SE HAN GUARDADO LOS CAMBIOS, CORRECTAMENTE.");
		} catch (Exception ex) {
			ex.printStackTrace();
			addMessageError("Error!", ex.getMessage());
		}
	}
   
    
     /**
      * MENSAJES 
      * @param summary
      * @param detail
      */
    
    public void addMessageInfo(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public void addMessageError(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public void addMessageWarning(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, summary,  detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }



    public Date getNow() {
        return now;
    }

    public void setNow(Date now) {
        this.now = now;
    }

	public String getUbicacionAdeA() {
		return ubicacionAdeA;
	}

	public void setUbicacionAdeA(String ubicacionAdeA) {
		this.ubicacionAdeA = ubicacionAdeA;
	}

	public String getEtiquetaAdea() {
		return etiquetaAdea;
	}

	public void setEtiquetaAdea(String etiquetaAdea) {
		this.etiquetaAdea = etiquetaAdea;
	}

	public EtiqDocum getEtq() {
		return etq;
	}

	public void setEtq(EtiqDocum etq) {
		this.etq = etq;
	}

	public ScbnkBaseLectura getDatosBDScotia() {
		return datosBDScotia;
	}

	public void setDatosBDScotia(ScbnkBaseLectura datosBDScotia) {
		this.datosBDScotia = datosBDScotia;
	}

	public boolean isBtnActualizaDisabled() {
		return btnActualizaDisabled;
	}

	public void setBtnActualizaDisabled(boolean btnActualizaDisabled) {
		this.btnActualizaDisabled = btnActualizaDisabled;
	}

	
}
