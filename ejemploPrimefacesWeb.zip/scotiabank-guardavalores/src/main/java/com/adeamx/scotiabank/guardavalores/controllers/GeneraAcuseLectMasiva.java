package com.adeamx.scotiabank.guardavalores.controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adeamx.scotiabank.guardavalores.lib.beans.ReporteTotalesLectMasiva;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScbnkBaseLectura;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaLecturaMasivaService;
import com.adeamx.scotiabank.guardavalores.lib.utils.Constantes;

@Controller
public class GeneraAcuseLectMasiva {

    @Autowired
    ScotiaLecturaMasivaService scotiaLecturaMasivaService;    
	
	 @RequestMapping(value = "/lecturaMasiva/generaAcuse.action")
	    @ResponseBody
	    public void generarAcuse(
	            HttpServletResponse response,
	            HttpServletRequest request) {
	       

	    	FacesContext context = FacesContext.getCurrentInstance();
			try {

				HttpSession session = request.getSession();
	            String ubicacionScotia = (String) session.getAttribute("ubicScotia");

	            List<ScbnkBaseLectura> scbnkBaseLecturaList = new ArrayList<ScbnkBaseLectura>();
	            	
					
					List<ReporteTotalesLectMasiva> reporteTotalesLMBeanList = scotiaLecturaMasivaService
							.obtieneTotalesByUbicacion(ubicacionScotia);

					//Obtenemos reporte de faltantes y sobrantes
					List<ScbnkBaseLectura> sobFaltantesList =  scotiaLecturaMasivaService.getSobrantesFaltantes(ubicacionScotia);

					JasperReport jr = JasperCompileManager.compileReport(Thread.currentThread().getContextClassLoader()
							.getResourceAsStream("reports/ReporteTotalesIncidencias.jrxml"));
					
					JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(sobFaltantesList);

					Map<String, Object> parametros = new HashMap<String, Object>();

					SimpleDateFormat sdf = new SimpleDateFormat("ddMMyy");
					String date = sdf.format(new Date()); 
					
					String folio = scbnkBaseLecturaList.get(0).getUbicacionRealRecall();
					folio = folio.substring(folio.length()-4, folio.length()) +date;
					
					parametros.put("ubicacionScotia", scbnkBaseLecturaList.get(0).getUbicacionRealRecall());
					parametros.put("ubicacionAdea", scbnkBaseLecturaList.get(0).getUbicacionAdea());
					parametros.put("localizacion", scbnkBaseLecturaList.get(0).getLocalizacion());
					parametros.put("folio", folio);
					parametros.put("usuarioLectura", scbnkBaseLecturaList.get(0).getUsuarioLectura());
					parametros.put("fechaLectura", scbnkBaseLecturaList.get(0).getFechaLectura());
					// TODO
					// realizamos el for para los demas parametros
					for (ReporteTotalesLectMasiva dataTotales : reporteTotalesLMBeanList) {
						// Conciliados
						if ((dataTotales.getTipoCredito()).equals(Constantes.C_AUTO)) {
							parametros.put("TpoCredAuto","AUTO");
							parametros.put("conciliadoAuto",dataTotales.getConciliados());
							parametros.put("sobranteAuto",dataTotales.getSobrantes());
							parametros.put("faltanteAuto",dataTotales.getFaltantes());
						} else if ((dataTotales.getTipoCredito()).equals(Constantes.C_HIPOTECARIO)) {
							parametros.put("TpoCreditoHipo","HIPOTECARIO");
							parametros.put("conciliadoHipo",dataTotales.getConciliados());
							parametros.put("sobranteHipo",dataTotales.getSobrantes());
							parametros.put("faltanteHipo",dataTotales.getFaltantes());
						} else if ((dataTotales.getTipoCredito()).equals(Constantes.C_PERSONAL)) {
							parametros.put("TpoCreditoPersonal","PERSONAL");
							parametros.put("conciliadoPersonal",dataTotales.getConciliados());
							parametros.put("sobrantePersonal",dataTotales.getSobrantes());
							parametros.put("faltantePersonal",dataTotales.getFaltantes());
						} else if ((dataTotales.getTipoCredito())
								.equals(Constantes.C_RRHH)) {
							parametros.put("TpoCreditoRH","RRHH");
							parametros.put("conciliadoRH",dataTotales.getConciliados());
							parametros.put("sobranteRH", dataTotales.getSobrantes());
							parametros.put("faltanteRH", dataTotales.getFaltantes());
						}

					}
					
					byte[] fichero = JasperRunManager.runReportToPdf(jr,parametros, beanCollectionDataSource);
					ServletOutputStream outputStream = response.getOutputStream();
					response.setContentType("application/octet-stream");
					response.setHeader("Content-Disposition","attachment; filename=\"AcuseValija" + ".pdf\"");
					outputStream.write(fichero);
					outputStream.flush();
					outputStream.close();
//			        context.renderResponse();
//		            context.responseComplete();	
			
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}	
	    }
}
