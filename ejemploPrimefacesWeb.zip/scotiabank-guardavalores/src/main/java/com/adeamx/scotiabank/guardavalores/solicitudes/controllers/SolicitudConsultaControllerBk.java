package com.adeamx.scotiabank.guardavalores.solicitudes.controllers;

import com.adeadms.adeadms.core.captura.pojos.CabeceraDocCap;
import com.adeadms.adeadms.core.captura.pojos.PersonasCap;
import com.adeadms.core.adea.pojos.Clientes;
import com.adeadms.core.adea.pojos.EtiqDocumHn;
import com.adeadms.core.security.pojos.UsuarioWebmx;
import com.adeamx.adeadms.servicios.RegistroGeneralServicio;
import com.adeamx.dms.libs.consultas.beans.CabeceraDocBean;
import com.adeamx.dms.libs.consultas.beans.CabeceraDocCte1PhBean;
import com.adeamx.dms.libs.consultas.beans.CajaBean;
import com.adeamx.dms.libs.consultas.beans.ScPersonalBean;
import com.adeamx.dms.libs.consultas.pojos.AdeaCatalogos;
import com.adeamx.dms.libs.consultas.pojos.ScCentroCosto;
import com.adeamx.dms.libs.consultas.pojos.ScPrioridad;
import com.adeamx.dms.libs.consultas.pojos.ScSolicitudConsulta;
import com.adeamx.dms.libs.consultas.pojos.ScTipoConsulta;
import com.adeamx.dms.libs.consultas.services.AdjuntoService;
import com.adeamx.dms.libs.consultas.services.BusquedaService;
import com.adeamx.dms.libs.consultas.services.CatalogoService;
import com.adeamx.dms.libs.consultas.services.SolicitudConsultaService;
import com.adeamx.dms.libs.consultas.utils.ComboItem;
import com.adeamx.dms.libs.consultas.utils.SolicitudUtil;
import com.adeamx.faces.lib.utilerias.MessagesShow;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaSolicitudConsultaService;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import javax.annotation.PostConstruct;
import mx.com.adea.security.core.userdetails.UserDetails;
import net.codicentro.core.ClamavScan;
import org.codehaus.jackson.map.ObjectMapper;
import org.primefaces.event.FileUploadEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

/**
 *
 * @author asalgado
 */
@Component
@Scope("view")
public class SolicitudConsultaControllerBk implements Serializable {

    private Logger logger = LoggerFactory.getLogger(SolicitudConsultaControllerBk.class);

    @Value("${com.adeamx.webmx.customer.id}")
    private Long scltcod;
    @Value("${com.adeamx.security.antivirus.detecting.host}")
    private String antivirusDetectingHost;
    @Value("${com.adeamx.consultas.carga.bdi.path}")
    private String bdiPath;
    @Value("${com.adeamx.consultas.carga.bdo.path}")
    private String bdoPath;
    private boolean expedientes, documentos, cajas, cargaArchivos;

    private UserDetails userDetails;
    private UsuarioWebmx usuarioWebmx;
    private boolean facturable;
    private String titlePanelBusqueda = "";
    /* OBJETO A SALVAR POR TANTO EL MAS IMPORTANTE */
    private ScSolicitudConsulta consulta = new ScSolicitudConsulta();
    private List<Clientes> clientList = new ArrayList<Clientes>();
    private Long clienteId;
    private List<ComboItem> lugarConsultaList = new ArrayList<ComboItem>();
    private Integer lugarConsulta;
    private List<AdeaCatalogos> modosConsultaList = new ArrayList<AdeaCatalogos>();
    private String modoConsulta;
    private List<AdeaCatalogos> kitModoConsultaList = new ArrayList<AdeaCatalogos>();
    private Integer kitSelected;
    private List<ScPrioridad> prioridadList = new ArrayList<ScPrioridad>();
    private Long prioridad;
    private List<ScTipoConsulta> tipoConsultaList = new ArrayList<ScTipoConsulta>();
    private Long tipoConsulta;
    private List<ScPersonalBean> solicitanteList = new ArrayList<ScPersonalBean>();
    private Long solicitante;
    private List<ScPersonalBean> receptoresList = new ArrayList<ScPersonalBean>();
    private Long receptor;
    private List<ScCentroCosto> centroCostoList = new ArrayList<ScCentroCosto>();
    private Long centroCosto;
    private List<ComboItem> comboBusqueda = new ArrayList<ComboItem>();
    private String lblParamBusqueda = "PARAMETRO:";
    private Integer selectTipoBusqueda;
    private String paramBusqueda;
    private List<CabeceraDocBean> expedientesSeleccionados = new ArrayList<CabeceraDocBean>();
    private List<CabeceraDocCte1PhBean> documentosSeleccionados = new ArrayList<CabeceraDocCte1PhBean>();
    private List<CajaBean> cajasSeleccionadas = new ArrayList<CajaBean>();

    private List<CabeceraDocBean> expedienteEncontrado = new ArrayList<CabeceraDocBean>();
    private List<CabeceraDocCte1PhBean> documentoEncontrado = new ArrayList<CabeceraDocCte1PhBean>();
    private List<CajaBean> cajaEncontrado = new ArrayList<CajaBean>();
    private Map registros = new HashMap();

//    PARAMETROS DE LAS BUSQUEDAS
    private int tipoCarga = 0;

    private String folioCliente, observaciones, observacionesFact = "";
    
    //Busqueda Expedientes
    private String nunicodocFilter;
    private String nroIdentdocFilter;
    private Long folioFilter;
    private Long creditoFilter;

    @Autowired
    private BusquedaService busquedaService;
    @Autowired
    private SolicitudConsultaService solicitudConsultaService;
    @Autowired
    private RegistroGeneralServicio registroGeneralServicio;
    @Autowired
    private CatalogoService catalogoServiceImpl;
    @Autowired
    private AdjuntoService adjuntoService;
    @Autowired
    private ScotiaSolicitudConsultaService consultaService;

    @PostConstruct
    public void init() {
        userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        loadClienteList();
    }

    public void salvarSolicitud() {
        try {
            solicitudConsultaService.salvarSolicitud(clienteId, userDetails.getUsername(), consulta, lugarConsulta, prioridad, tipoConsulta, solicitante,
                    receptor, centroCosto, facturable, observaciones, observacionesFact, modoConsulta, expedientesSeleccionados,
                    documentosSeleccionados, cajasSeleccionadas);
            MessagesShow.showMessageInfoBackEnd("Solicitud de consulta con folio: " + consulta.getFolio() + ", creada correctamente");
            limpiarCaptura();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public List<ScSolicitudConsulta> buscarSolicitudes(Long cliente, Long folio, Integer page, Integer start, Integer limit) {
        try {
            return solicitudConsultaService.obtenerConsultas(cliente, folio, page, limit);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
            return null;
        }
    }

    public void limpiarCaptura() throws Exception {
        consulta = new ScSolicitudConsulta();
        clienteId = null;
        lugarConsultaList = new ArrayList<ComboItem>();
        lugarConsulta = null;
        modosConsultaList = new ArrayList<AdeaCatalogos>();
        modoConsulta = null;
        kitModoConsultaList = new ArrayList<AdeaCatalogos>();
        kitSelected = null;
        prioridadList = new ArrayList<ScPrioridad>();
        prioridad = null;
        tipoConsultaList = new ArrayList<ScTipoConsulta>();
        tipoConsulta = null;
        solicitanteList = new ArrayList<ScPersonalBean>();
        solicitante = null;
        receptoresList = new ArrayList<ScPersonalBean>();
        receptor = null;
        centroCostoList = new ArrayList<ScCentroCosto>();
        centroCosto = null;
        comboBusqueda = new ArrayList<ComboItem>();
        expedientesSeleccionados.clear();
        documentosSeleccionados.clear();
        cajasSeleccionadas.clear();
        registros.clear();
        lblParamBusqueda = "PARAMETRO:";
        facturable = false;
        expedientes = false;
        observaciones = "";
        observacionesFact = "";
        loadClienteList();
    }

    /* METODOS COPIADOS DE CATALOGO CONTROLLER */
    public void loadClienteList() {
        try {
            clientList = new ArrayList<Clientes>();
            Clientes cte = catalogoServiceImpl.getClienteByScltcod(scltcod);
            clientList.add(cte);
//            clientList = catalogoServiceImpl.getClientes(null);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     *
     * @param cab Object to delete
     * @param opc flag to define which list is cleared
     */
    public void eliminarExpediente(CabeceraDocBean cab, int opc) {
        if (opc == 1) {
            expedienteEncontrado.remove(cab);
        } else if (opc == 2) {
            expedientesSeleccionados.remove(cab);
        }
    }

    public void eliminarDocumento(CabeceraDocCte1PhBean docum, int opc) {
        if (opc == 1) {
            documentoEncontrado.remove(docum);
            registros.remove(docum.getNunicodoc());
        } else if (opc == 2) {
            documentosSeleccionados.remove(docum);
        }

    }

    public void eliminarCaja(CajaBean caja, int opc) {
        if (opc == 1) {
            cajaEncontrado.remove(caja);
        } else if (opc == 2) {
            cajasSeleccionadas.remove(caja);
        }
    }

    public void cancelar() {
        expedienteEncontrado.clear();
        documentoEncontrado.clear();
        cajaEncontrado.clear();
        registros.clear();
        tipoCarga = 0;
        paramBusqueda = "";
        selectTipoBusqueda = null;
    }

    private String[] readFile(FileUploadEvent event) throws IOException {
        StringBuilder concatString = new StringBuilder();
        InputStream in = event.getFile().getInputstream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        StringBuilder out = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            if ("".compareTo(line.trim()) != 0) {
                concatString.append(line.trim());
                concatString.append(",");
            }
        }
        return concatString.toString().trim().substring(0, concatString.toString().length() - 1).split(",");
    }

    public void handleFileUpload(FileUploadEvent event) {
        try {
            String[] registros = readFile(event);
            if (registros.length > 1000) {
                throw new Exception("El archivo no debe contener mas de 1000 registros.");
            } else {
                try {
                    busquedaService.buscar(registros, modoConsulta, selectTipoBusqueda, clienteId, lugarConsulta, expedienteEncontrado,
                            documentoEncontrado, cajaEncontrado, kitSelected);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    logger.error("Error: " + ex.getMessage(), ex);
                }
            }
        } catch (IOException ex) {
            MessagesShow.showMessageError(ex.getMessage());
        } catch (Exception ex) {
            MessagesShow.showMessageError(ex.getMessage());
        }
    }

    public void loadLugaresConsultaList() {
        try {
//            limpiar pantalla
            lugarConsultaList = new ArrayList<ComboItem>();
            lugarConsulta = null;
            modosConsultaList = new ArrayList<AdeaCatalogos>();
            modoConsulta = null;
            kitModoConsultaList = new ArrayList<AdeaCatalogos>();
            kitSelected = null;
            prioridadList = new ArrayList<ScPrioridad>();
            prioridad = null;
            tipoConsultaList = new ArrayList<ScTipoConsulta>();
            tipoConsulta = null;
            solicitanteList = new ArrayList<ScPersonalBean>();
            solicitante = null;
            receptoresList = new ArrayList<ScPersonalBean>();
            receptor = null;
            centroCostoList = new ArrayList<ScCentroCosto>();
            centroCosto = null;
            comboBusqueda = new ArrayList<ComboItem>();
            expedientesSeleccionados.clear();
            documentosSeleccionados.clear();
            cajasSeleccionadas.clear();
            registros.clear();
            lblParamBusqueda = "PARAMETRO:";
            facturable = false;
            expedientes = false;

            lugarConsultaList = new ArrayList<ComboItem>();
            lugarConsultaList.add(new ComboItem(ComboItem.LUGAR_CONSULTA_LOCAL_CLIENTE_VALUE, ComboItem.LUGAR_CONSULTA_LOCAL_CLIENTE_LABEL));
            lugarConsultaList.add(new ComboItem(ComboItem.LUGAR_CONSULTA_REMOTA_VALUE, ComboItem.LUGAR_CONSULTA_REMOTA_LABEL));
            if (userDetails.getUser().getCliente() == 2L) {
                lugarConsultaList.add(new ComboItem(ComboItem.LUGAR_CONSULTA_INTERNA_VALUE, ComboItem.LUGAR_CONSULTA_INTERNA_LABEL));
                lugarConsultaList.add(new ComboItem(ComboItem.LUGAR_CONSULTA_DEVOLUCION_DEFINITIVA_VALUE, ComboItem.LUGAR_CONSULTA_DEVOLUCION_DEFINITIVA_LABEL));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadModosConsultaList() {
        try {
            modosConsultaList = consultaService.obtenerModosConsulta(clienteId.intValue());
//            modosConsultaList = new ArrayList<ComboItem>();
//            modosConsultaList.add(new ComboItem(ComboItem.MODO_CONSULTA_EXPEDIENTES_VALUE, ComboItem.MODO_CONSULTA_EXPEDIENTES_LABEL));
//            modosConsultaList.add(new ComboItem(ComboItem.MODO_CONSULTA_DOCUMENTOS_VALUE, ComboItem.MODO_CONSULTA_DOCUMENTOS_LABEL));
//            modosConsultaList.add(new ComboItem(ComboItem.MODO_CONSULTA_CAJAS_VALUE, ComboItem.MODO_CONSULTA_CAJAS_LABEL));
        } catch (Exception e) {
            logger.error(e.getMessage());
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    private AdeaCatalogos getModoSelected() {
        if (modoConsulta != null) {
            for (AdeaCatalogos catalogo : modosConsultaList) {
                if (catalogo.getDescripcionCat().compareTo(modoConsulta) == 0) {
                    return catalogo;
                }
            }
        }
        return null;
    }

    public void loadKitConsultaList() {
        try {
            AdeaCatalogos modoSelected = getModoSelected();
            if (modoSelected != null) {
                kitModoConsultaList = busquedaService.obtenerKits(modoSelected.getId());
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadPrioridadesList() {
        try {
            prioridadList = catalogoServiceImpl.getPrioridades(clienteId);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadInComboModoConsulta() {
        loadKitConsultaList();
        loadPrioridadesList();
    }

    public void loadTiposConsultaList() {
        Integer item;
        try {
//            if (modoConsulta == ComboItem.MODO_CONSULTA_CAJAS_VALUE) {
            if (ComboItem.MODO_CONSULTA_CAJAS_LABEL.compareTo(modoConsulta) == 0) {
                item = ScTipoConsulta.ITEM_SOLICITADO_CAJAS;
            } else {
                item = ScTipoConsulta.ITEM_SOLICITADO_EXPEDIENTES;
            }
            tipoConsultaList = catalogoServiceImpl.getTiposConsulta(clienteId, item);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadSolicitantesList() {
        try {
            solicitanteList = catalogoServiceImpl.getSolicitantes(clienteId, null);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadReceptoresList() {
        try {
            receptoresList = catalogoServiceImpl.getReceptores(clienteId, null);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public void loadCentrosCostoList() {
        try {
            centroCostoList = catalogoServiceImpl.getCentrosCosto(clienteId);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }
    /* METODO QUE SE UTILIZA AL MOMENTO DE CARGAR LOS COMBOS DE BUSQUEDA DE ETIQUETAS */

    public void loadCamposBusquedaList() {
        try {
            comboBusqueda = new ArrayList<ComboItem>();
            comboBusqueda.add(new ComboItem(ComboItem.CAMPO_BUSQUEDA_ETIQUETA_VALUE, ComboItem.CAMPO_BUSQUEDA_ETIQUETA_LABEL));
            if (clienteId == 37 && ((ComboItem.MODO_CONSULTA_EXPEDIENTES_LABEL.compareTo(modoConsulta) == 0))/*modoConsulta == ComboItem.MODO_CONSULTA_EXPEDIENTES_VALUE*/) {
                comboBusqueda.add(new ComboItem(ComboItem.CAMPO_BUSQUEDA_CREDITO_VALUE, ComboItem.CAMPO_BUSQUEDA_CREDITO_LABEL));
                comboBusqueda.add(new ComboItem(ComboItem.CAMPO_BUSQUEDA_ESCRITURA_VALUE, ComboItem.CAMPO_BUSQUEDA_ESCRITURA_LABEL));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    /* CARGAR ITEMS DE COMBO DE TIPO DE BUSQUEDA */
    public void loadCamposBusquedaCajaList() {
        comboBusqueda = new ArrayList<ComboItem>();
        comboBusqueda.add(new ComboItem(ComboItem.CAMPO_BUSQUEDA_CAJA_ID_VALUE, ComboItem.CAMPO_BUSQUEDA_CAJA_ID_LABEL));
        comboBusqueda.add(new ComboItem(ComboItem.CAMPO_BUSQUEDA_CAJA_ADEA_VALUE, ComboItem.CAMPO_BUSQUEDA_CAJA_ADEA_LABEL));
    }

    public void loadCamposBusquedaArchivo() {
        try {
            comboBusqueda = new ArrayList<ComboItem>();
            comboBusqueda.add(new ComboItem(ComboItem.CAMPO_BUSQUEDA_ETIQUETA_VALUE, ComboItem.CAMPO_BUSQUEDA_ETIQUETA_LABEL));
            if (clienteId == 37 && (ComboItem.MODO_CONSULTA_EXPEDIENTES_LABEL.compareTo(modoConsulta) == 0)/*modoConsulta == ComboItem.MODO_CONSULTA_EXPEDIENTES_VALUE*/) {
                comboBusqueda.add(new ComboItem(ComboItem.CAMPO_BUSQUEDA_CREDITO_VALUE, ComboItem.CAMPO_BUSQUEDA_CREDITO_LABEL));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    public void onChangeCombo() {
        if (selectTipoBusqueda != null) {
            for (ComboItem valor : comboBusqueda) {
                if (valor.getValue().compareTo(selectTipoBusqueda) == 0) {
                    lblParamBusqueda = valor.getLabel() + ":";
                    break;
                }
            }
        }
    }

    public void loadCombo() {
        loadCamposBusquedaList();
        if (ComboItem.MODO_CONSULTA_EXPEDIENTES_LABEL.compareTo(modoConsulta) == 0) {
            titlePanelBusqueda = "BUSQUEDA EXPEDIENTES";
        } else if (ComboItem.MODO_CONSULTA_DOCUMENTOS_LABEL.compareTo(modoConsulta) == 0) {
            titlePanelBusqueda = "BUSQUEDA DOCUMENTOS";
        } else if (ComboItem.MODO_CONSULTA_CAJAS_LABEL.compareTo(modoConsulta) == 0) {
            loadCamposBusquedaCajaList();
            titlePanelBusqueda = "BUSQUEDA CAJAS";
        } else if (ComboItem.MODO_CONSULTA_KIT_DOCUMENTOS_LABEL.compareTo(modoConsulta) == 0) {
            titlePanelBusqueda = "BUSQUEDA KITS DOCUMENTOS";
        }
    }

    /**
     * YORDANIS
     *
     * @param tipoCarga Parametro que define el tipo de carga que se realizará
     * en la aplicación con los siguientes valores: 1- carga simple de uno por
     * uno 2- carga a traves de un archivo
     *
     */
    public void showBusqueda(int tipoCarga) {
        this.tipoCarga = tipoCarga;
        if (tipoCarga == 1) {
            if (!expedientesSeleccionados.isEmpty()) {
                expedienteEncontrado.addAll(expedientesSeleccionados);
            }
            if (!documentosSeleccionados.isEmpty()) {
                documentoEncontrado.addAll(documentosSeleccionados);
            }
            if (!cajasSeleccionadas.isEmpty()) {
                cajaEncontrado.addAll(cajasSeleccionadas);
            }
        }
        loadCombo();
        /* PARAMETROS DE ENVÍO */
//        Map<String, List<String>> paramMap = new HashMap<String, List<String>>();
//        List<String> paramList = new ArrayList<String>();
//        
//        
//        //Param: Modo de consulta
//        paramList = new ArrayList<String>();
//        paramList.add(String.valueOf(modoConsulta));
//        paramMap.put("modoConsulta", paramList);
//        
//        //Param: cliente
//        paramList = new ArrayList<String>();
//        paramList.add(String.valueOf(clienteId));
//        paramMap.put("clienteId", paramList);
//
//        //Param: lugar Consulta
//        paramList = new ArrayList<String>();
//        paramList.add(String.valueOf(lugarConsulta));
//        paramMap.put("lugarConsulta", paramList);
//        
//        //Param: Tipo carga
//        paramList = new ArrayList<String>();
//        paramList.add(String.valueOf(tipoCarga));
//        paramMap.put("tipoCarga", paramList);        
//        
//        /* PARTE PROPIA DEL LEVANTAMIENTO DEL MODAL */
//        
//        Map<String,Object> options = new HashMap<String, Object>();
//        options.put("modal", true);
//        options.put("draggable", false);
//        options.put("resizable", true);
//        options.put("contentWidth", 1220);
//        options.put("contentHeight", 650);
//        
//        RequestContext.getCurrentInstance().openDialog("dlgBuscarExpedientes.xhtml", options, paramMap);
    }

//    public void onReturnDialog(SelectEvent event) {
//        Map<String, Object> response = (Map<String, Object>) event.getObject();
//        if (response != null && response.get("agregarLista") != null && (Boolean)response.get("agregarLista") == true) {
//            switch (modoConsulta) {
//                case 1:
//                    List<CabeceraDocBean> auxExp = (ArrayList<CabeceraDocBean>)response.get("lista");
//                    adicionarNuevasSelecciones(auxExp, null, null);
//                    break;
//                case 2:
//                    List<CabeceraDocCte1PhBean> auxDocum = (ArrayList<CabeceraDocCte1PhBean>)response.get("lista");
//                    adicionarNuevasSelecciones(null, auxDocum, null);
//                    break;
//                case 3:
//                    List<CajaBean> auxCaja = (ArrayList<CajaBean>)response.get("lista");
//                    adicionarNuevasSelecciones(null, null, auxCaja);
//                    break;
//            }
//        } 
//    }
    public void onReturnDialog() {
        if (ComboItem.MODO_CONSULTA_KIT_DOCUMENTOS_LABEL.compareTo(modoConsulta) == 0) {
            adicionarNuevasSelecciones(null, documentoEncontrado, null);
        } else if (ComboItem.MODO_CONSULTA_EXPEDIENTES_LABEL.compareTo(modoConsulta) == 0) {
            adicionarNuevasSelecciones(expedienteEncontrado, null, null);
        } else if (ComboItem.MODO_CONSULTA_DOCUMENTOS_LABEL.compareTo(modoConsulta) == 0) {
            adicionarNuevasSelecciones(null, documentoEncontrado, null);
        } else if (ComboItem.MODO_CONSULTA_CAJAS_LABEL.compareTo(modoConsulta) == 0) {
            adicionarNuevasSelecciones(null, null, cajaEncontrado);
        }
        tipoCarga = 0;
        paramBusqueda = "";
        selectTipoBusqueda = null;
    }

    private void adicionarNuevasSelecciones(List<CabeceraDocBean> auxExp, List<CabeceraDocCte1PhBean> auxDocum, List<CajaBean> auxCaja) {
        boolean existe;
        if ((auxExp != null) && !auxExp.isEmpty()) {
            for (CabeceraDocBean expediente : auxExp) {
                existe = false;
                for (CabeceraDocBean expViejo : expedientesSeleccionados) {
                    if (expViejo.getNunicodoc().compareTo(expediente.getNunicodoc()) == 0) {
                        existe = true;
                    }
                }
                if (!existe) {
                    expedientesSeleccionados.add(expediente);
                }
            }
            auxExp.clear();
            return;
        }
        if ((auxDocum != null) && !auxDocum.isEmpty()) {
            for (CabeceraDocCte1PhBean documento : auxDocum) {
                existe = false;
                for (CabeceraDocCte1PhBean documViejo : documentosSeleccionados) {
                    if (documViejo.getNunicodoct().compareTo(documento.getNunicodoct()) == 0) {
                        existe = true;
                    }
                }
                if (!existe) {
                    documentosSeleccionados.add(documento);
                }
            }
            auxDocum.clear();
            return;
        }
        if ((auxCaja != null) && !auxCaja.isEmpty()) {
            for (CajaBean caja : auxCaja) {
                existe = false;
                for (CajaBean cajaVieja : cajasSeleccionadas) {
                    if (cajaVieja.getCajaId().compareTo(caja.getCajaId()) == 0) {
                        existe = true;
                    }
                }
                if (!existe) {
                    cajasSeleccionadas.add(caja);
                }
            }
            auxCaja.clear();
        }
    }

    public void buscarArchivo(Authentication auth, @RequestParam CommonsMultipartFile archivo, @RequestParam Long cliente,
            @RequestParam Integer modoConsulta, @RequestParam Integer busqueda, @RequestParam(required = false) Integer lugarConsulta) {
        EtiqDocumHn et;

        ClamavScan scanner;

        File inputFile;
        FileInputStream ifis;
        File outputFile;
        FileOutputStream ofos;

        byte[] buffer;
        int noBytes;

        String registro;

        int linea = 0;
        int encontrados = 0;
        int erroneos = 0;
        String observaciones;
        Object dummy;
        Map<String, Object> dummyModel;

        ObjectMapper mapper;
        OutputStream out;

        Map<String, Object> model;
        try {
            if (archivo == null || archivo.getSize() <= 0) {
                throw new Exception("El archivo no existe o esta vacio");
            } else {
                if ("text/plain".equals(archivo.getContentType())) {
                    scanner = new ClamavScan(antivirusDetectingHost);
                    if (!scanner.doScan(archivo.getInputStream())) {
                        throw new Exception("Se detectaron virus en el archivo, " + scanner.getVirus());
                    }

                    if (busquedaService.isArchivoDepositado(archivo.getOriginalFilename())) {
                        throw new Exception("El archivo " + archivo.getOriginalFilename() + ", fue depositado anteriormente");
                    }

                    inputFile = new File(bdiPath);
                    if (!inputFile.exists()) {
                        if (!inputFile.mkdirs()) {
                            throw new Exception("Error el crear el directorio " + bdiPath);
                        }
                    }

                    inputFile = new File(bdiPath + File.separator + archivo.getOriginalFilename());
                    if (inputFile.exists()) {
                        inputFile.delete();
                    }

                    SolicitudUtil.write(inputFile, archivo.getInputStream(), false);

                    inputFile = new File(bdiPath + File.separator + archivo.getOriginalFilename());
                    ifis = new FileInputStream(inputFile);

                    outputFile = new File(bdoPath + File.separator + archivo.getOriginalFilename().substring(0, archivo.getOriginalFilename().lastIndexOf('.')) + ".log");
                    ofos = new FileOutputStream(outputFile);

                    buffer = new byte[(int) inputFile.length()];
                    noBytes = ifis.read(buffer);
                    String strArchivo = new String(buffer, 0, noBytes);
                    StringTokenizer tokens = new StringTokenizer(strArchivo, "\n");
                    if (tokens.countTokens() > 1000) {
                        ifis.close();
                        ofos.close();
                        throw new Exception("Número máximo de lineas permitido 1000");
                    }

                    mapper = new ObjectMapper();
                    model = new HashMap<String, Object>();
                    dummyModel = new HashMap<String, Object>();
                    observaciones = "";
                    if (modoConsulta == ComboItem.MODO_CONSULTA_EXPEDIENTES_VALUE) {
                        switch (busqueda) {
                            case ComboItem.CAMPO_BUSQUEDA_ETIQUETA_VALUE:
                                while (tokens.hasMoreElements()) {
                                    linea++;
                                    registro = tokens.nextElement().toString().trim();
                                    if (SolicitudUtil.validar(registro, "[Uu]{1}\\d{10}")) {
                                        if (!dummyModel.containsKey(registro)) {
                                            Long nunicodoc = Long.valueOf(registro.substring(1));
                                            if (!busquedaService.isEtiquetaCarteraEspecial(nunicodoc, BusquedaService.TIPO_ETIQUETA_U)) {
                                                dummy = busquedaService.obtenerExpediente(nunicodoc, cliente);
                                                if (dummy != null) {
                                                    dummyModel.put(registro, dummy);
                                                    encontrados++;
                                                } else {
                                                    observaciones += "linea: " + linea + " - no existe expediente " + registro + " para este cliente";
                                                    erroneos++;
                                                }
                                            } else {
                                                observaciones += "linea: " + linea + " - expediente bloqueado por cartera especial";
                                                erroneos++;
                                            }
                                        } else {
                                            observaciones += "linea: " + linea + " - etiqueta duplicada";
                                            erroneos++;
                                        }
                                    } else {
                                        observaciones += "linea: " + linea + " - etiqueta no valida";
                                        erroneos++;
                                    }
                                    if (observaciones != null && observaciones.trim().length() > 0) {
                                        observaciones += System.getProperty("line.separator");//System.lineSeparator()
                                        ofos.write(observaciones.getBytes());
                                        observaciones = "";
                                    }
                                }
                                ifis.close();
                                ofos.close();

                                out = new ByteArrayOutputStream();
                                mapper.writeValue(out, dummyModel.values());

                                model.put("cabeceraDocBeans", new String(((ByteArrayOutputStream) out).toByteArray()));
                                model.put("total", dummyModel.size());
                                model.put("encotrados", encontrados);
                                model.put("erroneos", erroneos);
                                model.put("success", true);
                                break;
                            case ComboItem.CAMPO_BUSQUEDA_CREDITO_VALUE:
                                while (tokens.hasMoreElements()) {
                                    linea++;
                                    registro = tokens.nextElement().toString().trim();
                                    if (registro != null && registro.length() > 0) {
                                        if (!dummyModel.containsKey(registro)) {
                                            dummy = busquedaService.obtenerExpedienteCredito(registro, cliente);
                                            if (dummy != null) {
                                                if (!busquedaService.isEtiquetaCarteraEspecial(((CabeceraDocBean) dummy).getNunicodoc(), BusquedaService.TIPO_ETIQUETA_U)) {
                                                    dummyModel.put(registro, dummy);
                                                    encontrados++;
                                                } else {
                                                    observaciones += "linea: " + linea + " - expediente bloqueado por cartera especial";
                                                }
                                            } else {
                                                observaciones += "linea: " + linea + " - no existe credito: " + registro;
                                                erroneos++;
                                            }
                                        } else {
                                            observaciones += "linea: " + linea + " - etiqueta duplicada";
                                            erroneos++;
                                        }
                                    } else {
                                        observaciones += "linea: " + linea + " - registro erroneo";
                                        erroneos++;
                                    }
                                    if (observaciones != null && observaciones.trim().length() > 0) {
                                        observaciones += System.lineSeparator();
                                        ofos.write(observaciones.getBytes());
                                        observaciones = "";
                                    }
                                }

                                ifis.close();
                                ofos.close();

                                out = new ByteArrayOutputStream();
                                mapper.writeValue(out, dummyModel.values());

                                model.put("cabeceraDocBeans", new String(((ByteArrayOutputStream) out).toByteArray()));
                                model.put("total", dummyModel.size());
                                model.put("encotrados", encontrados);
                                model.put("erroneos", erroneos);
                                model.put("success", true);
                                break;
                            default:
                                ifis.close();
                                ofos.close();
                                throw new Exception("Error, el modo de busqueda no existe");
                        }
                    } else if (modoConsulta == ComboItem.MODO_CONSULTA_DOCUMENTOS_VALUE) {
                        switch (busqueda) {
                            case ComboItem.CAMPO_BUSQUEDA_ETIQUETA_VALUE:
                                while (tokens.hasMoreElements()) {
                                    linea++;
                                    registro = tokens.nextElement().toString().trim();
                                    if (SolicitudUtil.validar(registro, "[Tt]{1}\\d{11}")) {
                                        if (!dummyModel.containsKey(registro)) {
                                            Long nunicodoct = Long.valueOf(registro.substring(1));
                                            if (!busquedaService.isEtiquetaCarteraEspecial(nunicodoct, BusquedaService.TIPO_ETIQUETA_T)) {
                                                dummy = busquedaService.obtenerCabeceraDocCte1Ph(cliente, nunicodoct);
                                                if (dummy != null) {
                                                    et = busquedaService.obtenerEtiqDocumHn(nunicodoct);
                                                    if (et.getEstadoUbicacion() == null || et.getEstadoUbicacion().equals("ETN") || et.getEstadoUbicacion().equals("ECU") || et.getEstadoUbicacion().equals("ECC") || et.getEstadoUbicacion().equals("INT") || et.getEstadoUbicacion().equals("ING") || et.getEstadoUbicacion().equals("ECR") || et.getEstadoUbicacion().equals("ECL") || et.getEstadoUbicacion().equals("PLP")) {
                                                        if (et.getScltcod().longValue() == cliente) {
                                                            dummyModel.put(registro, dummy);
                                                            encontrados++;
                                                        } else {
                                                            observaciones += "linea: " + linea + " - el Documento no pertenece al cliente de la consulta";
                                                            erroneos++;
                                                        }
                                                    } else {
                                                        observaciones += "linea: " + linea + " - el documento está en un estado ubicación NO valido para consultas";
                                                        erroneos++;
                                                    }
                                                } else {
                                                    observaciones += "linea: " + linea + " - no existe documento con etiqueta " + registro;
                                                    erroneos++;
                                                }
                                            } else {
                                                observaciones += "linea: " + linea + " - expediente bloqueado por cartera especial";
                                                erroneos++;
                                            }
                                        } else {
                                            observaciones += "linea: " + linea + " - etiqueta duplicada";
                                            erroneos++;
                                        }
                                    } else {
                                        observaciones += "linea: " + linea + " - etiqueta no valida";
                                        erroneos++;
                                    }
                                    if (observaciones != null && observaciones.trim().length() > 0) {
                                        observaciones += System.lineSeparator();
                                        ofos.write(observaciones.getBytes());
                                        observaciones = "";
                                    }
                                }

                                ifis.close();
                                ofos.close();

                                out = new ByteArrayOutputStream();
                                mapper.writeValue(out, dummyModel.values());

                                model.put("cabeceraDocCte1PhBeans", new String(((ByteArrayOutputStream) out).toByteArray()));
                                model.put("total", dummyModel.size());
                                model.put("encotrados", encontrados);
                                model.put("erroneos", erroneos);
                                model.put("success", true);
                                break;
                            default:
                                ifis.close();
                                ofos.close();
                                throw new Exception("Error, el modo de busqueda no existe");
                        }
                    } else if (modoConsulta == ComboItem.MODO_CONSULTA_CAJAS_VALUE) {
                        switch (busqueda) {
                            case ComboItem.CAMPO_BUSQUEDA_CAJA_ID_VALUE:
                                while (tokens.hasMoreElements()) {
                                    linea++;
                                    registro = tokens.nextElement().toString().trim();
                                    if (SolicitudUtil.validar(registro, "[Ss]{1}\\d{8}")) {
                                        if (!dummyModel.containsKey(registro)) {
                                            Long caja = Long.valueOf(registro.substring(1));
                                            if (!busquedaService.isEtiquetaCarteraEspecial(caja, BusquedaService.TIPO_ETIQUETA_S)) {
                                                dummy = busquedaService.obtenerCaja(caja, cliente);
                                                if (dummy != null) {
                                                    if (busquedaService.cajaAutorizada(((CajaBean) dummy).getCajaTipoId(), lugarConsulta) || busquedaService.cajaAutorizadaPorContenido(((CajaBean) dummy).getCajaId(), ((CajaBean) dummy).getCajaTipoId(), lugarConsulta, cliente)) {
                                                        dummyModel.put(registro, dummy);
                                                        encontrados++;
                                                    } else {
                                                        observaciones += "linea: " + linea + " - esta caja " + registro + " no está autorizada para este lugar de consulta";
                                                        erroneos++;
                                                    }
                                                } else {
                                                    observaciones += "linea: " + linea + " - no existe caja con etiqueta " + registro + " para el cliente " + cliente;
                                                    erroneos++;
                                                }
                                            } else {
                                                observaciones += "linea: " + linea + " - esta caja " + registro + " está bloqueada porque pertenece a una cartera especial";
                                                erroneos++;
                                            }
                                        } else {
                                            observaciones += "linea: " + linea + " - etiqueta duplicada";
                                            erroneos++;
                                        }
                                    } else {
                                        observaciones += "linea: " + linea + " - etiqueta no valida";
                                        erroneos++;
                                    }
                                    if (observaciones != null && observaciones.trim().length() > 0) {
                                        observaciones += System.lineSeparator();
                                        ofos.write(observaciones.getBytes());
                                        observaciones = "";
                                    }
                                }

                                ifis.close();
                                ofos.close();

                                out = new ByteArrayOutputStream();
                                mapper.writeValue(out, dummyModel.values());

                                model.put("cajaBeans", new String(((ByteArrayOutputStream) out).toByteArray()));
                                model.put("total", dummyModel.size());
                                model.put("encotrados", encontrados);
                                model.put("erroneos", erroneos);
                                model.put("success", true);
                                break;
                            case ComboItem.CAMPO_BUSQUEDA_CAJA_ADEA_VALUE:
                                while (tokens.hasMoreElements()) {
                                    linea++;
                                    registro = tokens.nextElement().toString().trim();
                                    if (SolicitudUtil.validar(registro, "\\d{1,8}")) {
                                        Long cajaAdea = Long.valueOf(registro);
                                        dummy = busquedaService.obtenerCajaByCajaAdea(cajaAdea, cliente);
                                        if (dummy != null) {
                                            if (!busquedaService.isEtiquetaCarteraEspecial(((CajaBean) dummy).getCajaId(), BusquedaService.TIPO_ETIQUETA_S)) {
                                                if (busquedaService.cajaAutorizada(((CajaBean) dummy).getCajaTipoId(), lugarConsulta) || busquedaService.cajaAutorizadaPorContenido(((CajaBean) dummy).getCajaId(), ((CajaBean) dummy).getCajaTipoId(), lugarConsulta, cliente)) {
                                                    dummyModel.put(registro, (CajaBean) dummy);
                                                    encontrados++;
                                                } else {
                                                    observaciones += "linea: " + linea + " - esta caja " + registro + " no está autorizada para este lugar de consulta";
                                                    erroneos++;
                                                }
                                            } else {
                                                observaciones += "linea: " + linea + " - esta caja " + registro + " está bloqueada porque pertenece a una cartera especial";
                                                erroneos++;
                                            }
                                        } else {
                                            observaciones += "linea: " + linea + " - no existe caja con caja adea " + registro + " para el cliente " + cliente;
                                            erroneos++;
                                        }
                                    } else {
                                        observaciones += "linea: " + linea + " - etiqueta no valida";
                                        erroneos++;
                                    }
                                    if (observaciones != null && observaciones.trim().length() > 0) {
                                        observaciones += System.lineSeparator();
                                        ofos.write(observaciones.getBytes());
                                        observaciones = "";
                                    }
                                }

                                ifis.close();
                                ofos.close();

                                out = new ByteArrayOutputStream();
                                mapper.writeValue(out, dummyModel.values());

                                model.put("cajaBeans", new String(((ByteArrayOutputStream) out).toByteArray()));
                                model.put("total", dummyModel.size());
                                model.put("encotrados", encontrados);
                                model.put("erroneos", erroneos);
                                model.put("success", true);
                                break;
                            default:
                                ifis.close();
                                ofos.close();
                                throw new Exception("Error, el modo de busqueda no existe");
                        }
                    } else {
                        ifis.close();
                        ofos.close();
                        throw new Exception("Error, el tipo de busqueda no existe");
                    }
                } else {
                    throw new Exception("El tipo de archivo no es valido");
                }
            }
//            return model;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public String getStatusDocument(CabeceraDocCte1PhBean document) {
        Integer val = document.getEstadoDocumento();
        if (val == 1 || val == 3 || val == 50 || val == 100) {
            return "Disponible";
        } else if (val == 2) {
            return "En consulta";
        } else if (val >= 100 && val < 200) {
            return "Solicitado en folio " + document.getFolioActivo();
        } else if (val == 200) {
            return "Bloqueado temporalmente";
        } else {
            return "";
        }
    }

    public String getStatusCaja(CajaBean caja) {
        Integer e = caja.getEstadoCaja();
        if (e == 1 || e == 3 || e == 50 || e == 100) {
            return "Disponible";
        } else if (e == 2) {
            return "En consulta";
        } else if (e >= 100 && e < 200) {
            return "Solicitado en folio " + caja.getFolioActivo();
        } else if (e == 200) {
            return "Bloqueado temporalmente";
        } else {
            return "";
        }
    }

    private boolean existInList(String param, String modoConsulta, int selectTipoBusqueda) {
        Long nunicodoc;
        if (ComboItem.MODO_CONSULTA_EXPEDIENTES_LABEL.compareTo(modoConsulta) == 0) {
            nunicodoc = Long.valueOf(param.substring(1));
            for (CabeceraDocBean exp : expedienteEncontrado) {
                if (exp.getNunicodoc().compareTo(nunicodoc) == 0) {
                    return true;
                }
            }
            return false;
        } else if (ComboItem.MODO_CONSULTA_DOCUMENTOS_LABEL.compareTo(modoConsulta) == 0) {
            nunicodoc = Long.valueOf(param.substring(1));
            for (CabeceraDocCte1PhBean exp : documentoEncontrado) {
                if (exp.getNunicodoct().compareTo(nunicodoc) == 0) {
                    return true;
                }
            }
            return false;
        } else if (ComboItem.MODO_CONSULTA_CAJAS_LABEL.compareTo(modoConsulta) == 0) {
            for (CajaBean exp : cajaEncontrado) {
                switch (selectTipoBusqueda) {
                    case ComboItem.CAMPO_BUSQUEDA_CAJA_ID_VALUE:
                        nunicodoc = Long.valueOf(param.substring(1));
                        if (exp.getCajaId().compareTo(nunicodoc) == 0) {
                            return true;
                        }
                        break;
                    case ComboItem.CAMPO_BUSQUEDA_CAJA_ADEA_VALUE:
                        nunicodoc = Long.valueOf(param);
                        if (exp.getCajaAdea().compareTo(nunicodoc) == 0) {
                            return true;
                        }
                }
            }
            return false;
        } else if (ComboItem.MODO_CONSULTA_KIT_DOCUMENTOS_LABEL.compareTo(modoConsulta) == 0) {
            nunicodoc = Long.valueOf(param.substring(1));
            for (CabeceraDocCte1PhBean exp : documentoEncontrado) {
                if (exp.getNunicodoc().compareTo(nunicodoc) == 0) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    /* METODOS QUE CORRESPONDEN A LAS BUSQUEDAS DE EXPEDIENTES, DOCUMENTOS, CAJAS Y ARCHIVOS */
    public void buscar() {
        Long nunicodoc;
        try {
            if ("".compareTo(paramBusqueda.trim()) == 0) {
                MessagesShow.showMessageError("El PARAMETRO DE BUSQUEDA NO PUEDE SER VACÍO.");
                return;
            }
            if (!existInList(paramBusqueda, modoConsulta, selectTipoBusqueda)) {
                busquedaService.buscar(new String[]{paramBusqueda}, modoConsulta, selectTipoBusqueda, clienteId,
                        lugarConsulta, expedienteEncontrado, documentoEncontrado, cajaEncontrado, kitSelected);
                paramBusqueda = "";
            } else {
                MessagesShow.showMessageValidacion("El PARAMETRO DE BUSQUEDA YA EXISTE EN ESTA LISTA.");
                paramBusqueda = "";
            }
            

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            MessagesShow.showMessageError(e.getMessage());
        }
    }

    public String obtenerPersona(Long codPersona) {
        PersonasCap person = null;
        if (codPersona != null) {
            person = catalogoServiceImpl.getPersonaByCod(codPersona);
            if (person != null) {
                return person.getDescripcion();
            }
        }
        return "-";
    }

    public String obtenerCredito(CabeceraDocCap cab) {
        if (cab != null) {
            if (cab.getNroidentdoc() != null && "".compareTo(cab.getNroidentdoc()) != 0) {
                return cab.getNroidentdoc();
            }
            if (cab.getNroreferenc() != null && "".compareTo(cab.getNroreferenc()) != 0) {
                return cab.getNroreferenc();
            }
            if (cab.getDescripcion() != null && "".compareTo(cab.getDescripcion()) != 0) {
                return cab.getDescripcion();
            }
        }
        return "-";
    }

    public ScSolicitudConsulta getConsulta() {
        return consulta;
    }

    public void setConsulta(ScSolicitudConsulta consulta) {
        this.consulta = consulta;
    }

    public boolean isFacturable() {
        return facturable;
    }

    public void setFacturable(boolean facturable) {
        this.facturable = facturable;
    }

    public Long getClienteId() {
        return clienteId;
    }

    public void setClienteId(Long clienteId) {
        this.clienteId = clienteId;
    }

    public List<Clientes> getClientList() {
        return clientList;
    }

    public void setClientList(List<Clientes> clientList) {
        this.clientList = clientList;
    }

    public List<ComboItem> getLugarConsultaList() {
        return lugarConsultaList;
    }

    public void setLugarConsultaList(List<ComboItem> lugarConsultaList) {
        this.lugarConsultaList = lugarConsultaList;
    }

    public Integer getLugarConsulta() {
        return lugarConsulta;
    }

    public void setLugarConsulta(Integer lugarConsulta) {
        this.lugarConsulta = lugarConsulta;
    }

    public List<AdeaCatalogos> getModosConsultaList() {
        return modosConsultaList;
    }

    public void setModosConsultaList(List<AdeaCatalogos> modosConsultaList) {
        this.modosConsultaList = modosConsultaList;
    }

    public String getModoConsulta() {
        return modoConsulta;
    }

    public void setModoConsulta(String modoConsulta) {
        this.modoConsulta = modoConsulta;
    }

    public List<ScPrioridad> getPrioridadList() {
        return prioridadList;
    }

    public void setPrioridadList(List<ScPrioridad> prioridadList) {
        this.prioridadList = prioridadList;
    }

    public Long getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(Long prioridad) {
        this.prioridad = prioridad;
    }

    public List<ScTipoConsulta> getTipoConsultaList() {
        return tipoConsultaList;
    }

    public void setTipoConsultaList(List<ScTipoConsulta> tipoConsultaList) {
        this.tipoConsultaList = tipoConsultaList;
    }

    public Long getTipoConsulta() {
        return tipoConsulta;
    }

    public void setTipoConsulta(Long tipoConsulta) {
        this.tipoConsulta = tipoConsulta;
    }

    public List<ScPersonalBean> getSolicitanteList() {
        return solicitanteList;
    }

    public void setSolicitanteList(List<ScPersonalBean> solicitanteList) {
        this.solicitanteList = solicitanteList;
    }

    public Long getSolicitante() {
        return solicitante;
    }

    public void setSolicitante(Long solicitante) {
        this.solicitante = solicitante;
    }

    public List<ScPersonalBean> getReceptoresList() {
        return receptoresList;
    }

    public void setReceptoresList(List<ScPersonalBean> receptoresList) {
        this.receptoresList = receptoresList;
    }

    public Long getReceptor() {
        return receptor;
    }

    public void setReceptor(Long receptor) {
        this.receptor = receptor;
    }

    public List<ScCentroCosto> getCentroCostoList() {
        return centroCostoList;
    }

    public void setCentroCostoList(List<ScCentroCosto> centroCostoList) {
        this.centroCostoList = centroCostoList;
    }

    public Long getCentroCosto() {
        return centroCosto;
    }

    public void setCentroCosto(Long centroCosto) {
        this.centroCosto = centroCosto;
    }

    public List<ComboItem> getComboBusqueda() {
        return comboBusqueda;
    }

    public void setComboBusqueda(List<ComboItem> comboBusqueda) {
        this.comboBusqueda = comboBusqueda;
    }

    public String getLblParamBusqueda() {
        return lblParamBusqueda;
    }

    public void setLblParamBusqueda(String lblParamBusqueda) {
        this.lblParamBusqueda = lblParamBusqueda;
    }

    public String getTitlePanelBusqueda() {
        return titlePanelBusqueda;
    }

    public void setTitlePanelBusqueda(String titlePanelBusqueda) {
        this.titlePanelBusqueda = titlePanelBusqueda;
    }

    public boolean isExpedientes() {
        return expedientes;
    }

    public void setExpedientes(boolean expedientes) {
        this.expedientes = expedientes;
    }

    public boolean isDocumentos() {
        return documentos;
    }

    public void setDocumentos(boolean documentos) {
        this.documentos = documentos;
    }

    public boolean isCajas() {
        return cajas;
    }

    public void setCajas(boolean cajas) {
        this.cajas = cajas;
    }

    public boolean isCargaArchivos() {
        return cargaArchivos;
    }

    public void setCargaArchivos(boolean cargaArchivos) {
        this.cargaArchivos = cargaArchivos;
    }

    public String getParamBusqueda() {
        return paramBusqueda;
    }

    public void setParamBusqueda(String paramBusqueda) {
        this.paramBusqueda = paramBusqueda;
    }

    public Integer getSelectTipoBusqueda() {
        return selectTipoBusqueda;
    }

    public void setSelectTipoBusqueda(Integer selectTipoBusqueda) {
        this.selectTipoBusqueda = selectTipoBusqueda;
    }

    public List<CabeceraDocBean> getExpedientesSeleccionados() {
        return expedientesSeleccionados;
    }

    public void setExpedientesSeleccionados(List<CabeceraDocBean> expedientesSeleccionados) {
        this.expedientesSeleccionados = expedientesSeleccionados;
    }

    public List<CabeceraDocCte1PhBean> getDocumentosSeleccionados() {
        return documentosSeleccionados;
    }

    public void setDocumentosSeleccionados(List<CabeceraDocCte1PhBean> documentosSeleccionados) {
        this.documentosSeleccionados = documentosSeleccionados;
    }

    public List<CajaBean> getCajasSeleccionadas() {
        return cajasSeleccionadas;
    }

    public void setCajasSeleccionadas(List<CajaBean> cajasSeleccionadas) {
        this.cajasSeleccionadas = cajasSeleccionadas;
    }

    public int getTipoCarga() {
        return tipoCarga;
    }

    public void setTipoCarga(int tipoCarga) {
        this.tipoCarga = tipoCarga;
    }

    public List<CabeceraDocBean> getExpedienteEncontrado() {
        return expedienteEncontrado;
    }

    public void setExpedienteEncontrado(List<CabeceraDocBean> expedienteEncontrado) {
        this.expedienteEncontrado = expedienteEncontrado;
    }

    public List<CabeceraDocCte1PhBean> getDocumentoEncontrado() {
        return documentoEncontrado;
    }

    public void setDocumentoEncontrado(List<CabeceraDocCte1PhBean> documentoEncontrado) {
        this.documentoEncontrado = documentoEncontrado;
    }

    public List<CajaBean> getCajaEncontrado() {
        return cajaEncontrado;
    }

    public void setCajaEncontrado(List<CajaBean> cajaEncontrado) {
        this.cajaEncontrado = cajaEncontrado;
    }

    public String getFolioCliente() {
        return folioCliente;
    }

    public void setFolioCliente(String folioCliente) {
        this.folioCliente = folioCliente;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getObservacionesFact() {
        return observacionesFact;
    }

    public void setObservacionesFact(String observacionesFact) {
        this.observacionesFact = observacionesFact;
    }

    public List<AdeaCatalogos> getKitModoConsultaList() {
        return kitModoConsultaList;
    }

    public void setKitModoConsultaList(List<AdeaCatalogos> kitModoConsultaList) {
        this.kitModoConsultaList = kitModoConsultaList;
    }

    public Integer getKitSelected() {
        return kitSelected;
    }

    public void setKitSelected(Integer kitSelected) {
        this.kitSelected = kitSelected;
    }

    public String getNunicodocFilter() {
        return nunicodocFilter;
    }

    public void setNunicodocFilter(String nunicodocFilter) {
        this.nunicodocFilter = nunicodocFilter;
    }

    public String getNroIdentdocFilter() {
        return nroIdentdocFilter;
    }

    public void setNroIdentdocFilter(String nroIdentdocFilter) {
        this.nroIdentdocFilter = nroIdentdocFilter;
    }

    public Long getFolioFilter() {
        return folioFilter;
    }

    public void setFolioFilter(Long folioFilter) {
        this.folioFilter = folioFilter;
    }

    public Long getCreditoFilter() {
        return creditoFilter;
    }

    public void setCreditoFilter(Long creditoFilter) {
        this.creditoFilter = creditoFilter;
    }

}
