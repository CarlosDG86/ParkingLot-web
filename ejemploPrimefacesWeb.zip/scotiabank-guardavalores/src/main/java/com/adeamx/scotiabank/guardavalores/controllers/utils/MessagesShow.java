/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers.utils;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author yfigueredo
 */
public abstract class MessagesShow {
    public static void showMessageInfo(String details){
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información", details);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public static void showMessageError(String details){
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", details);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public static void showMessageValidacion(String details){
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Validación", details);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public static void showMessageGlobal(FacesMessage.Severity severity, String title, String details){
        FacesMessage message = new FacesMessage(severity, title, details);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
}
