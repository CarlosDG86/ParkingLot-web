package com.adeamx.scotiabank.guardavalores.convert;

import com.adeamx.scotiabank.guardavalores.lib.beans.TipoRecepcion;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 *
 * @author fvelazquez
 */
@FacesConverter("tipoRecepcionConverter")
public class TipoRecepcionConverter implements Converter{
    
    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
        if(value != null && value.trim().length() > 0) {
            
                TipoRecepcion tipoRecepcion = new TipoRecepcion();
                tipoRecepcion.setClave(1);
                tipoRecepcion.setDescripcion("VALIJA");
                System.out.println("TipoRecepcionConverter -> getAsObject -> value \n" + value);
                return tipoRecepcion;
            
        }else{
            return null;
        }
    }
    
    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object object) {
        if( object != null && object.getClass().getName().equalsIgnoreCase("com.adeamx.scotiabank.guardavalores.lib.beans.TipoRecepcion") ){
            System.out.println("TipoRecepcionConverter -> getAsString -> object \n" + object.toString());
            return String.valueOf( ((TipoRecepcion)object).getClave() );
        }else{
            return null;
        }
    }
    
}
