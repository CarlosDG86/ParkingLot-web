/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import mx.com.adea.security.core.userdetails.UserDetails;
import net.codicentro.core.TypeCast;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.apache.commons.lang.StringUtils;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.adeadms.core.adea.pojos.EtiqDocum;
import com.adeadms.core.adea.pojos.Horizontalca;
import com.adeamx.adeadms.servicios.RegistroGeneralServicio;
import com.adeamx.dms.libs.consultas.pojos.AdeaCatalogos;
import com.adeamx.faces.lib.utilerias.MessagesShow;
import com.adeamx.scotiabank.guardavalores.lib.beans.ReporteTotalesLectMasiva;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScbnkBaseLectura;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScbnkBaseLecturaPk;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaLecturaMasivaService;
import com.adeamx.scotiabank.guardavalores.lib.utils.Constantes;

/**
 *
 * @author jdavila
 */
@Controller
@Scope("view")
public class ScotiaLecturaMasivaBean implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
//	public static final Long serialVersionUID = 20160119L;
    public final static String TARGET_PATH_DIGITALES = "Digitales";
    private static final Logger log = LoggerFactory.getLogger(ScotiaLecturaMasivaBean.class);

    @Value("${com.adeamx.security.antivirus.detecting.host}")
    private String antivirusDetectingHost;
    @Value("${com.adeamx.webmx.customer.id}")
    private Long cliente;

    private UserDetails userDetails;

    //MIO
    private ScbnkBaseLectura scbnkBaseLectura;
    private ScbnkBaseLecturaPk scbnkBaseLecturaPk;
    private ScbnkBaseLectura selectedTableRow;
    private ScbnkBaseLectura datosBdd;
    private List<ScbnkBaseLectura> scbnkBaseLecturaList;
    private List<AdeaCatalogos> documentosList;

    private Integer[] selectedDoctos;

    @Autowired
    ScotiaLecturaMasivaService scotiaLecturaMasivaService;
    @Autowired
    RegistroGeneralServicio registroGeneralServicio;

    private boolean ubicAdeaDisabled;
    private boolean ubicScotiaDisabled;
    private boolean etiquetaRecallDisabled;
    private boolean etiquetaAdeaDisabled;
    private boolean radioIncidenciaDisabled;
    private boolean sinEtqRecallDisabled;
    private boolean checklistDisabled;
    private boolean tipoCreditoDisabled;
    private boolean guadarIncidenciaDisabled;
    private boolean sinContenidoIncidenciaDisabled;
    private boolean isRecaptura = false;

    private boolean sinEtqRecallSelected;
    private String idIncidencia;
    private String etiquetaAdea;
    private String msjDoctos;
    private String msjDoctosSobrantes; 
    private int totalesByUbicacion;

    private Date now;

    @PostConstruct
    public void init() {
        userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        now = registroGeneralServicio.getFechaActual();
        //MIO
        scbnkBaseLecturaList = new ArrayList<ScbnkBaseLectura>();

        scbnkBaseLectura = new ScbnkBaseLectura();
        scbnkBaseLecturaPk = new ScbnkBaseLecturaPk();
        scbnkBaseLectura.setFechaLectura(now);
        ubicScotiaDisabled = false;
        ubicAdeaDisabled = true;
        checklistDisabled = true;
        sinEtqRecallDisabled = true;
        radioIncidenciaDisabled = true;
        tipoCreditoDisabled = true;
        guadarIncidenciaDisabled = true;
        sinContenidoIncidenciaDisabled = false;
        etiquetaRecallDisabled = true;
        etiquetaAdeaDisabled = true;
        isRecaptura = false;

    }

    public void validaUbicScotia() {
        System.out.println("validaUbicScotia");
        RequestContext requestContext = RequestContext.getCurrentInstance();
        try {
            if (!StringUtils.isNotEmpty(scbnkBaseLectura.getUbicacionRealRecall())) {

                scbnkBaseLectura.setUbicacionRealRecall("");
                requestContext.execute("document.getElementById('form:fluidGrid:UbicScotia').focus()");
                addMessageError("Error!", "LECTURA ERRONEA DE LA UBICACIÓN.");
            } else {
                if (scbnkBaseLectura.getUbicacionRealRecall().startsWith("C")
                        || Pattern.matches("U\\d{10}", scbnkBaseLectura.getUbicacionRealRecall())
                        || Pattern.matches("T\\d{11}", scbnkBaseLectura.getUbicacionRealRecall())
                        || Pattern.matches("S\\d{8}", scbnkBaseLectura.getUbicacionRealRecall())
                        || Pattern.matches("G\\d{12}", scbnkBaseLectura.getUbicacionRealRecall())) {

                    throw new Exception("LA LECTURA CORRESPONE A UNA ETIQIETA ADEA.");
                }
                 boolean existeUbicacion = scotiaLecturaMasivaService.getUbicacionScotian(scbnkBaseLectura.getUbicacionRealRecall());
                 if(!existeUbicacion){
                     throw new Exception("LA UBICACION SCOTIABANK NO EXISTE.");
                 }
                                
                //Obtenemos la lista de los totales
                totalesByUbicacion = scotiaLecturaMasivaService.getRegistrosPendientes(scbnkBaseLectura);

                //Obtenenmos los registros de las ubicaciones
                scbnkBaseLecturaList = scotiaLecturaMasivaService.getRegistrosByUbicaciones(scbnkBaseLectura);
                ubicScotiaDisabled = true;
                if (scbnkBaseLecturaList.size() > 0) {
                    scbnkBaseLectura.setUbicacionAdea(scbnkBaseLecturaList.get(0).getUbicacionAdea());
                    scbnkBaseLectura.setHzNunico(scbnkBaseLecturaList.get(0).getHzNunico());

                    sinEtqRecallDisabled = false;
                    etiquetaRecallDisabled = false;
                    requestContext.execute("document.getElementById('form:fluidGrid:EtiquetaRecall').focus()");
                } else {
                    ubicScotiaDisabled = true;
                    ubicAdeaDisabled = false;
                    requestContext.execute("document.getElementById('form:fluidGrid2:UbicAdea').focus()");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            scbnkBaseLectura.setUbicacionRealRecall("");
            addMessageError("Error!", e.getMessage());
            requestContext.execute("document.getElementById('form:fluidGrid:UbicScotia').focus()");
        }
    }

    public void validaUbicAdea() {
        System.out.println("validaUbicAdea");
        RequestContext requestContext = RequestContext.getCurrentInstance();
        try {

            if (scbnkBaseLectura.getUbicacionAdea().startsWith("C") && TypeCast.toInt(scbnkBaseLectura.getUbicacionAdea().substring(1, 3)) > -1 && TypeCast.toInt(scbnkBaseLectura.getUbicacionAdea().substring(5)) > -1 && scbnkBaseLectura.getUbicacionAdea().length() == 13) {
             //Ubicación AdeA C101A00600105
                //Validamos Ubicacion 
                Horizontalca horizontal = scotiaLecturaMasivaService.getUbicacionHz(scbnkBaseLectura.getUbicacionAdea());
                if (horizontal == null) {
                    throw new Exception("NO EXISTE LA UBICACION ADEA REGISTRADA");
                }
                scbnkBaseLectura.setHzNunico(horizontal.getHzNunico());
                ubicAdeaDisabled = true;
                sinEtqRecallDisabled = false;
                etiquetaRecallDisabled = false;
                requestContext.execute("document.getElementById('form:fluidGrid:EtiquetaRecall').focus()");
            } else {
                addMessageError("Error!", "LECTURA ERRONEA DE LA UBICACIÓN ADEA.");
                scbnkBaseLectura.setUbicacionAdea("");
                requestContext.execute("document.getElementById('form:fluidGrid2:UbicAdea').focus()");
                return;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            scbnkBaseLectura.setUbicacionAdea("");
            addMessageError("Error!", ex.getMessage());
            requestContext.execute("document.getElementById('form:fluidGrid2:UbicAdea').focus()");
            return;
        }
    }

    public void existeEtqRecall() {
        System.out.println("existeEtqRecall");
        RequestContext requestContext = RequestContext.getCurrentInstance();
        if (sinEtqRecallSelected) {
            scbnkBaseLectura.setConciliado(Constantes.ST_SOBRANTE);
            scbnkBaseLectura.setIncidencia(Constantes.SIN_ETIQUETA_RECALL);
            etiquetaAdeaDisabled = false;
            scbnkBaseLecturaPk.setEtqRecall(null);
            etiquetaRecallDisabled = true;
            requestContext.execute("document.getElementById('form:fluidGrid2:EtiquetaAdea').focus()");
        } else {
            etiquetaRecallDisabled = false;
            etiquetaAdeaDisabled = true;
            scbnkBaseLecturaPk.setNunicodoc(null);
            etiquetaAdea = null;
            requestContext.execute("document.getElementById('form:fluidGrid:EtiquetaRecall').focus()");
        }

    }

    public void validaEtiquetaRecall() {
        System.out.println("validaEtiquetaRecall");
        RequestContext requestContext = RequestContext.getCurrentInstance();
        try {

            if (scbnkBaseLecturaPk.getEtqRecall() != null) {

                //VALIDAMOS LA ETIQUETA DE INCIDENCIAS            		
                if (scbnkBaseLecturaPk.getEtqRecall().startsWith("C")
                        || Pattern.matches("U\\d{10}", scbnkBaseLecturaPk.getEtqRecall())
                        || Pattern.matches("T\\d{11}", scbnkBaseLecturaPk.getEtqRecall())
                        || Pattern.matches("S\\d{8}", scbnkBaseLecturaPk.getEtqRecall())
                        || Pattern.matches("G\\d{12}", scbnkBaseLecturaPk.getEtqRecall())) {

                    throw new Exception("LA LECTURA CORRESPONE A UNA ETIQIETA ADEA.");
                } else {
                    ScbnkBaseLectura etiqLeida = scotiaLecturaMasivaService.existeEtiqRecallLeida(scbnkBaseLecturaPk.getEtqRecall());

                    if (etiqLeida != null) {
                        MessagesShow.showMessageErrorBackEnd("YA EXISTE LA ETIQUETA " + scbnkBaseLecturaPk.getEtqRecall() + ", LEIDA POR EL USUARIO: " + etiqLeida.getUsuarioLectura() + " Y FECHA: " + etiqLeida.getFechaLectura());
                        scbnkBaseLecturaPk.setEtqRecall(null);
                        requestContext.execute("document.getElementById('form:fluidGrid:EtiquetaRecall').focus()");
                        return;
                    }

                    scbnkBaseLectura.setConciliado(Constantes.ST_CONCILIADO);
                    //Consultamos bdd para conciliar
                    datosBdd = scotiaLecturaMasivaService.getDatosRecall(scbnkBaseLecturaPk.getEtqRecall(), scbnkBaseLectura.getUbicacionRealRecall());
                    if (datosBdd == null) {
                        addMessageInfo("ALERTA!", "NO SE PUDO CONCILIAR LA ETIQUETA Y LA UBICACION EN LA BASE.  "
                                + "SE GUARDARA COMO SOBRANTE.");
                        scbnkBaseLectura.setConciliado(Constantes.ST_SOBRANTE);
                    } else {

                        
                        scbnkBaseLectura.setNoFolio(datosBdd.getNoFolio());
                        scbnkBaseLectura.setNoCredito(datosBdd.getNoCredito());
                        scbnkBaseLectura.setTipo(datosBdd.getTipo());
                        scbnkBaseLectura.setNomAcreditado(datosBdd.getNomAcreditado());
                        scbnkBaseLectura.setFechaCaptura(datosBdd.getFechaCaptura());
                        scbnkBaseLectura.setLocalizacion(datosBdd.getLocalizacion());
                        scbnkBaseLectura.setUbicacion(datosBdd.getUbicacion());
                        scbnkBaseLectura.setPrestamo(datosBdd.getPrestamo());
                        scbnkBaseLectura.setAreaPrestamo(datosBdd.getAreaPrestamo());
                        scbnkBaseLecturaPk.setTipoCredito(datosBdd.getScbnkBaseLecturaPk().getTipoCredito());
                        
                        if(!datosBdd.getUbicacion().equalsIgnoreCase(scbnkBaseLectura.getUbicacionRealRecall())){
                            addMessageInfo("ALERTA!", "LA ETIQUETA LEIDA SE ECUENTRA EN LA UBICACIÓN "+datosBdd.getUbicacion()+" \n SE GURDARA COMO SOBRANTE");
                             scbnkBaseLectura.setConciliado(Constantes.ST_SOBRANTE);
                        }
                    }
                    etiquetaRecallDisabled = true;
                    etiquetaAdeaDisabled = false;
                    requestContext.execute("document.getElementById('form:fluidGrid2:EtiquetaAdea').focus()");
                }

            } else {
                addMessageError("Error!", "NO EXISTE LA ETIQUETA RECALL.");
                scbnkBaseLecturaPk.setEtqRecall(null);
                requestContext.execute("document.getElementById('form:fluidGrid:EtiquetaRecall').focus()");
                return;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            addMessageError("Error!", ex.getMessage());
            scbnkBaseLecturaPk.setEtqRecall(null);
            requestContext.execute("document.getElementById('form:fluidGrid:EtiquetaRecall').focus()");
            return;
        }
    }

    public void validaEtiquetaAdea() {
        System.out.println("validaEtiquetaAdea");
        RequestContext requestContext = RequestContext.getCurrentInstance();
        try {
            if (StringUtils.isNotEmpty(etiquetaAdea) && !Pattern.matches("U\\d{10}", etiquetaAdea)) {
                addMessageError("Error!", "LECTURA ERRONEA DE LA ETIQUETA ADEA.");
                radioIncidenciaDisabled = true;
                requestContext.execute("document.getElementById('form:fluidGrid:EtiquetaRecall').focus()");
            } else {
                //	validamos etiq docum
                EtiqDocum etq = scotiaLecturaMasivaService.getEtiquetaU(TypeCast.toLong(etiquetaAdea.replace("U", "")));
                if (etq == null) {
                    etiquetaAdea = null;
                    throw new Exception("LA ETIQUETA ADEA NO EXISTE PARA ESTE CLIENTE");
                }
                
                //Validamos si se encuentra en la lista de lecturas
                for (ScbnkBaseLectura iter : scbnkBaseLecturaList) {
                    Long nunicolst = iter.getScbnkBaseLecturaPk().getNunicodoc();
                    Long nunicoLeido = TypeCast.toLong(etiquetaAdea.replace("U", ""));
                    if (nunicolst.compareTo(nunicoLeido) == 0) {
                        MessagesShow.showMessageErrorBackEnd("LA ETIQUETA ADEA, YA FUE LEIDA POR " + iter.getUsuarioLectura() + " CON FECHA " + iter.getFechaLectura());
                        etiquetaAdea = null;
                        requestContext.execute("document.getElementById('form:fluidGrid2:EtiquetaAdea').focus()");
                        return;
                    }
                }

                // validamos etiq leida
                ScbnkBaseLectura etiqLeida = scotiaLecturaMasivaService.getDatosRecallByNunicodoc(TypeCast.toLong(etiquetaAdea.replace("U", "")));
                if (etiqLeida != null) {
                    addMessageError("Error!", "LA ETIQUETA ADEA, YA FUE LEIDA EN ESTA UBICACIÓN.");
                    etiquetaAdea = null;
                    requestContext.execute("document.getElementById('form:fluidGrid2:EtiquetaAdea').focus()");
                    return;
                } else {
                    scbnkBaseLecturaPk.setNunicodoc(TypeCast.toLong(etiquetaAdea.replace("U", "")));
                    scbnkBaseLectura.setUsuarioLectura(userDetails.getUser().getLogin());
                    tipoCreditoDisabled = false;
                    radioIncidenciaDisabled = false;
                    checklistDisabled = false;
                    if (sinEtqRecallSelected) {
                        scbnkBaseLectura.setIncidencia(Constantes.SIN_ETIQUETA_RECALL);
                        scbnkBaseLecturaPk.setEtqRecall("0");
                        requestContext.execute("document.getElementById('form:consoleTipoCredito').focus()");
                    } else {
                        guadarIncidenciaDisabled = false;
                    }
                    //Obtenemos ChekList para Tipo de credito
                    scbnkBaseLectura.setScbnkBaseLecturaPk(scbnkBaseLecturaPk);
                    documentosList = scotiaLecturaMasivaService.getDocumentos(scbnkBaseLectura);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            addMessageError("Error!", "LECTURA ERRONEA. \n" + ex.getMessage());
        }
    }

    public void validaIncidencias() { // SE GUARDAN LOS REGISTROS EN LA BBDD
        System.out.println("validaIncidencias");
        RequestContext requestContext = RequestContext.getCurrentInstance();
        try {
            if (selectedDoctos == null) {
                if (scbnkBaseLecturaPk.getTipoCredito() == null) {
                    throw new Exception("FAVOR DE SELECCIONAR UN TÍPO DE CRÉDITO");
                }
                if (!scbnkBaseLecturaPk.getTipoCredito().equals(Constantes.C_PERSONAL) && !idIncidencia.equals("2") && !scbnkBaseLecturaPk.getTipoCredito().equals(Constantes.C_RRHH)) {
                    throw new Exception("DEBE SELECCIONAR ALMENOS UN DOCUMENTO");
                }
            }
            scbnkBaseLectura.setIncidencia(TypeCast.toInteger(idIncidencia));
            msjDoctos = "";
            msjDoctosSobrantes = "";
            
            
            scbnkBaseLectura.setScbnkBaseLecturaPk(scbnkBaseLecturaPk);
            
            //CALCULAMOS DOCTOS LEIDOS FALTANTES
            List<String> doctosFaltantes = scotiaLecturaMasivaService.getCklstFaltantes(selectedDoctos, scbnkBaseLectura, documentosList);
            
            //CALCULAMOS DOCTOS LEIDOS SOBRANTES
            List<String> doctosSobrantes = scotiaLecturaMasivaService.getCklstSobrantes(selectedDoctos, scbnkBaseLectura, documentosList);
            
            if (doctosFaltantes.size() > 0 && doctosFaltantes != null) {
                for (String docto : doctosFaltantes) {
                    msjDoctos = msjDoctos + docto + " | ";
                }
            } 
 
            if (doctosSobrantes.size() > 0 && doctosSobrantes != null) {
                for (String docto : doctosSobrantes) {
                    msjDoctosSobrantes = msjDoctosSobrantes + docto + " | ";
                }
            }
            
            if (!msjDoctos.equals("") || !msjDoctosSobrantes.equals("")){
                requestContext.addCallbackParam("doctosFaltantes", true);
            }else{
                guardaRegistro();
                requestContext.addCallbackParam("doctosFaltantes", false);   
            }
                    
        } catch (Exception e) {
            e.printStackTrace();
            addMessageWarning("Error!", e.getMessage());
            requestContext.addCallbackParam("doctosFaltantes", false);
        }

    }

    public void guardaRegistro() {
        System.out.println("guardaRegistro");
        try {
	    	//Guardamos el registro

            if (scbnkBaseLectura.getUbicacion() == null) {
                scbnkBaseLectura.setUbicacion(scbnkBaseLectura.getUbicacionRealRecall());
            }
            if (scbnkBaseLecturaPk.getEtqRecall() == null) {
                throw new Exception("DEBE INGRESAR UNA ETIQUETA RECALL");
            }
            if (scbnkBaseLecturaPk.getNunicodoc() == null) {
                throw new Exception("DEBE INGRESAR UNA ETIQUETA ADEA");
            }
            if (scbnkBaseLectura.getIncidencia() == null) {
                
                if(msjDoctos != ""){
                    scbnkBaseLectura.setIncidencia(4);
                    scbnkBaseLectura.setObservaciones("DocumentosFaltantes:"+msjDoctos);
                }else{
                     throw new Exception("DEBE INCLUIR ALGUNA INCIDENCIA, O INDICAR SIN INCIDENDCIA");
                }   
            }                 
            
            if(!"".equals(msjDoctos) && scbnkBaseLectura.getIncidencia().compareTo(Constantes.INCIDENCIA_CRC) != 0
                    && scbnkBaseLectura.getIncidencia().compareTo(Constantes.INCIDENCIA_SEGUROS) != 0
                    && scbnkBaseLectura.getIncidencia().compareTo(Constantes.INCIDENCIA_ASUNTOS_ESPECIALES) != 0
                    && scbnkBaseLectura.getIncidencia().compareTo(Constantes.INCIDENCIA_JURIDICO) != 0
                    && scbnkBaseLectura.getIncidencia().compareTo(Constantes.INCIDENCIA_LIQUIDADOS) != 0){
                    scbnkBaseLectura.setIncidencia(4);
                    scbnkBaseLectura.setObservaciones("DocumentosFaltantes:"+msjDoctos);
            }
            // VALIDAMOS SI EXISTE EN LOS EXPEDIENTES EN RECUPERACION
            if(scotiaLecturaMasivaService.existeExpRecuperacion(scbnkBaseLecturaPk.getEtqRecall())){
                scbnkBaseLectura.setIncidencia(Constantes.INCIDENCIA_RECUPERACION);
            }
            
            scbnkBaseLectura.setScbnkBaseLecturaPk(scbnkBaseLecturaPk);
            scbnkBaseLecturaList.remove(scbnkBaseLectura);
            scotiaLecturaMasivaService.guardaRegistroRecall(scbnkBaseLectura, selectedDoctos, msjDoctos);
        } catch (Exception e) {
            e.printStackTrace();
            addMessageWarning("Error!", e.getMessage());
        }
        scbnkBaseLecturaList.add(scbnkBaseLectura);

        inicializaValores();
    }

    public void eliminaRegistroTabla() {
        System.out.println("eliminaRegistroTabla");
        try {
            if (isRecaptura) {
                scbnkBaseLectura.setScbnkBaseLecturaPk(scbnkBaseLecturaPk);
                scotiaLecturaMasivaService.eliminaRegistroRecall(scbnkBaseLectura);
                scbnkBaseLecturaList.remove(scbnkBaseLectura);
                inicializaValores();
            }

        } catch (Exception e) {
            addMessageError("Error!", e.getMessage());
        }
    }

    public void cambiaTipoCredito() {
        System.out.println("cambiaTipoCredito");
        try {

            idIncidencia = null;
            if (scbnkBaseLecturaPk.getTipoCredito().equals("")) {
                documentosList = null;
                throw new Exception("DEBE SELECCIONAR UN TIPO DE CRÉDITO");
            }

            documentosList = scotiaLecturaMasivaService.getDocumentos(scbnkBaseLectura);
        } catch (Exception e) {
            addMessageError("Error!", e.getMessage());
        }

    }

    public void agregaDocumentos() {
//        System.out.println("agregaDocumentos");
        idIncidencia = null;
        if (selectedDoctos.length > 0) {
            sinContenidoIncidenciaDisabled = true;
        } else {
            sinContenidoIncidenciaDisabled = false;
        }

    }

    public void generaAcuse(String ubicacionScotia) {
        System.out.println("generaAcuse");
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();

            List<ReporteTotalesLectMasiva> reporteTotalesLMBeanList = scotiaLecturaMasivaService
                    .obtieneTotalesByUbicacion(ubicacionScotia);

            //Obtenemos reporte de faltantes y sobrantes
            List<ScbnkBaseLectura> sobFaltantesList = scotiaLecturaMasivaService.getSobrantesFaltantes(ubicacionScotia);

            JasperReport jr = JasperCompileManager.compileReport(Thread.currentThread().getContextClassLoader()
                    .getResourceAsStream("reports/ReporteTotalesIncidencias.jrxml"));

            JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(sobFaltantesList);

            Map<String, Object> parametros = new HashMap<String, Object>();

            SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyHHmm");
            String date = sdf.format(new Date());

            String folio = ubicacionScotia;
            folio = folio.substring(folio.length() - 4, folio.length()) + date;

            parametros.put("ubicacionScotia", ubicacionScotia);
            parametros.put("ubicacionAdea", reporteTotalesLMBeanList.get(0).getUbicacionAdea());
            parametros.put("localizacion", reporteTotalesLMBeanList.get(0).getLocalizacion());
            parametros.put("folio", folio);
            parametros.put("usuarioLectura", reporteTotalesLMBeanList.get(0).getUsuarioLectura());
            parametros.put("fechaLectura", reporteTotalesLMBeanList.get(0).getFechaLectura());
				// realizamos el for para los demas parametros

            parametros.put("TpoCredAuto", "AUTO");
            parametros.put("TpoCreditoHipo", "HIPOTECARIO");
            parametros.put("TpoCreditoPersonal", "PERSONAL");
            parametros.put("TpoCreditoRH", "RRHH");
            for (ReporteTotalesLectMasiva dataTotales : reporteTotalesLMBeanList) {

                if ((dataTotales.getTipoCredito()).equals(Constantes.C_AUTO)) {
                    parametros.put("conciliadoAuto", dataTotales.getConciliados());
                    parametros.put("sobranteAuto", dataTotales.getSobrantes());
                    parametros.put("faltanteAuto", dataTotales.getFaltantes());
                } else if ((dataTotales.getTipoCredito()).equals(Constantes.C_HIPOTECARIO)) {
                    parametros.put("conciliadoHipo", dataTotales.getConciliados());
                    parametros.put("sobranteHipo", dataTotales.getSobrantes());
                    parametros.put("faltanteHipo", dataTotales.getFaltantes());
                } else if ((dataTotales.getTipoCredito()).equals(Constantes.C_PERSONAL)) {
                    parametros.put("conciliadoPersonal", dataTotales.getConciliados());
                    parametros.put("sobrantePersonal", dataTotales.getSobrantes());
                    parametros.put("faltantePersonal", dataTotales.getFaltantes());
                } else if ((dataTotales.getTipoCredito()).equals(Constantes.C_RRHH)) {
                    parametros.put("conciliadoRH", dataTotales.getConciliados());
                    parametros.put("sobranteRH", dataTotales.getSobrantes());
                    parametros.put("faltanteRH", dataTotales.getFaltantes());
                }

            }

            //Guardamos el log del acuse por su ID
            scotiaLecturaMasivaService.guardalogAcuse(sobFaltantesList, reporteTotalesLMBeanList, folio);

            byte[] fichero = JasperRunManager.runReportToPdf(jr, parametros, beanCollectionDataSource);
            ServletOutputStream outputStream = response.getOutputStream();
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=\"Acuse_" + folio + ".pdf\"");
            outputStream.write(fichero);
            outputStream.flush();
            outputStream.close();
            context.renderResponse();
            context.responseComplete();

        } catch (Exception ex) {
            ex.printStackTrace();
            addMessageError("Error!", ex.getMessage());
        }
    }

    public void cierraUbicacion() {
        System.out.println("cierraUbicacion");
        RequestContext requestContext = RequestContext.getCurrentInstance();

        Map<String, Object> options = new HashMap<String, Object>();
        options.put("modal", true);
        options.put("draggable", false);
        options.put("resizable", true);
        options.put("contentWidth", 1090);
        options.put("contentHeight", 650);

        if (scbnkBaseLecturaList.size() > 0) {
//			FacesContext facesContext = FacesContext.getCurrentInstance();
//			HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
//			session.setAttribute("ubicScotia", scbnkBaseLecturaList.get(0).getUbicacionRealRecall());
            String ubic = scbnkBaseLecturaList.get(0).getUbicacionRealRecall();
            scotiaLecturaMasivaService.cierraUbicacion(scbnkBaseLecturaList.get(0));
            limpiaForm();
            RequestContext.getCurrentInstance().execute("alert('This onload script is added from backing bean.')");
            requestContext.update("form:TablaLecturas");

            generaAcuse(ubic);
//			RequestContext.getCurrentInstance().openDialog("/aplicacion/capturas/visualizaAcuse.xhtml", options, null);
        } else {
            addMessageError("Error!", "NO EXISTEN DATOS DE LECTURA");
        }

    }

    public void validaHotKeys() {
        System.out.println("ENTRA AWUI");

    }

    public void getRecaptura(SelectEvent event) {
        System.out.println("getRecaptura");
        if (event.getObject() != null) {
            scbnkBaseLectura = (ScbnkBaseLectura) event.getObject();
            etiquetaAdea = "U" + String.format("%010d", scbnkBaseLectura.getScbnkBaseLecturaPk().getNunicodoc());
            documentosList = scotiaLecturaMasivaService.getDocumentos(scbnkBaseLectura);

            radioIncidenciaDisabled = false;
            guadarIncidenciaDisabled = false;
            sinEtqRecallDisabled = true;
            etiquetaRecallDisabled = true;
            isRecaptura = true;
            //Obtenemos los doctos seleccionados
            selectedDoctos = scotiaLecturaMasivaService.obtieneSelectedDoctos(scbnkBaseLectura.getScbnkBaseLecturaPk().getNunicodoc());
            scbnkBaseLecturaPk = scbnkBaseLectura.getScbnkBaseLecturaPk();
        }
    }

    public void inicializaValores() {
        System.out.println("inicializaValores");
        String ubicacionReal = scbnkBaseLectura.getUbicacionRealRecall();
        String ubicAdea = scbnkBaseLectura.getUbicacionAdea();
        Integer nunicoHz = scbnkBaseLectura.getHzNunico();
        scbnkBaseLectura = new ScbnkBaseLectura();
        scbnkBaseLecturaPk = new ScbnkBaseLecturaPk();
        documentosList = new ArrayList<AdeaCatalogos>();
        scbnkBaseLectura.setFechaLectura(now);
        scbnkBaseLectura.setUbicacionAdea(ubicAdea);
        scbnkBaseLectura.setUbicacionRealRecall(ubicacionReal);
        scbnkBaseLectura.setHzNunico(nunicoHz);
        selectedDoctos = null;
        checklistDisabled = true;
        ubicScotiaDisabled = true;
        ubicAdeaDisabled = true;
        sinEtqRecallDisabled = false;
        radioIncidenciaDisabled = true;
        tipoCreditoDisabled = true;
        etiquetaRecallDisabled = false;
        etiquetaAdeaDisabled = true;
        sinEtqRecallSelected = false;
        guadarIncidenciaDisabled = true;
        idIncidencia = null;
        etiquetaAdea = null;
        datosBdd = null;
        sinContenidoIncidenciaDisabled = false;
        msjDoctos = null;
        msjDoctosSobrantes = null;
        isRecaptura = false;
    }

    public void limpiaForm() {
        System.out.println("limpiaForm");
        scbnkBaseLectura = new ScbnkBaseLectura();
        selectedTableRow = new ScbnkBaseLectura();
        scbnkBaseLecturaPk = new ScbnkBaseLecturaPk();
        scbnkBaseLecturaList = new ArrayList<ScbnkBaseLectura>();;
        documentosList = new ArrayList<AdeaCatalogos>();
        scbnkBaseLectura = new ScbnkBaseLectura();
        scbnkBaseLectura.setFechaLectura(now);

        ubicScotiaDisabled = false;
        ubicAdeaDisabled = true;
        sinEtqRecallDisabled = true;
        radioIncidenciaDisabled = true;
        guadarIncidenciaDisabled = true;
        etiquetaRecallDisabled = true;
        etiquetaAdeaDisabled = true;
        sinEtqRecallSelected = false;
        idIncidencia = null;
        etiquetaAdea = null;
        selectedDoctos = null;
        checklistDisabled = true;
        totalesByUbicacion = 0;
        isRecaptura = false;
    }

    /**
     * MENSAJES
     *
     * @param summary
     * @param detail
     */
    public void addMessageInfo(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void addMessageError(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void addMessageWarning(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, summary, detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public ScbnkBaseLectura getScbnkBaseLectura() {
        return scbnkBaseLectura;
    }

    public void setScbnkBaseLectura(ScbnkBaseLectura scbnkBaseLectura) {
        this.scbnkBaseLectura = scbnkBaseLectura;
    }

    public Date getNow() {
        return now;
    }

    public void setNow(Date now) {
        this.now = now;
    }

    public boolean isUbicAdeaDisabled() {
        return ubicAdeaDisabled;
    }

    public void setUbicAdeaDisabled(boolean ubicAdeaDisabled) {
        this.ubicAdeaDisabled = ubicAdeaDisabled;
    }

    public boolean isUbicScotiaDisabled() {
        return ubicScotiaDisabled;
    }

    public void setUbicScotiaDisabled(boolean ubicScotiaDisabled) {
        this.ubicScotiaDisabled = ubicScotiaDisabled;
    }

    public boolean isEtiquetaRecallDisabled() {
        return etiquetaRecallDisabled;
    }

    public void setEtiquetaRecallDisabled(boolean etiquetaRecallDisabled) {
        this.etiquetaRecallDisabled = etiquetaRecallDisabled;
    }

    public boolean isEtiquetaAdeaDisabled() {
        return etiquetaAdeaDisabled;
    }

    public void setEtiquetaAdeaDisabled(boolean etiquetaAdeaDisabled) {
        this.etiquetaAdeaDisabled = etiquetaAdeaDisabled;
    }

    /**
     * @return the scbnkBaseLecturaList
     */
    public List<ScbnkBaseLectura> getScbnkBaseLecturaList() {
        return scbnkBaseLecturaList;
    }

    /**
     * @param scbnkBaseLecturaList the scbnkBaseLecturaList to set
     */
    public void setScbnkBaseLecturaList(List<ScbnkBaseLectura> scbnkBaseLecturaList) {
        this.scbnkBaseLecturaList = scbnkBaseLecturaList;
    }

    public boolean isRadioIncidenciaDisabled() {
        return radioIncidenciaDisabled;
    }

    public void setRadioIncidenciaDisabled(boolean radioIncidenciaDisabled) {
        this.radioIncidenciaDisabled = radioIncidenciaDisabled;
    }

    public String getIdIncidencia() {
        return idIncidencia;
    }

    public void setIdIncidencia(String idIncidencia) {
        this.idIncidencia = idIncidencia;
    }

    public boolean isSinEtqRecallDisabled() {
        return sinEtqRecallDisabled;
    }

    public void setSinEtqRecallDisabled(boolean sinEtqRecallDisabled) {
        this.sinEtqRecallDisabled = sinEtqRecallDisabled;
    }

    public boolean isSinEtqRecallSelected() {
        return sinEtqRecallSelected;
    }

    public void setSinEtqRecallSelected(boolean sinEtqRecallSelected) {
        this.sinEtqRecallSelected = sinEtqRecallSelected;
    }

    public String getEtiquetaAdea() {
        return etiquetaAdea;
    }

    public void setEtiquetaAdea(String etiquetaAdea) {
        this.etiquetaAdea = etiquetaAdea;
    }

    public ScbnkBaseLectura getSelectedTableRow() {
        return selectedTableRow;
    }

    public void setSelectedTableRow(ScbnkBaseLectura selectedTableRow) {
        this.selectedTableRow = selectedTableRow;
    }

    public ScbnkBaseLectura getDatosBdd() {
        return datosBdd;
    }

    public void setDatosBdd(ScbnkBaseLectura datosBdd) {
        this.datosBdd = datosBdd;
    }

    public List<AdeaCatalogos> getDocumentosList() {
        return documentosList;
    }

    public void setDocumentosList(List<AdeaCatalogos> documentosList) {
        this.documentosList = documentosList;
    }

    public boolean isChecklistDisabled() {
        return checklistDisabled;
    }

    public void setChecklistDisabled(boolean checklistDisabled) {
        this.checklistDisabled = checklistDisabled;
    }

    public Integer[] getSelectedDoctos() {
        return selectedDoctos;
    }

    public void setSelectedDoctos(Integer[] selectedDoctos) {
        this.selectedDoctos = selectedDoctos;
    }

    public boolean isTipoCreditoDisabled() {
        return tipoCreditoDisabled;
    }

    public void setTipoCreditoDisabled(boolean tipoCreditoDisabled) {
        this.tipoCreditoDisabled = tipoCreditoDisabled;
    }

    public boolean isGuadarIncidenciaDisabled() {
        return guadarIncidenciaDisabled;
    }

    public void setGuadarIncidenciaDisabled(boolean guadarIncidenciaDisabled) {
        this.guadarIncidenciaDisabled = guadarIncidenciaDisabled;
    }

    public boolean isSinContenidoIncidenciaDisabled() {
        return sinContenidoIncidenciaDisabled;
    }

    public void setSinContenidoIncidenciaDisabled(
            boolean sinContenidoIncidenciaDisabled) {
        this.sinContenidoIncidenciaDisabled = sinContenidoIncidenciaDisabled;
    }

    public String getMsjDoctos() {
        return msjDoctos;
    }

    public void setMsjDoctos(String msjDoctos) {
        this.msjDoctos = msjDoctos;
    }

    public int getTotalesByUbicacion() {
        return totalesByUbicacion;
    }

    public void setTotalesByUbicacion(int totalesByUbicacion) {
        this.totalesByUbicacion = totalesByUbicacion;
    }

    public ScbnkBaseLecturaPk getScbnkBaseLecturaPk() {
        return scbnkBaseLecturaPk;
    }

    public void setScbnkBaseLecturaPk(ScbnkBaseLecturaPk scbnkBaseLecturaPk) {
        this.scbnkBaseLecturaPk = scbnkBaseLecturaPk;
    }

    public String getMsjDoctosSobrantes() {
        return msjDoctosSobrantes;
    }

    public void setMsjDoctosSobrantes(String msjDoctosSobrantes) {
        this.msjDoctosSobrantes = msjDoctosSobrantes;
    }

}
