package com.adeamx.scotiabank.guardavalores.solicitudes.controllers;

import com.adeamx.dms.libs.consultas.pojos.ScDocumentoSolicitado;
import com.adeamx.dms.libs.consultas.pojos.ScExpedienteSolicitado;
import com.adeamx.dms.libs.consultas.pojos.ScSolicitudConsulta;
import com.adeamx.faces.lib.utilerias.MessagesShow;
import com.adeamx.scotiabank.guardavalores.lib.beans.ReporteUbicacionesBean;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaSolicitudConsultaService;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import mx.com.adea.security.core.userdetails.UserDetails;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/**
 *
 * @author asalgado
 */
@Component
@Scope("view")
public class SolicitudesGeneradasController implements Serializable {

    private static final Logger logger = Logger.getLogger(SolicitudesGeneradasController.class.getName());

    @Value("${com.adeamx.webmx.customer.id}")
    private Long scltcod;

    @Autowired
    private ScotiaSolicitudConsultaService consultaService;

    UserDetails userDetails;
    private List<ScSolicitudConsulta> listSolicitudes;
    private ScSolicitudConsulta selectedSolicitud;
    private List<ScExpedienteSolicitado> expedientesSolicitados;
    private List<ScDocumentoSolicitado> documentosSolicitados;

    @PostConstruct
    public void init() {
        userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        search();
    }
    
    public void asignarExpedientes() {
        try {
            consultaService.asignarExpedientes(selectedSolicitud, expedientesSolicitados, documentosSolicitados, userDetails.getUsername());
            selectedSolicitud = null;
            search();
            MessagesShow.showMessageInfo("LA OPERACIÓN SE REALIZÓ CORRECTAMENTE.");
        } catch (Exception ex) {
            Logger.getLogger(SolicitudesGeneradasController.class.getName()).log(Level.SEVERE, null, ex);
            MessagesShow.showMessageErrorBackEnd("Ocurrió un error al asignar la solicitud: <br /> " + ex.getMessage());
        }
    }
    
    private void search() {
        listSolicitudes = consultaService.getSolicitudesGeneradas(scltcod);
    }
    
    public void onSolicitudSelect() {
        if (selectedSolicitud != null) {
            expedientesSolicitados = consultaService.getExpedientesSolicitados(selectedSolicitud.getFolio());
            documentosSolicitados = consultaService.getDocumentosSolicitados(selectedSolicitud.getFolio());
        } else {
            expedientesSolicitados = null;
            documentosSolicitados = null;
        }
    }
    
    public void reporteUbicaciones(){

        try {
            //TODO Agregar la GENERACION DEL ACUSE
            FacesContext context = FacesContext.getCurrentInstance();
            List<ReporteUbicacionesBean> dataList = consultaService.getReporteUbicaciones(selectedSolicitud.getFolio());
            HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();

            JasperReport jr = JasperCompileManager.compileReport(Thread.currentThread().getContextClassLoader()
                    .getResourceAsStream("reports/ReporteUbicaciones.jrxml"));

            JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(dataList);

            Map<String, Object> parametros = new HashMap<String, Object>();

            parametros.put("cliente", selectedSolicitud.getCliente().getAcltrzsc());
            parametros.put("receptor", selectedSolicitud.getScReceptor().getNombre());
            parametros.put("remitente", selectedSolicitud.getScSolicitante().getNombre());
            parametros.put("cCosto", selectedSolicitud.getScCc().getScCentroCostoPk().getIdCC());
            parametros.put("prioridad", selectedSolicitud.getPrioridad());
            parametros.put("fecha", selectedSolicitud.getFechaRespuesta());
            parametros.put("observaciones", selectedSolicitud.getObservaciones());
            parametros.put("folio", selectedSolicitud.getFolio());
            parametros.put("solicitud", selectedSolicitud.getNoSolicitud());

            byte[] fichero = JasperRunManager.runReportToPdf(jr, parametros, beanCollectionDataSource);
            ServletOutputStream outputStream = response.getOutputStream();
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=\"Acuse_" + selectedSolicitud.getFolio() + ".pdf\"");
            outputStream.write(fichero);
            outputStream.flush();
            outputStream.close();

            context.renderResponse();
            context.responseComplete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<ScSolicitudConsulta> getListSolicitudes() {
        return listSolicitudes;
    }

    public void setListSolicitudes(List<ScSolicitudConsulta> listSolicitudes) {
        this.listSolicitudes = listSolicitudes;
    }

    public ScSolicitudConsulta getSelectedSolicitud() {
        return selectedSolicitud;
    }

    public void setSelectedSolicitud(ScSolicitudConsulta selectedSolicitud) {
        this.selectedSolicitud = selectedSolicitud;
    }

    public List<ScExpedienteSolicitado> getExpedientesSolicitados() {
        return expedientesSolicitados;
    }

    public void setExpedientesSolicitados(List<ScExpedienteSolicitado> expedientesSolicitados) {
        this.expedientesSolicitados = expedientesSolicitados;
    }

    public List<ScDocumentoSolicitado> getDocumentosSolicitados() {
        return documentosSolicitados;
    }

    public void setDocumentosSolicitados(List<ScDocumentoSolicitado> documentosSolicitados) {
        this.documentosSolicitados = documentosSolicitados;
    }

}
