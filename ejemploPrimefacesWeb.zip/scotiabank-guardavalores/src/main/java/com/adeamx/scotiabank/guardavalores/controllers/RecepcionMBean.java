/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import mx.com.adea.security.core.userdetails.UserDetails;

import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.adeamx.scotiabank.guardavalores.lib.beans.Recepcion;
import com.adeamx.scotiabank.guardavalores.lib.beans.TipoRecepcion;
import com.adeamx.scotiabank.guardavalores.lib.beans.EtiquetaVW;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbCatIncidencia;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbRecepcion;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbRecepcionCab;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbSucursal;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbSucursalPK;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbSucursalValija;
import com.adeamx.scotiabank.guardavalores.lib.pojos.SbSucursalValijaPK;
import com.adeamx.scotiabank.guardavalores.lib.services.RecepcionService;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;

/**
 *
 * @author evglezmen
 */

@Controller
@Scope("view")
public class RecepcionMBean implements Serializable{    
    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    private Recepcion selectedRecepcion;
    private List<TipoRecepcion> tipoRecepcionLst;
    private List<SbCatIncidencia> incidenciaLst;
    private SbSucursalValija sucursalValija;
    private List<SbSucursalValija> sucValijaList;
    private List<SbSucursal> sucursalList;
    private List<SbRecepcion> recepcionList = new ArrayList<SbRecepcion>();
    private Boolean disabledValija = false;
    private Boolean disabledRecepcion = false;
    private Boolean disabledSucursal = false;
    private Boolean disabledSegurisello = false;
    private Boolean disabledIncidencia = false;
    private Boolean disabledExpediente = true;
    private Boolean isGenerated =false;
    private Integer totalValijas = 0;
    private Integer totalCajas = 0;
    private Integer totalExpedientes = 0;
    private SbRecepcion itemSelected;
    private Map<String, Object> reportParams = new HashMap<String, Object>();
    
    @Autowired
    private RecepcionService serviceRecepcion;
    
    @PostConstruct
    public void init(){
        selectedRecepcion = new Recepcion();
        tipoRecepcionLst = serviceRecepcion.getTipoRecepcionCat();
        incidenciaLst = serviceRecepcion.getIncidenciaCat(1);
        sucursalList = serviceRecepcion.getSucursalCat();
        disabledValija = true;
        disabledSucursal = true;
        disabledSegurisello = true;
        disabledIncidencia = true;
        disabledExpediente = true;
    }
    
    
    public boolean validaIngreso(){
        RequestContext requestContext = RequestContext.getCurrentInstance();
        boolean valido =  true;
        switch(selectedRecepcion.getTipoRecepcion().getClave()){
                   //** Realiza la validacion en el caso de que se trate de una Valija
            case 1:
                   sucursalValija = serviceRecepcion.obtenSucursalValija(selectedRecepcion.getValija());
                   if(sucursalValija == null){
                       valido = false;
                   }                   
                   break;
                
                  //** Realiza la validacion en el caso de que se trate de una Caja
            case 2:
                   break;
        }        
        requestContext.addCallbackParam("isValid", valido);
        return valido;
    }
    
    public void agregar(){
        System.out.println("--------------------------------------\nMetodo Agregar\n\n\n");
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        try {   
            
            if( selectedRecepcion.getTipoRecepcion() == null || selectedRecepcion.getTipoRecepcion().getClave() == 0 ){
                String msg = "No se ha seleccionado un Tipo de Recepcion, favor de verificar";
                throw new Exception(msg);
            }
            if(selectedRecepcion.getTipoRecepcion().getClave() == 1){
                if( (selectedRecepcion.getValija() == null || selectedRecepcion.getValija().equals("")) && selectedRecepcion.getTipoRecepcion().getClave() != 3 ){
                    String msg = "La Valija/Caja es obligatoria, favor de verificar";
                    throw new Exception(msg);
                }
                if( selectedRecepcion.getSucursal() == null && selectedRecepcion.getTipoRecepcion().getClave() != 3  ){
                    String msg = "No se ha seleccionado una Sucursal, favor de verificar";
                    throw new Exception(msg);
                }
                if( selectedRecepcion.getIncidencia() == null  ){
                    String msg = "No se ha seleccionado un Tipo de Incidencia, favor de verificar";
                    throw new Exception(msg);
                }
                if( selectedRecepcion.getExpediente() == null || selectedRecepcion.getExpediente().trim().isEmpty() ){
                    String msg = "El expediente es obligatorio, favor de verificar";
                    throw new Exception(msg);
                }
            }
            if(selectedRecepcion.getTipoRecepcion().getClave() == 2){
                if( (selectedRecepcion.getValija() == null || selectedRecepcion.getValija().equals("")) && selectedRecepcion.getTipoRecepcion().getClave() != 3 ){
                    String msg = "La Valija/Caja es obligatoria, favor de verificar";
                    throw new Exception(msg);
                }
                if( selectedRecepcion.getExpediente() == null || selectedRecepcion.getExpediente().trim().isEmpty() ){
                    String msg = "El expediente es obligatorio, favor de verificar";
                    throw new Exception(msg);
                }
            }
            if(selectedRecepcion.getTipoRecepcion().getClave() == 3){
                if( selectedRecepcion.getExpediente() == null || selectedRecepcion.getExpediente().trim().isEmpty() ){
                String msg = "El expediente es obligatorio, favor de verificar";
                throw new Exception(msg);
                }    
                if( selectedRecepcion.getSucursal() == null && selectedRecepcion.getTipoRecepcion().getClave() == 3  ) {
                    SbSucursal sinSuc = new SbSucursal(new SbSucursalPK(264, 0), "0000");
                    sinSuc.setDescripcion("SIN SUCURSAL");
                    selectedRecepcion.setSucursal(sinSuc);
                }
            }
            System.out.println(selectedRecepcion.toString());
            System.out.println("Expediente:" +selectedRecepcion.getExpediente());
            
            List<EtiquetaVW> etiquetaVW = serviceRecepcion.getEtiquetaVW(Long.valueOf(selectedRecepcion.getExpediente().substring(1)),
                    selectedRecepcion.getExpediente().substring(0, 1));
            if ((etiquetaVW != null) && (!etiquetaVW.isEmpty())) {
                System.out.println(etiquetaVW);
                if (etiquetaVW.get(0).getIngresada()) {
                    String msg = "El expediente " + selectedRecepcion.getExpediente() + " ya fue ingresado";
                    throw new Exception(msg);
                }
            } else {
                String msg = "Expediente no valido";
                throw new Exception(msg);
            }
            
            if(recepcionList != null && !recepcionList.isEmpty()){
                for(SbRecepcion r : recepcionList){
                    if(r.getTipo() == 3 && r.getSbRecepcionPK().getExpediente().equals(Long.valueOf(selectedRecepcion.getExpediente().substring(1))) ){
                        String msg = "El expediente "+selectedRecepcion.getExpediente() + " ya fue leido";
                        throw new Exception(msg);
                    }
                }
            }
            
            SbRecepcion r = serviceRecepcion.getRecepcionByExpediente(Long.valueOf(selectedRecepcion.getExpediente().substring(1)));
            if(r != null){
                String msg = "El expediente "+selectedRecepcion.getExpediente() + " ya fue Recibido";
                throw new Exception(msg);
            }
             SbRecepcion recepcion = new SbRecepcion();
            if( selectedRecepcion.getTipoRecepcion().getClave() == 1 ){
                if(!isInList(false)){
                    recepcion = new SbRecepcion(0L,selectedRecepcion.getValija());
                    recepcion.setTipo( selectedRecepcion.getTipoRecepcion().getClave() );
                    recepcion.setTipoDesc(selectedRecepcion.getTipoRecepcion().getDescripcion() );
                    recepcion.setSegurisello( selectedRecepcion.getSegurisello() );
                    recepcion.setIncidencia( selectedRecepcion.getIncidencia().getId() );
                    recepcion.setIncidenciaDesc(selectedRecepcion.getIncidencia().getTipoIncidencia() );
                    recepcion.setUsuario( userDetails.getUser().getLogin());
                    recepcion.setSsccod( selectedRecepcion.getSucursal().getSbSucursalPK().getSsccod() );
                    recepcion.setSsccodDesc(selectedRecepcion.getSucursal().getDescripcion() );
                    recepcionList.add(recepcion);
                    ++totalValijas;
                }
                recepcion = new SbRecepcion(Long.valueOf(selectedRecepcion.getExpediente().substring(1)),selectedRecepcion.getValija());
                recepcion.setTipo( 3 ); // Tipo Expediente
                recepcion.setTipoDesc( "EXPEDIENTE" ); // Tipo Expediente
                recepcion.setSegurisello( selectedRecepcion.getSegurisello() );
                recepcion.setIncidencia( selectedRecepcion.getIncidencia().getId() );
                recepcion.setIncidenciaDesc( selectedRecepcion.getIncidencia().getTipoIncidencia() );
                recepcion.setUsuario( userDetails.getUser().getLogin() );
                recepcion.setSsccod( selectedRecepcion.getSucursal().getSbSucursalPK().getSsccod() );
                recepcion.setSsccodDesc( selectedRecepcion.getSucursal().getDescripcion() );
            } else if( selectedRecepcion.getTipoRecepcion().getClave() == 2){
                if(!isInList(false)){
                    recepcion = new SbRecepcion(0L,selectedRecepcion.getValija());
                    recepcion.setTipo( selectedRecepcion.getTipoRecepcion().getClave() );
                    recepcion.setTipoDesc(selectedRecepcion.getTipoRecepcion().getDescripcion() );
                    recepcion.setUsuario( userDetails.getUser().getLogin());
                    recepcionList.add(recepcion);
                    ++totalCajas;
                }
                recepcion = new SbRecepcion(Long.valueOf(selectedRecepcion.getExpediente().substring(1)),selectedRecepcion.getValija());
                recepcion.setTipo( 3 ); // Tipo Expediente
                recepcion.setTipoDesc( "EXPEDIENTE" ); // Tipo Expediente
                recepcion.setUsuario( userDetails.getUser().getLogin() );
            }
            else if( selectedRecepcion.getTipoRecepcion().getClave() == 3) {
                recepcion = new SbRecepcion(Long.valueOf(selectedRecepcion.getExpediente().substring(1)),"0");
                recepcion.setTipo( 3 ); // Tipo Expediente
                recepcion.setTipoDesc( "EXPEDIENTE" ); // Tipo Expediente
                recepcion.setUsuario( userDetails.getUser().getLogin() );
            }
            recepcionList.add(recepcion);
            java.util.Collections.sort(recepcionList, new java.util.Comparator<SbRecepcion>() {
                @Override
                public int compare(SbRecepcion recep1, SbRecepcion recep2)
                {return  recep1.getSbRecepcionPK().getEtiqueta().compareTo(recep2.getSbRecepcionPK().getEtiqueta());}
            });
            ++totalExpedientes;
            selectedRecepcion.setExpediente(null);
        } catch (Exception e){
            RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "AVISO", e.getMessage() ));
            selectedRecepcion.setExpediente(null);
            RequestContext.getCurrentInstance().execute("PrimeFaces.focus('form:fluidGrid:txtExpediente');");
        }
    }
    
    /**
     * valida si la valija o caja ya fue ingrasada
     * @param boolean completaValija
     * si completaValija true carga datos de valija encontrada
    */
    private Boolean isInList(boolean completaValija){
        for (SbRecepcion item : recepcionList) {
            if((item.getSbRecepcionPK().getEtiqueta().compareTo(selectedRecepcion.getValija()) == 0) &&
                    (item.getSbRecepcionPK().getExpediente().compareTo(0L)) == 0){
                if((completaValija) &&(selectedRecepcion.getTipoRecepcion().getClave() == 1)){
                    selectedRecepcion.setSegurisello(item.getSegurisello());
                    SbCatIncidencia incidenciaAux = new SbCatIncidencia();
                    incidenciaAux.setId(item.getIncidencia());
                    incidenciaAux.setTipoIncidencia(item.getIncidenciaDesc());
                    selectedRecepcion.setIncidencia(incidenciaAux);
                    SbSucursal sucAux = new SbSucursal(new SbSucursalPK(264, item.getSsccod()), "0000");
                    sucAux.setDescripcion(item.getSsccodDesc());
                    selectedRecepcion.setSucursal(sucAux);
                }
                return true;
            }
        }
        return false;
    }
    
    public void exportPdfCartaDetalle() {
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
            JasperReport jr = JasperCompileManager.compileReport(Thread.currentThread().getContextClassLoader()
                    .getResourceAsStream("reports/acuseRecepcionCaptura.jrxml"));
            
            Connection connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521/scotiabank","system","Scotiabank2016");
            
            byte[] fichero = JasperRunManager.runReportToPdf(jr, reportParams,connection);
            ServletOutputStream outputStream = response.getOutputStream();
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=\"Acuse_Recepcion_" + reportParams.get("idRecepcion")+ ".pdf\"");
            connection.close();
            outputStream.write(fichero);
            outputStream.flush();
            outputStream.close();
            context.renderResponse();
            context.responseComplete();
        } catch (Exception e) {
            RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "AVISO", e.getMessage() ));
            e.printStackTrace();
        } finally {
            RequestContext.getCurrentInstance().execute("PF('confirmAcuse').hide()");
            isGenerated = false;
        }
    }

    public void validarRecepcion(){ 
        System.out.print("\n\nVALIDAR RECEPCION: ");
        if(selectedRecepcion.getTipoRecepcion() != null){
            if(selectedRecepcion.getTipoRecepcion().getClave().equals(1)){ //** Validacion para una Valija
                disabledRecepcion = true;
                disabledValija = false;
                disabledSucursal = false;
                disabledSegurisello = false;
                disabledIncidencia = false;
                disabledExpediente = false;
                sucursalValija = serviceRecepcion.obtenSucursalValija(selectedRecepcion.getValija());
                if(sucursalValija != null){            
                    SbSucursal suc = serviceRecepcion.getSucursalByCR(sucursalValija.getSbSucursalValijaPk().getCr());
                    selectedRecepcion.setSucursal(suc);
                }
                recepcionList.addAll(serviceRecepcion.getRecepcionByValija(selectedRecepcion.getValija()));
            } else if(selectedRecepcion.getTipoRecepcion().getClave().equals(2)){ //** Validacion para una Caja
                disabledRecepcion = true;
                disabledValija = false;
                disabledSucursal = true;
                disabledSegurisello = true;
                disabledIncidencia = true;
                disabledExpediente = false;
            }
            else if(selectedRecepcion.getTipoRecepcion().getClave().equals(3)){ //** Validacion para una Caja
                disabledRecepcion = true;
                disabledValija = true;
                disabledSucursal = true;
                disabledSegurisello = true;
                disabledIncidencia = true;
                disabledExpediente = false;
            }
        }   
        System.out.println(disabledValija + "\n\n");
    }
    
    public void relacionarValijaSucursal(){        
        System.out.println(selectedRecepcion.getValija());
        System.out.println(selectedRecepcion.getSucursal());
        if(!disabledSucursal && selectedRecepcion.getTipoRecepcion().getClave().equals(1)){
            System.out.println("Se guardará la relacion");
            SbSucursal suc = serviceRecepcion.getSucursalById(selectedRecepcion.getSucursal().getSbSucursalPK().getSsccod());
            SbSucursalValija sv = new SbSucursalValija();
            SbSucursalValijaPK pk = new SbSucursalValijaPK(selectedRecepcion.getValija(), suc.getCentroCosto());
            sv.setFechaAlta(serviceRecepcion.getFechaActual());
            sv.setSbSucursalValijaPk(pk);
            serviceRecepcion.guardarSucursalValija(sv);
            disabledValija = true;
            disabledRecepcion = true;
            disabledSucursal = true;
        }
    }
    
    public void guardar() {
        if (recepcionList != null && !recepcionList.isEmpty()) {

            SbRecepcionCab cabecero = new SbRecepcionCab();
            cabecero.setTipo(recepcionList.get(0).getTipo());
            cabecero.setUsuario(recepcionList.get(0).getUsuario());
            cabecero = serviceRecepcion.creaRecepcionCab(cabecero);
            if (cabecero != null) {
                String mensaje = serviceRecepcion.conciliaExpediente(recepcionList, cabecero);
                serviceRecepcion.save(recepcionList);
                reportParams.put("scltcod", 264L);
                reportParams.put("idRecepcion", cabecero.getIdRecepcion());
                reportParams.put("valijasCount", totalValijas);
                reportParams.put("cajasCount", totalCajas);
                reportParams.put("ExpedientesCount", totalExpedientes);
                if (!mensaje.isEmpty()) {
                    RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "Expedientes NO Conciliados", mensaje));
                } else {
                    isGenerated = true;
                    reset();
                    //FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("LA RECEPCION SE REALIZÓ CON EXITO", null));
                    RequestContext.getCurrentInstance().execute("PF('confirmAcuse').show();");
                }
            }
        } else {
            RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "SIN EXPEDIENTES", "FAVOR DE AGREGAR EXPEDIENTES PARA PODER GUARDAR"));
        }
    }
    
    public void validarEtiqueta(){
        if(selectedRecepcion.getValija() != null && selectedRecepcion.getValija().startsWith("G") && selectedRecepcion.getValija().length() == 13){
            selectedRecepcion.setTipoRecepcion(new TipoRecepcion(1, "VALIJA"));
            validarRecepcion();
            disabledValija = true;
            disabledRecepcion = true;   
        } else if(selectedRecepcion.getValija() != null && selectedRecepcion.getValija().startsWith("S") && selectedRecepcion.getValija().length() == 9){
            selectedRecepcion.setTipoRecepcion(new TipoRecepcion(2, "CAJA"));
            disabledValija = true;
            disabledRecepcion = true;              
        } else {
            RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "VALIJA / CAJA", "LA ETIQUETA DE VALIJA/CAJA NO ES CORRECTA" ));
        }
    }
    
    public void changeTipo(){
        if(selectedRecepcion.getValija() != null && selectedRecepcion.getTipoRecepcion() != null ){
            if ( (selectedRecepcion.getValija().startsWith("G") && selectedRecepcion.getTipoRecepcion().getClave().equals(1) && selectedRecepcion.getValija().length() == 13) ||
                 (selectedRecepcion.getValija().startsWith("S") && selectedRecepcion.getTipoRecepcion().getClave().equals(2) && selectedRecepcion.getValija().length() == 9) ){
                try{
                    Long val = new Long(selectedRecepcion.getValija().substring(1)); // Sólo es para validar el formato de la Valija y/o Caja
                    if (selectedRecepcion.getValija().startsWith("S")) {
                        List<EtiquetaVW> etiquetaVW= serviceRecepcion.getEtiquetaVW(
                                Long.valueOf(selectedRecepcion.getValija().substring(1)),
                                "S");
                        if ((etiquetaVW != null) && (!etiquetaVW.isEmpty())) {
                            disabledValija = true;
                        } else {
                            selectedRecepcion.setValija(null);
                            RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "TIPO RECEPCIÓN", "LA ETIQUETA DE CAJA NO ES CORRECTA"));
                        }
                    }
                    else if(isInList(true)) {
                        disabledValija = true;
                        disabledSucursal = true;
                        disabledSegurisello = true;
                        disabledIncidencia = true;
                    } else {
                        disabledValija = true;
                    }
                } catch(NumberFormatException e){
                    selectedRecepcion.setValija(null);
                    RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "TIPO RECEPCIÓN", "LA ETIQUETA DE VALIJA/CAJA NO ES CORRECTA" ));
                }                    
   
            } else if(selectedRecepcion.getTipoRecepcion().getClave().equals(3)){
                disabledValija = true;
            } else {
                selectedRecepcion.setValija(null);
                RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "TIPO RECEPCIÓN", "LA ETIQUETA DE VALIJA/CAJA NO PERTENECE AL TIPO DE RECEPCION SELECCIONADO O EL FORMATO NO ES CORRECTO" )); 
            }
        }
    }
    
    public void changeSucursal(){
        if(!disabledSucursal && selectedRecepcion.getTipoRecepcion().getClave().equals(1)){
            if(selectedRecepcion.getValija() == null || selectedRecepcion.getValija().length() < 10){
                selectedRecepcion.setSucursal(null);
                //selectedRecepcion.setTipoRecepcion(null);
                RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "Formato Incorrecto", "La Valija no tiene el formato correcto, favor de verificar" ));
            } else if(selectedRecepcion.getSucursal() != null) {
                SbSucursal suc = serviceRecepcion.getSucursalById(selectedRecepcion.getSucursal().getSbSucursalPK().getSsccod());            
                Integer relaciones = serviceRecepcion.getTotalValijasSucursal(suc.getCentroCosto());
            
                RequestContext.getCurrentInstance().execute("PF('confirm').show()");
                
                if(relaciones >= 5){
                    RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "RELACIÓN VALIJA - SUCURSAL", "LA SUCURSAL YA TIENE "+relaciones+" VALIJAS RELACIONADAS." ));
                }
            }
        } else {
            disabledValija = true;
            disabledRecepcion = true;
            disabledSucursal = true;
        }
    }
    
    public void changeIncidencia(){
        if(selectedRecepcion.getIncidencia() != null && selectedRecepcion.getTipoRecepcion().getClave() != 3){
            if(selectedRecepcion.getIncidencia().getId().equals(3)){
                selectedRecepcion.setSegurisello(null);
                disabledSegurisello = true;
            }else{
                if(selectedRecepcion.getSegurisello() != null && !selectedRecepcion.getSegurisello().equals("")){
                    disabledSegurisello = true;
                    disabledIncidencia = true;
                } else {
                    if(!disabledSegurisello){
                        RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "INCIDENCIA", "FAVOR DE ESCRIBIR PRIMERO EL SEGURISELLO" ));
                    }
                    disabledSegurisello = false;
                    selectedRecepcion.setIncidencia(null);                
                }
            }
        }
    }
    
    public void closeConfirm(){
//        RequestContext.getCurrentInstance().execute("PF('cs').selectValue(PF('cs').preShowValue.val())");
        RequestContext.getCurrentInstance().execute("PF('confirm').hide()");
    }
    
//    public void limpiar(){
//        selectedRecepcion = new Recepcion();
//        disabledValija = false;
//        disabledRecepcion = false;
//        disabledSucursal = false;        
//    }
    
    public void noDeleteItem(){
        itemSelected = null;
    }
    
    private void resetContadores(){
        totalValijas = 0;
        totalCajas = 0;
        totalExpedientes = 0;
    }
    
    public void agregarElemento(){
        disabledRecepcion = false;
        disabledValija = true;
        disabledSucursal = true;
        disabledSegurisello = true;
        disabledIncidencia = true;
        disabledExpediente = true;
        selectedRecepcion = new Recepcion();
    }
    
    private void deleteItem(){
        try {
            for (Iterator<SbRecepcion> item = recepcionList.iterator(); item.hasNext();) {
               SbRecepcion tipoRecepcion = item.next();
               if(tipoRecepcion.getSbRecepcionPK().getEtiqueta().compareTo(itemSelected.getSbRecepcionPK().getEtiqueta()) == 0){
                    switch(tipoRecepcion.getTipo()){
                        case 1: --totalValijas; break;
                        case 2: --totalCajas; break;
                        case 3: --totalExpedientes; break;
                    }
                   item.remove();
               }
            }
        } catch (Exception e) {
            System.out.println("Ocurrio un error:"+e.getMessage());
        }
    }
    
    public void resetElement(){
        deleteItem();
    }
    
    public void reset(){
        selectedRecepcion = new Recepcion();
        disabledValija = true;
        disabledRecepcion = false;
        disabledSucursal = true;
        recepcionList.clear();
        disabledSegurisello = true;
        disabledIncidencia = true;
        disabledExpediente = true;
        resetContadores();
    }
    
    public String eliminarExpediente(SbRecepcion reg){
        recepcionList.remove(reg);
        --totalExpedientes;
        return "";
    }
    
    public Recepcion getSelectedRecepcion() {
        return selectedRecepcion;
    }

    public void setSelectedRecepcion(Recepcion selectedRecepcion) {
        this.selectedRecepcion = selectedRecepcion;
    }

    public List<SbSucursalValija> getSucValijaList() {
        return sucValijaList;
    }

    public List<TipoRecepcion> getTipoRecepcionLst() {
        return tipoRecepcionLst;
    }

    public List<SbCatIncidencia> getIncidenciaLst() {
        return incidenciaLst;
    }

    public List<SbSucursal> getSucursalList() {
        return sucursalList;
    }    

    public List<SbRecepcion> getRecepcionList() {
        return recepcionList;
    }

    public Boolean getDisabledValija() {
        return disabledValija;
    }

    public void setDisabledValija(Boolean disabledValija) {
        this.disabledValija = disabledValija;
    }

    public Boolean getDisabledRecepcion() {
        return disabledRecepcion;
    }

    public void setDisabledRecepcion(Boolean disabledRecepcion) {
        this.disabledRecepcion = disabledRecepcion;
    }

    public Boolean getDisabledSucursal() {
        return disabledSucursal;
    }

    public void setDisabledSucursal(Boolean disabledSucursal) {
        this.disabledSucursal = disabledSucursal;
    }    

    public Boolean getDisabledSegurisello() {
        return disabledSegurisello;
    }

    public void setDisabledSegurisello(Boolean disabledSegurisello) {
        this.disabledSegurisello = disabledSegurisello;
    }

    public Boolean getDisabledIncidencia() {
        return disabledIncidencia;
    }

    public void setDisabledIncidencia(Boolean disabledIncidencia) {
        this.disabledIncidencia = disabledIncidencia;
    }

    public Boolean getDisabledExpediente() {
        return disabledExpediente;
    }

    public void setDisabledExpediente(Boolean disabledExpediente) {
        this.disabledExpediente = disabledExpediente;
    }

    public Integer getTotalValijas() {
        return totalValijas;
    }

    public void setTotalValijas(Integer totalValijas) {
        this.totalValijas = totalValijas;
    }

    public Integer getTotalCajas() {
        return totalCajas;
    }

    public void setTotalCajas(Integer totalCajas) {
        this.totalCajas = totalCajas;
    }

    public Integer getTotalExpedientes() {
        return totalExpedientes;
    }

    public void setTotalExpedientes(Integer totalExpedientes) {
        this.totalExpedientes = totalExpedientes;
    }

    public SbRecepcion getItemSelected() {
        return itemSelected;
    }

    public void setItemSelected(SbRecepcion itemSelected) {
        this.itemSelected = itemSelected;
    }

    public Boolean getIsGenerated() {
        return isGenerated;
    }

    public void setIsGenerated(Boolean isGenerated) {
        this.isGenerated = isGenerated;
    }
    
    /*public Long getIdRecepcion() {
        return idRecepcion;
    }

    public void setIdRecepcion(Long idRecepcion) {
        this.idRecepcion = idRecepcion;
    }*/
    
}
