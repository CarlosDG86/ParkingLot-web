/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adeamx.scotiabank.guardavalores.controllers;

import com.adeamx.adeadms.excepciones.ServicioException;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;

import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.adeamx.scotiabank.guardavalores.lib.beans.Recepcion;
import com.adeamx.scotiabank.guardavalores.lib.pojos.ScotiabankBaseCliente;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaSolicitudConsultaService;

/**
 *
 * @author dmarcos
 */

@Controller
@Scope("view")
public class BuscarFolioBean implements Serializable{    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Recepcion selectedRecepcion;
    private Boolean disabledValija = false;
     @Autowired
    private ScotiaSolicitudConsultaService serviceSolConsulta;
    
    @PostConstruct
    public void init(){
        selectedRecepcion = new Recepcion();
    }
           
    
        
    public void validarFolio(){
      Long folio= null; 
      String nameProducto= null;
      if(selectedRecepcion.getFolio() != null){
          try {
              folio = new Long(selectedRecepcion.getFolio());
              ScotiabankBaseCliente sbBC = serviceSolConsulta.getProductoByFolio(folio);
              if(sbBC != null){
                 if(sbBC.getProducto().equals("CH")){
                     nameProducto = "CREDITO HIPOTECARIO";
                 }else if(sbBC.getProducto().equals("CA")){
                     nameProducto = "CREDIAUTO";
                 }else if(sbBC.getProducto().equals("CP")){
                     nameProducto = "CREDITO PERSONAL";
                 }else if(sbBC.getProducto().equals("TC")){
                     nameProducto = "TARJETA DE CREDITO";
                 }else if(sbBC.getProducto().equals("SL")){
                     nameProducto = "SCOTIALINE";
                 }
                 selectedRecepcion.setFolio(null);
                 RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "CONSULTAR FOLIO", "FOLIO: " + folio +" TIPO DE PRODUCTO: " +nameProducto));
                 
              }else{
                   selectedRecepcion.setFolio(null);
                RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_WARN, "CONSULTAR FOLIO", "NO SE ENCONTRO REGISTRO PARA ESTE FOLIO" ));
              }
              
          } catch (NumberFormatException e) {
               selectedRecepcion.setFolio(null);
              RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_ERROR, "CONSULTAR FOLIO", "FORMATO DE FOLIO INCORRECTO" )); 
          } catch (ServicioException e) {
              selectedRecepcion.setFolio(null);
              RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_ERROR, "CONSULTAR FOLIO", "FORMATO DE FOLIO INCORRECTO" ));
          }
          // serviceSolConsulta.getProductoByFolio(serialVersionUID)
          
         // serviceSolConsulta.getProductoByFolio(serialVersionUID)
          
      }else{
           RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_ERROR, "CONSULTAR FOLIO", "FAVOR DE INGRESAR FOLIO" ));
      }
//        if(selectedRecepcion.getValija() != null && selectedRecepcion.getValija().startsWith("G") && selectedRecepcion.getValija().length() == 13){
//            selectedRecepcion.setTipoRecepcion(new TipoRecepcion(1, "VALIJA"));
//            validarRecepcion();
//            disabledValija = true;
//            disabledRecepcion = true;   
//        } else if(selectedRecepcion.getValija() != null && selectedRecepcion.getValija().startsWith("S") && selectedRecepcion.getValija().length() == 9){
//            selectedRecepcion.setTipoRecepcion(new TipoRecepcion(2, "CAJA"));
//            disabledValija = true;
//            disabledRecepcion = true;              
//        } else {
//            RequestContext.getCurrentInstance().showMessageInDialog(new FacesMessage(FacesMessage.SEVERITY_INFO, "VALIJA / CAJA", "LA ETIQUETA DE VALIJA/CAJA NO ES CORRECTA" ));
//        }
    }
    
     public Boolean getDisabledValija() {
        return disabledValija;
    }

    public void setDisabledValija(Boolean disabledValija) {
        this.disabledValija = disabledValija;
    }  
    
    public Recepcion getSelectedRecepcion() {
        return selectedRecepcion;
    }

    public void setSelectedRecepcion(Recepcion selectedRecepcion) {
        this.selectedRecepcion = selectedRecepcion;
    }

    
    
}
