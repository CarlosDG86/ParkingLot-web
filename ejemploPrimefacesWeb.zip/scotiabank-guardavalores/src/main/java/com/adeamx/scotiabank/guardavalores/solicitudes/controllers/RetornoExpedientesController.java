package com.adeamx.scotiabank.guardavalores.solicitudes.controllers;

import com.adeamx.dms.libs.consultas.pojos.ScRetorno;
import com.adeamx.faces.lib.utilerias.MessagesShow;
import com.adeamx.scotiabank.guardavalores.lib.beans.ExpedienteFolioRemito;
import com.adeamx.scotiabank.guardavalores.lib.beans.RetornoMsg;
import com.adeamx.scotiabank.guardavalores.lib.services.ScotiaRetornosService;
import com.adeamx.scotiabank.guardavalores.lib.utils.RetornosUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;
import mx.com.adea.security.core.userdetails.UserDetails;
import net.codicentro.core.TypeCast;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/**
 *
 * @author asalgado
 */
@Component
@Scope("view")
public class RetornoExpedientesController implements java.io.Serializable {

    private static final Logger logger = Logger.getLogger(RetornoExpedientesController.class.getName());

    @Autowired
    ScotiaRetornosService retornosService;

    UserDetails userDetails;

    private String etiqueta;
    private List<ExpedienteFolioRemito> listRetorno;

    @PostConstruct
    public void init() {
        userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        listRetorno = new ArrayList<ExpedienteFolioRemito>();
    }

    public void lecturaEtiqueta() {

        char tipo = etiqueta.charAt(0);
        Long nunicodoc = null;
        Long nunicodoct = null;
        boolean isExpedienteCompleto;

        switch (tipo) {
            case 'U':
                if (!Pattern.matches("U\\d{10}", etiqueta)) {
                    MessagesShow.showMessageError("EL FORMATO DE LA ETIQUETA NO ES VALIDO.");
                    return;
                }
                nunicodoc = TypeCast.toLong(etiqueta.substring(1));
                
                Map<String, Object> registro = retornosService.getExpedienteFolioRemito(nunicodoc);

                if (registro == null) {
                    MessagesShow.showMessageError("LA ETIQUETA NO SE ENCUENTRO EN ALGÚN REMITO ACTIVO.");
                    return;
                }
                ExpedienteFolioRemito folioRemito = castMapToExpedienteFolioRemito(registro);
                
                try {
                    isExpedienteCompleto = retornosService.isExpedienteCompleto(nunicodoc,folioRemito.getFolio());
                    if(!isExpedienteCompleto){
                        MessagesShow.showMessageError("FAVOR DE LEER LOS DOCUMENTOS DEL EXPEDIENTE.");
                        return;
                    }
                } catch(Exception e){
                    MessagesShow.showMessageError(e.getMessage());
                    return;
                }                
                folioRemito.setCompleto(isExpedienteCompleto);
                
                if (listRetorno.contains(folioRemito)) {
                    MessagesShow.showMessageError("LA ETIQUETA YA SE ENCUENTRA EN LA LISTA DE RETORNO.");
                    return;
                }
                listRetorno.add(folioRemito);
                break;

            case 'T':
                if (!Pattern.matches("T\\d{11}", etiqueta)) {
                    MessagesShow.showMessageError("EL FORMATO DE LA ETIQUETA NO ES VALIDO.");
                    return;
                }
                nunicodoct = TypeCast.toLong(etiqueta.substring(1));
                Map<String, Object> registroT = retornosService.getDocumentoFolioRemito(nunicodoct);

                if (registroT == null) {
                    MessagesShow.showMessageError("LA ETIQUETA NO SE ENCUENTRO EN ALGÚN REMITO ACTIVO.");
                    return;
                }

                ExpedienteFolioRemito dctRemito = castMapToExpedienteFolioRemito(registroT);
//                try {
//                    isExpedienteCompleto = retornosService.isExpedienteCompleto(dctRemito.getNunicodoc(), dctRemito.getFolio());
//
//                    dctRemito.setCompleto(isExpedienteCompleto);
//                    if(isExpedienteCompleto){
//                        boolean isDocFaltante = retornosService.isDocumentoFaltante(nunicodoct,dctRemito.getNunicodoc());
//                        if(!isDocFaltante){
//                            ExpedienteFolioRemito expRemito = new ExpedienteFolioRemito(dctRemito.getNunicodoc(), null);
//                            if (!listRetorno.contains(expRemito)) {
//                                MessagesShow.showMessageError("NO SE HA LEIDO EL EXPEDIENTE DE ESTE DOCUMENTO.");
//                                return;
//                            }
//                        }
//                    }
//                } catch(Exception e){
//                    MessagesShow.showMessageError(e.getMessage());
//                    return;
//                }
                
                if (listRetorno.contains(dctRemito)) {
                    MessagesShow.showMessageError("LA ETIQUETA YA SE ENCUENTRA EN LA LISTA DE RETORN0.");
                    return;
                }
                listRetorno.add(dctRemito);
                break;
            default:
                MessagesShow.showMessageError("EL FORMATO DE LA ETIQUETA NO ES VALIDO.");
        }

        Collections.sort(listRetorno, RetornosUtils.ExpedienteFolioRemitoComparator);

        etiqueta = null;

    }

    public void generaRetorno() {
        try {
            RetornoMsg scRetorno = retornosService.generarRetorno(listRetorno, userDetails.getUsername(), "");
            limpiarRetorno();
            StringBuilder msg = new StringBuilder();
            msg.append("LA OPERACIÓN SE REALIZÓ CORRECTAMENTE. <br /> Retorno generado: ").append(scRetorno.getRetorno().getIdRetorno());
            if(scRetorno.getMensaje() != null){
                msg.append("<br />").append(scRetorno.getMensaje());
            }            
            MessagesShow.showMessageInfoBackEnd(msg.toString());
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Ocurri\u00f3 un error al generar el retorno: <br /> {0}", ex.getMessage());
            MessagesShow.showMessageErrorBackEnd("Ocurrió un error al generar el retorno: <br> " + ex.getMessage());
        }
    }

    public void limpiarRetorno() {
        etiqueta = null;
        listRetorno = new ArrayList<ExpedienteFolioRemito>();
    }

    public boolean isEnableGeneraRetorno() {
        if (listRetorno != null && !listRetorno.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public List<ExpedienteFolioRemito> getListRetorno() {
        return listRetorno;
    }

    public void setListRetorno(List<ExpedienteFolioRemito> listRetorno) {
        this.listRetorno = listRetorno;
    }

    private ExpedienteFolioRemito castMapToExpedienteFolioRemito(Map<String, Object> registro) {
        ExpedienteFolioRemito efr = new ExpedienteFolioRemito();

        if (registro != null) {
            efr.setNunicodoc(TypeCast.toLong(registro.get("NUNICODOC")));
            efr.setNunicodoct(TypeCast.toLong(registro.get("NUNICODOCT")));
            efr.setDoccod(TypeCast.toLong(registro.get("DOCCOD")));
            efr.setIdRemito(TypeCast.toLong(registro.get("ID_REMITO")));
            efr.setFolio(TypeCast.toLong(registro.get("FOLIO")));
        }

        return efr;
    }

}
