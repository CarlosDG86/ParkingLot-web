/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function displayKeyCode(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    console.log(charCode);
    if (charCode == 13) {
        alert('Oprimiste Enter.');
    }
}

function permite(elEvento, permitidos) {
    // Variables que definen los caracteres permitidos
    var numeros = "0123456789";
    var decimales = "0123456789.";
    var caracteres = " ÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ-.,";
    var alphanumericos = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ-.,";
    var numeros_caracteres = numeros + caracteres;
    var numeros_alpha = numeros + alphanumericos;
    var teclas_especiales = [13, 9, 27, 8, 37, 39, 46];
    // 13 =  Enter, 9 = Tabulador, 27 = Escape, 8 = BackSpace, 46 = Supr, 37 = flecha izquierda, 39 = flecha derecha
    // 32 = Barra Espaciadora


    // Seleccionar los caracteres a partir del parámetro de la función
    switch (permitidos) {
        case 'num':
            permitidos = numeros;
            break;
        case 'decimal':
            permitidos = decimales;
            break;
        case 'car':
            permitidos = caracteres;
            teclas_especiales.push(32);
            break;
        case 'num_car':
            permitidos = numeros_caracteres;
            teclas_especiales.push(32);
            break;
        case 'num_alpha':
            permitidos = numeros_alpha;
            break;
    }

    // Obtener la tecla pulsada 
    var evento = elEvento || window.event;
    var codigoCaracter = evento.charCode || evento.keyCode;
    var caracter = String.fromCharCode(codigoCaracter).toUpperCase();

    // Comprobar si la tecla pulsada es alguna de las teclas especiales
    // (teclas de borrado y flechas horizontales)
    var tecla_especial = false;
    for (var i in teclas_especiales) {
        if (codigoCaracter == teclas_especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    // Comprobar si la tecla pulsada se encuentra en los caracteres permitidos
    // o si es una tecla especial
    return permitidos.indexOf(caracter) != -1 || tecla_especial;
}

function validaFloat(numero)
    {
        var codigoCaracter = evento.charCode || evento.keyCode;
        var caracter = String.fromCharCode(codigoCaracter).toUpperCase();
        var existe = false;
        if (!/^([0-9])*[.]?[0-9]*$/.test(caracter)){
            existe =  true;
        }
        return existe;

    }